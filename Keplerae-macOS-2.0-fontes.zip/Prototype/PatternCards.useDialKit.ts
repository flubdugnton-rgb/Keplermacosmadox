"use client";

import { useDialKit } from "dialkit";

// Parâmetros da referência web, incluindo a redução posterior de 30% na altura.
// No macOS, PatternCardParameters + PatternAnimationEngine reproduzem estes valores.
export function usePatternCardParameters() {
  return useDialKit("Pattern Cards", {
  "typography": {
    "titleSize": 33,
    "titleWeight": 700,
    "descriptionSize": 17,
    "descriptionWeight": 200
  },
  "highlight": {
    "x": 0.11,
    "y": -0.09
  },
  "card": {
    "height": 289.8
  },
  "effect": {
    "scale": 0.76
  },
  "animation": {
    "speed": 0.44,
    "phaseSpread": 2.25,
    "easing": 3,
    "fillBias": -0.34
  },
  "particles": {
    "spawnRate": 0.6,
    "fallSpeed": 47,
    "jitter": 0.26,
    "lifetime": 1.7,
    "fadeStart": 0,
    "startOpacity": 0.28
  },
  "patternA": {
    "size": 127,
    "dotScale": 0.86,
    "ringStrokeScale": 0.06
  },
  "patternB": {
    "size": 127,
    "dotScale": 0.86,
    "ringStrokeScale": 0.06
  },
  "patternC": {
    "size": 127,
    "dotScale": 0.86,
    "ringStrokeScale": 0.06
  },
  "tilt": {
    "maxAngle": 0,
    "randomness": 0.56,
    "perspective": 520,
    "scaleMax": 3.8,
    "scaleRadius": 161,
    "packIterations": 40,
    "easing": 1.6,
    "centerDurationMs": 420,
    "centerStaggerMs": 320,
    "centerOffsetY": -43,
    "keepInGrid": false,
    "pushSmoothingMs": 260,
    "scaleSmoothingMs": 220,
    "fadeOthers": true,
    "othersOpacity": 0.12
  },
  "shimmer": {
    "enabled": true,
    "intensity": 0.2,
    "widthPct": 162,
    "angleDeg": 38,
    "blurPx": 60,
    "durationMs": 320,
    "loopDelayMs": 8000,
    "color": {
      "type": "color",
      "default": "#ffffff"
    },
    "blendMode": {
      "type": "select",
      "options": [
        "overlay",
        "screen",
        "soft-light",
        "plus-lighter",
        "lighten",
        "color-dodge",
        "normal"
      ],
      "default": "screen"
    }
  }
});
}
