import XCTest

@MainActor
final class MistakeNotebookTests: XCTestCase {
    private func makeDefaults() -> (String, UserDefaults) {
        let suite = "com.keplerae.tests.mistakes.\(UUID().uuidString)"
        return (suite, UserDefaults(suiteName: suite)!)
    }

    func testLegacyQuestionsPayloadPreservesExistingResults() throws {
        let (suite, defaults) = makeDefaults()
        defer { defaults.removePersistentDomain(forName: suite) }
        let id = UUID()
        let legacy = """
        {"subjects":[{"id":"\(id)","name":"Português"}],
         "records":[{"id":"\(UUID())","subjectID":"\(id)","correct":8,"wrong":2,"recordedAt":0}]}
        """
        defaults.set(Data(legacy.utf8), forKey: "keplerae.questions.v1")
        let store = QuestionsStore(defaults: defaults)
        XCTAssertEqual(store.subjects.first?.id, id)
        XCTAssertEqual(store.totals().total, 10)
        XCTAssertTrue(store.mistakes.isEmpty)
        try store.upsertMistake(QuestionMistake(subjectID: id, topic: "Concordância"))
        let reopened = QuestionsStore(defaults: defaults)
        XCTAssertEqual(reopened.records, store.records)
        XCTAssertEqual(reopened.mistakes.count, 1)
    }

    func testNotebookSavesEditsReviewsAndDeletionAcrossReopen() throws {
        let (suite, defaults) = makeDefaults()
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = QuestionsStore(defaults: defaults)
        let subjectID = try store.createSubject("Matemática")
        var entry = QuestionMistake(subjectID: subjectID, topic: "Porcentagem", source: "Simulado", location: "Questão 12", question: "Calcule 20% de 80", markedAnswer: "12", correctAnswer: "16", explanation: "Multiplicar por 0,20", reason: .calculation, reviewDate: .distantPast)
        try store.upsertMistake(entry)
        XCTAssertTrue(store.mistakes[0].isDue)
        entry.explanation = "20/100 × 80 = 16"
        try store.upsertMistake(entry)
        store.setMistakeStatus(entry.id, status: .learned)
        let reopened = QuestionsStore(defaults: defaults)
        XCTAssertEqual(reopened.mistakes.count, 1)
        XCTAssertEqual(reopened.mistakes[0].explanation, entry.explanation)
        XCTAssertEqual(reopened.mistakes[0].correctAnswer, "16")
        XCTAssertFalse(reopened.mistakes[0].isDue)
        reopened.deleteMistake(entry.id)
        XCTAssertTrue(QuestionsStore(defaults: defaults).mistakes.isEmpty)
    }

    func testOlderSyncPayloadDoesNotEraseNotebookButExplicitEmptyDoes() throws {
        let (suite, defaults) = makeDefaults()
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = QuestionsStore(defaults: defaults)
        try store.upsertMistake(QuestionMistake(topic: "Revisão"))
        store.replace(subjects: [], records: [])
        XCTAssertEqual(store.mistakes.count, 1)
        store.replace(subjects: [], records: [], mistakes: [])
        XCTAssertTrue(QuestionsStore(defaults: defaults).mistakes.isEmpty)
    }

    func testInvalidNotebookEntryAndSubjectRemoval() throws {
        let (suite, defaults) = makeDefaults()
        defer { defaults.removePersistentDomain(forName: suite) }
        let store = QuestionsStore(defaults: defaults)
        XCTAssertThrowsError(try store.upsertMistake(QuestionMistake(topic: "  ")))
        XCTAssertThrowsError(try store.upsertMistake(QuestionMistake(topic: String(repeating: "a", count: 161))))
        let subject = try store.createSubject("SUS")
        try store.upsertMistake(QuestionMistake(subjectID: subject, topic: "Princípios"))
        store.deleteSubject(subject)
        XCTAssertEqual(store.mistakes.count, 1)
        XCTAssertNil(store.mistakes.first?.subjectID)
    }

    func testCloudRoundTripKeepsNotebookAndDistinguishesLegacyAbsence() throws {
        let decoder = JSONDecoder()
        let legacy = try decoder.decode(KepleraeCloudState.self, from: Data("{}".utf8))
        XCTAssertNil(legacy.questionMistakes)
        var state = legacy
        state.questionMistakes = [QuestionMistake(topic: "Tema", source: "Livro", location: "Página 32", correctAnswer: "B")]
        let data = try JSONEncoder().encode(state)
        let restored = try decoder.decode(KepleraeCloudState.self, from: data)
        XCTAssertEqual(restored.questionMistakes, state.questionMistakes)
        XCTAssertTrue(restored.hasUserData)
    }
}
