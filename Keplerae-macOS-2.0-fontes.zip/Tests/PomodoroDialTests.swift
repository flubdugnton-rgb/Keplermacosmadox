import XCTest

final class PomodoroDialTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_000)

    func testHandsAdvanceClockwiseAcrossSecondAndMinuteBoundaries() {
        let deadline = now.addingTimeInterval(1500)
        var previous = PomodoroDialReading(totalSeconds: 1500, remainingSeconds: 1500, deadline: deadline, date: now)
        for elapsed in [0.5, 1, 59, 59.9, 60, 60.1, 120, 1499, 1500] {
            let current = PomodoroDialReading(totalSeconds: 1500, remainingSeconds: 1500,
                                              deadline: deadline, date: now.addingTimeInterval(elapsed))
            XCTAssertGreaterThan(current.secondDegrees, previous.secondDegrees)
            XCTAssertGreaterThan(current.minuteDegrees, previous.minuteDegrees)
            XCTAssertGreaterThan(current.hourDegrees, previous.hourDegrees)
            previous = current
        }
        XCTAssertEqual(previous.minuteDegrees, 150)
        XCTAssertEqual(previous.secondDegrees, 9000)
    }

    func testPausedReadingStaysStillAndResumeUsesDeadline() {
        let paused = PomodoroDialReading(totalSeconds: 1500, remainingSeconds: 1440, deadline: nil, date: now)
        let later = PomodoroDialReading(totalSeconds: 1500, remainingSeconds: 1440, deadline: nil, date: now.addingTimeInterval(300))
        XCTAssertEqual(paused.secondDegrees, later.secondDegrees)
        let resumed = PomodoroDialReading(totalSeconds: 1500, remainingSeconds: 1440,
                                         deadline: now.addingTimeInterval(1440), date: now.addingTimeInterval(0.5))
        XCTAssertEqual(resumed.elapsed, 60.5)
    }

    func testNewPhaseResetsAndDeadlineIsClamped() {
        for duration in [300, 900, 1500, 10800] {
            let reset = PomodoroDialReading(totalSeconds: duration, remainingSeconds: duration, deadline: nil, date: now)
            XCTAssertEqual(reset.elapsed, 0)
            let expired = PomodoroDialReading(totalSeconds: duration, remainingSeconds: 0, deadline: now.addingTimeInterval(-5), date: now)
            XCTAssertEqual(expired.elapsed, Double(duration))
        }
    }
}
