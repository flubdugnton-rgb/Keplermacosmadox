import XCTest

@MainActor
final class SessionCredentialLocationTests: XCTestCase {
    func testNewLocationIsAdoptedOnlyAfterTheSessionHasBeenWrittenAndVerified() throws {
        let suite = "CredentialLocationTests.\(UUID().uuidString)"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let location = SessionCredentialLocation(defaults: defaults)
        XCTAssertEqual(location.service, SessionCredentialLocation.legacyService)
        var writtenService: String?
        try location.replaceInaccessibleCredential { service in
            XCTAssertEqual(location.service, SessionCredentialLocation.legacyService)
            XCTAssertTrue(service.hasPrefix(SessionCredentialLocation.legacyService + "."))
            writtenService = service
        }
        XCTAssertEqual(location.service, writtenService)
        XCTAssertEqual(SessionCredentialLocation(defaults: defaults).service, writtenService)
    }

    func testFailedReplacementKeepsThePreviouslySavedLocation() throws {
        enum Failure: Error { case storage }
        let suite = "CredentialLocationTests.\(UUID().uuidString)"
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        let location = SessionCredentialLocation(defaults: defaults)
        try location.replaceInaccessibleCredential { _ in }
        let existing = location.service
        XCTAssertThrowsError(try location.replaceInaccessibleCredential { _ in throw Failure.storage })
        XCTAssertEqual(SessionCredentialLocation(defaults: defaults).service, existing)
    }
}
