import XCTest
import Foundation

@MainActor
final class StreamingTests: XCTestCase {
    func testDeliverySelectionKeepsExistingMaterialsAuthenticatedAndPublicURLsFreeOfTokens() throws {
        let legacy = try JSONDecoder().decode(StudyItem.self, from: Data("""
        {"id":"old","title":"Aula","filename":"aula.mp4","subjectId":"sus","folderPath":[],
         "type":"VIDEO","url":"https://drive.google.com/file/d/abc/view","linkKind":"FILE",
         "driveFileId":"abc","note":"","source":"catalog"}
        """.utf8))
        XCTAssertNil(legacy.mediaDelivery)
        let api = try DriveStreamingPolicy.descriptor(fileID: "abc_123-xyz", accessToken: "synthetic-token", mimeType: "video/mp4", delivery: legacy.mediaDelivery ?? .authenticatedAPI)
        XCTAssertEqual(api.url.host, "www.googleapis.com")
        XCTAssertEqual(api.accessToken, "synthetic-token")
        let publicStream = try DriveStreamingPolicy.descriptor(fileID: "abc_123-xyz", accessToken: "synthetic-token", mimeType: "video/mp4", delivery: .publicDownload)
        XCTAssertEqual(publicStream.url.host, "drive.usercontent.google.com")
        XCTAssertEqual(publicStream.url.path, "/download")
        XCTAssertEqual(URLComponents(url: publicStream.url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: { $0.name == "id" })?.value, "abc_123-xyz")
        XCTAssertTrue(publicStream.accessToken.isEmpty)
        XCTAssertEqual(publicStream.delivery, .publicDownload)
        XCTAssertFalse(publicStream.url.absoluteString.contains("synthetic-token"))
        XCTAssertThrowsError(try DriveStreamingPolicy.descriptor(fileID: "../other?token=x", accessToken: "", mimeType: "video/mp4"))
    }

    func testPublicRangeRequestDoesNotSendAnAuthorizationHeader() async throws {
        let state = RangeProtocolState()
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [RangeTestURLProtocol.self]
        RangeTestURLProtocol.install(state)
        let stream = DriveStreamDescriptor(url: URL(string: "https://stream.test/public.mp4")!, accessToken: "", mimeType: "video/mp4")
        let transport = DriveRangeTransport(stream: stream, configuration: configuration) { throw URLError(.userAuthenticationRequired) }
        defer { transport.cancel(); RangeTestURLProtocol.uninstall() }
        let chunk = try await transport.read(offset: 512, remaining: 4)
        XCTAssertEqual(chunk.data, Data([1, 2, 3, 4]))
        XCTAssertNil(state.requests.first?.value(forHTTPHeaderField: "Authorization"))
        XCTAssertEqual(state.requests.first?.value(forHTTPHeaderField: "Range"), "bytes=512-515")
    }

    func testSeeksAreBoundedAndContentRangeMustMatchTheRequestedRegion() throws {
        let nearStart = DriveStreamingPolicy.range(offset: 0, remaining: 2)
        XCTAssertEqual(nearStart, 0...1)
        let middle = DriveStreamingPolicy.range(offset: 9_000_000, remaining: 100_000_000)
        XCTAssertEqual(middle.lowerBound, 9_000_000)
        XCTAssertEqual(middle.upperBound - middle.lowerBound + 1, Int64(256 * 1024))
        let range = try DriveStreamingPolicy.ContentRange("bytes 9000000-9262143/100000000")
        XCTAssertEqual(range.start, middle.lowerBound)
        XCTAssertEqual(range.end, middle.upperBound)
        XCTAssertEqual(range.total, 100_000_000)
        for header in [nil, "bytes */1000", "bytes 10-2/20", "bytes 0-21/20", "bytes -1-2/20"] {
            XCTAssertThrowsError(try DriveStreamingPolicy.ContentRange(header))
        }
    }

    func testTransportUsesRangesWithoutAnyDiskCacheAndRenewsExpiredToken() async throws {
        let protocolState = RangeProtocolState()
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [RangeTestURLProtocol.self]
        RangeTestURLProtocol.install(protocolState)
        let stream = DriveStreamDescriptor(url: URL(string: "https://stream.test/media.mp4")!, accessToken: "expired-test-token", mimeType: "video/mp4")
        let transport = DriveRangeTransport(stream: stream, configuration: configuration) { "fresh-test-token" }
        defer { transport.cancel(); RangeTestURLProtocol.uninstall() }
        let chunk = try await transport.read(offset: 512, remaining: 4)
        XCTAssertEqual(chunk.data, Data([1, 2, 3, 4]))
        XCTAssertEqual(chunk.range.total, 10_000_000)
        XCTAssertNil(transport.session.configuration.urlCache)
        XCTAssertEqual(protocolState.requests.map { $0.value(forHTTPHeaderField: "Range") }, ["bytes=512-515", "bytes=512-515"])
        XCTAssertEqual(protocolState.requests.last?.value(forHTTPHeaderField: "Authorization"), "Bearer fresh-test-token")
    }

    func testServerReturningAWholeFileIsRejectedBeforeItsBodyIsConsumed() async throws {
        let state = RangeProtocolState(fullFileResponse: true)
        let configuration = URLSessionConfiguration.ephemeral
        configuration.protocolClasses = [RangeTestURLProtocol.self]
        RangeTestURLProtocol.install(state)
        let stream = DriveStreamDescriptor(url: URL(string: "https://stream.test/full.mp4")!, accessToken: "fresh-test-token", mimeType: "video/mp4")
        let transport = DriveRangeTransport(stream: stream, configuration: configuration) { "fresh-test-token" }
        defer { transport.cancel(); RangeTestURLProtocol.uninstall() }
        do {
            _ = try await transport.read(offset: 0, remaining: 2)
            XCTFail("A full-file response must not be accepted as streaming")
        } catch StreamingError.rangeNotSupported {} catch { XCTFail("Unexpected error: \(error)") }
    }
}

private final class RangeProtocolState: @unchecked Sendable {
    private let lock = NSLock()
    private var recorded: [URLRequest] = []
    let fullFileResponse: Bool
    init(fullFileResponse: Bool = false) { self.fullFileResponse = fullFileResponse }
    var requests: [URLRequest] { lock.lock(); defer { lock.unlock() }; return recorded }
    func record(_ request: URLRequest) { lock.lock(); defer { lock.unlock() }; recorded.append(request) }
}

private final class RangeTestURLProtocol: URLProtocol, @unchecked Sendable {
    private static let lock = NSLock()
    nonisolated(unsafe) private static var state: RangeProtocolState?
    static func install(_ value: RangeProtocolState) { lock.lock(); defer { lock.unlock() }; state = value }
    static func uninstall() { lock.lock(); defer { lock.unlock() }; state = nil }
    private static func current() -> RangeProtocolState? { lock.lock(); defer { lock.unlock() }; return state }
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host == "stream.test" }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        guard let state = Self.current(), let url = request.url else { return }
        state.record(request)
        let expired = request.value(forHTTPHeaderField: "Authorization") == "Bearer expired-test-token"
        let status = state.fullFileResponse ? 200 : (expired ? 401 : 206)
        let headers = status == 206 ? ["Content-Type": "video/mp4", "Content-Range": "bytes 512-515/10000000", "Content-Length": "4"] : ["Content-Length": "10000000"]
        let response = HTTPURLResponse(url: url, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers)!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        // Error/full-file responses supply no video body at all.
        if status == 206 { client?.urlProtocol(self, didLoad: Data([1, 2, 3, 4])) }
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}
