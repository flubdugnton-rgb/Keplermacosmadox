import XCTest

final class CloudStateTests: XCTestCase {
    private func decode(_ json: String) throws -> KepleraeCloudState {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(KepleraeCloudState.self, from: Data(json.utf8))
    }

    func testAndroidLegacyMillisecondsAndMissingFields() throws {
        let state = try decode("""
        {"updatedAt": 1700000000000, "favorites": ["lesson-1"], "theme": "DARK"}
        """)
        XCTAssertEqual(state.schemaVersion, 1)
        XCTAssertEqual(state.updatedAt.timeIntervalSince1970, 1700000000, accuracy: 0.001)
        XCTAssertEqual(state.favorites, ["lesson-1"])
        XCTAssertEqual(state.theme, .dark)
        XCTAssertEqual(state.pomodoroSettings.focusMinutes, 25)
        XCTAssertTrue(state.notes.isEmpty)
        XCTAssertTrue(state.hasUserData)
    }

    func testLegacySecondsAndPreferenceBounds() throws {
        let state = try decode("""
        {"updatedAt": 1700000000, "glassIntensity": 200, "theme": "unknown"}
        """)
        XCTAssertEqual(state.updatedAt.timeIntervalSince1970, 1700000000, accuracy: 0.001)
        XCTAssertEqual(state.glassIntensity, 100)
        XCTAssertEqual(state.theme, .system)
        XCTAssertFalse(state.hasUserData)
    }

    func testSchemaTwoPreservesStudyDataOnRoundTrip() throws {
        let tagID = "9B4A1CFB-CA52-4450-A6AA-2C38FE663235"
        let subjectID = "31D563D7-D551-4EBA-BB81-4A242E882E5B"
        let state = try decode("""
        {
          "schemaVersion": 2,
          "updatedAt": "2026-10-12T12:00:00Z",
          "sourcePlatform": "android",
          "googleProjectNumber": "240965240632",
          "favorites": ["lesson-1"], "completed": ["lesson-2"],
          "lastOpenedID": "lesson-2",
          "noteTags": [{"id": "\(tagID)", "name": "Revisão"}],
          "notes": [{"id": "94AF6F2B-F906-41ED-8C84-2D86D69455E8", "title": "Português",
            "body": "Concordância", "tagID": "\(tagID)", "tone": 2,
            "createdAt": "2026-10-11T12:00:00Z", "updatedAt": "2026-10-12T12:00:00Z"}],
          "questionSubjects": [{"id": "\(subjectID)", "name": "SUS"}],
          "questionRecords": [{"id": "5B86C8F2-0A32-4867-A1D4-FF60268904EA",
            "subjectID": "\(subjectID)", "correct": 8, "wrong": 2,
            "recordedAt": "2026-10-12T12:00:00Z"}],
          "pomodoroSettings": {"focusMinutes": 30, "shortMinutes": 5, "longMinutes": 20,
            "cycles": 4, "autoAdvance": true, "sounds": true},
          "pomodoroHistory": [{"id": "2E38B098-B5D1-430C-970B-1BD09311C53D",
            "finishedAt": "2026-10-12T12:00:00Z", "durationSeconds": 1800}],
          "theme": "dark", "glassIntensity": 85
        }
        """)
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        let data = try encoder.encode(state)
        let decoded = try decode(String(decoding: data, as: UTF8.self))
        XCTAssertEqual(decoded.schemaVersion, CrossPlatformOAuth.syncSchemaVersion)
        XCTAssertEqual(decoded.updatedAt, state.updatedAt)
        XCTAssertEqual(decoded.notes, state.notes)
        XCTAssertEqual(decoded.noteTags, state.noteTags)
        XCTAssertEqual(decoded.questionSubjects, state.questionSubjects)
        XCTAssertEqual(decoded.questionRecords, state.questionRecords)
        XCTAssertEqual(decoded.pomodoroSettings, state.pomodoroSettings)
        XCTAssertEqual(decoded.pomodoroHistory, state.pomodoroHistory)
        XCTAssertEqual(decoded.favorites, state.favorites)
        XCTAssertEqual(decoded.completed, state.completed)
        XCTAssertEqual(decoded.lastOpenedID, state.lastOpenedID)
        XCTAssertEqual(decoded.googleProjectNumber, CrossPlatformOAuth.googleProjectNumber)
        XCTAssertTrue(decoded.hasUserData)
    }

    func testSharedCloudFilenameAndNativeMacClient() {
        XCTAssertEqual(CrossPlatformOAuth.syncFileName, "keplerae-sync-v1.json")
        XCTAssertEqual(CrossPlatformOAuth.syncSchemaVersion, 2)
        XCTAssertEqual(CrossPlatformOAuth.nativeClientID, CrossPlatformOAuth.macOSClientID)
        XCTAssertNotEqual(CrossPlatformOAuth.nativeClientID, CrossPlatformOAuth.iOSClientID)
    }
}
