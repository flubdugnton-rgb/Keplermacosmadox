import XCTest
import CoreGraphics

final class PatternAnimationTests: XCTestCase {
    private let p = PatternCardParameters.reference

    func testAll51RequestedDefaultsMatchTheBundledJSON() throws {
        #if SWIFT_PACKAGE
        let bundle = Bundle.module
        #else
        let bundle = Bundle(for: Self.self)
        #endif
        let url = try XCTUnwrap(bundle.url(forResource: "PatternCards.defaults", withExtension: "json"))
        let data = try Data(contentsOf: url)
        XCTAssertEqual((try JSONSerialization.jsonObject(with: data) as? [String: Any])?.count, 51)
        XCTAssertEqual(try PatternCardParameters(flatJSON: data), p)
    }

    func testPatternsKeepTheOriginalArrowCascadeAndPlusGeometry() {
        let counts = [PatternCardVariant.a: 15, .b: 13, .c: 9]
        for variant in PatternCardVariant.allCases {
            let engine = PatternAnimationEngine(variant: variant)
            let frame = engine.frame(time: 0, cursor: nil, centerOffset: .zero, fallHeight: 100,
                                     staticTarget: 1, parameters: p, reducedMotion: true)
            XCTAssertEqual(frame.dots.count, counts[variant])
            XCTAssertTrue(frame.particles.isEmpty)
            XCTAssertTrue(frame.dots.allSatisfy { $0.center.x > 0 && $0.center.x < 127 && $0.center.y > 0 && $0.center.y < 127 })
        }
    }

    func testPointerEnlargesAndSeparatesDotsThenReturnsToGrid() {
        let engine = PatternAnimationEngine(variant: .a, seed: 42)
        let idle = engine.frame(time: 0, cursor: nil, centerOffset: .zero, fallHeight: 100, staticTarget: 1, parameters: p)
        var hovered = idle
        for step in 1...180 {
            hovered = engine.frame(time: Double(step) / 60, cursor: CGPoint(x: 63.5, y: 63.5),
                                   centerOffset: .zero, fallHeight: 100, staticTarget: 1, parameters: p)
        }
        XCTAssertGreaterThan(hovered.dots.map(\.ringRadius).max() ?? 0, (idle.dots.map(\.ringRadius).max() ?? 0) * 1.5)
        XCTAssertTrue(zip(idle.dots, hovered.dots).contains { hypot($0.center.x - $1.center.x, $0.center.y - $1.center.y) > 2 })
        var returned = hovered
        for step in 181...480 {
            returned = engine.frame(time: Double(step) / 60, cursor: nil, centerOffset: .zero,
                                    fallHeight: 100, staticTarget: 1, parameters: p)
        }
        for (original, final) in zip(idle.dots, returned.dots) {
            XCTAssertEqual(original.center.x, final.center.x, accuracy: 0.05)
            XCTAssertEqual(original.center.y, final.center.y, accuracy: 0.05)
            XCTAssertEqual(original.ringRadius, final.ringRadius, accuracy: 0.05)
        }
    }

    func testParticleLifetimeBoundsMemoryAndOpacity() {
        let engine = PatternAnimationEngine(variant: .a)
        var foundParticles = false
        for step in 0...1800 {
            let frame = engine.frame(time: Double(step) / 60, cursor: nil, centerOffset: .zero,
                                     fallHeight: 160, staticTarget: 1, parameters: p)
            foundParticles = foundParticles || !frame.particles.isEmpty
            XCTAssertLessThan(frame.particles.count, 25)
            XCTAssertTrue(frame.particles.allSatisfy { $0.opacity >= 0 && $0.opacity <= p.particles.startOpacity })
            XCTAssertTrue(frame.dots.allSatisfy { $0.center.x.isFinite && $0.center.y.isFinite })
        }
        XCTAssertTrue(foundParticles)
    }
}
