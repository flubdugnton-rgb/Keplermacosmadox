import XCTest

@MainActor
private final class RecordingPomodoroAudio: PomodoroAudioPlaying {
    var ticking = false
    var alarms = 0
    func startTicking(volume: Double) { ticking = true }
    func stopTicking() { ticking = false }
    func playAlarm(volume: Double) { alarms += 1 }
    func stopAll() { ticking = false }
}

final class PomodoroAudioTests: XCTestCase {
    @MainActor func testAudioStartsOnlyWithTimerAndStopsOnPauseAndSkip() {
        let domain = "PomodoroAudioTests.\(UUID())"
        let defaults = UserDefaults(suiteName: domain)!
        defer { defaults.removePersistentDomain(forName: domain) }
        let audio = RecordingPomodoroAudio()
        let store = PomodoroStore(defaults: defaults, soundPlayer: audio)
        store.syncAudio()
        XCTAssertFalse(audio.ticking)
        store.start()
        XCTAssertTrue(audio.ticking)
        store.pause()
        XCTAssertFalse(audio.ticking)
        store.start()
        store.skip()
        XCTAssertFalse(audio.ticking)
        XCTAssertEqual(audio.alarms, 0)
        store.start() // pausa curta não toca tique-taque
        XCTAssertFalse(audio.ticking)
        store.pause()
    }

    @MainActor func testCompletedCycleAlarmsOnceAndMuteSuppressesIt() {
        for muted in [false, true] {
            let domain = "PomodoroAudioTests.\(UUID())"
            let defaults = UserDefaults(suiteName: domain)!
            defer { defaults.removePersistentDomain(forName: domain) }
            defaults.set(!muted, forKey: "pomodoroAmbientEnabled")
            let audio = RecordingPomodoroAudio()
            var date = Date(timeIntervalSince1970: 10000)
            let store = PomodoroStore(defaults: defaults, now: { date }, soundPlayer: audio)
            var settings = PomodoroSettings()
            settings.focusMinutes = 1
            store.configure(settings)
            store.start()
            date = date.addingTimeInterval(61)
            store.tick()
            store.tick()
            XCTAssertEqual(store.history.count, 1)
            XCTAssertEqual(audio.alarms, muted ? 0 : 1)
            XCTAssertFalse(audio.ticking)
        }
    }

    @MainActor func testMuteStopsRunningClockAndResetDoesNotAlarm() {
        let domain = "PomodoroAudioTests.\(UUID())"
        let defaults = UserDefaults(suiteName: domain)!
        defer { defaults.removePersistentDomain(forName: domain) }
        let audio = RecordingPomodoroAudio()
        let store = PomodoroStore(defaults: defaults, soundPlayer: audio)
        store.start()
        defaults.set(false, forKey: "pomodoroAmbientEnabled")
        store.syncAudio()
        XCTAssertFalse(audio.ticking)
        defaults.set(true, forKey: "pomodoroAmbientEnabled")
        store.syncAudio()
        XCTAssertTrue(audio.ticking)
        store.reset()
        XCTAssertFalse(audio.ticking)
        XCTAssertEqual(audio.alarms, 0)
    }
}
