import XCTest

final class StudyNavigationTests: XCTestCase {
    func testHomeClearsSubjectAndEveryNestedFolder() {
        let subject = Subject(id: "sus", title: "SUS", subtitle: "", icon: "cross", monogram: "S")
        var navigation = StudyNavigationState(path: [
            .library(type: nil), .subject(subject, type: nil),
            .folder(subject, type: nil, status: "all", path: ["Bateria"]),
            .folder(subject, type: nil, status: "all", path: ["Bateria", "Clínica"])
        ])
        navigation.returnHome()
        XCTAssertTrue(navigation.path.isEmpty)
        navigation.returnHome()
        XCTAssertTrue(navigation.path.isEmpty)
    }

    func testHomeClearsAnOpenedStudyMaterial() {
        let item = StudyItem(id: "1", title: "Aula", filename: "aula.mp4", subjectID: "sus",
                             folderPath: ["Bateria"], type: .lesson, url: "", linkKind: .file,
                             driveFileID: "id", note: "", source: "test")
        var navigation = StudyNavigationState(path: [.item(item)])
        navigation.returnHome()
        XCTAssertTrue(navigation.path.isEmpty)
    }
}
