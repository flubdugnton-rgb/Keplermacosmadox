streaming-fixture.mp4: trecho de 10 segundos, recortado sem recodificação, usado
somente nos testes do player. Não integra os recursos do aplicativo distribuído.

(c) copyright 2008, Blender Foundation / www.bigbuckbunny.org
Licença Creative Commons Attribution 3.0: https://creativecommons.org/licenses/by/3.0/
Declaração do projeto: https://peach.blender.org/about/
Arquivo de origem: https://github.com/mediaelement/mediaelement-files/blob/master/big_buck_bunny.mp4
