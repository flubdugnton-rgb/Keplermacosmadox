import XCTest

final class MacOAuthConfigurationTests: XCTestCase {
    func testNativeGoogleRedirectUsesTheMacClientAndSingleSlash() {
        XCTAssertEqual(MacOAuthConfiguration.redirectURL.absoluteString,
            "com.googleusercontent.apps.240965240632-g58uffmvvthdqa1mk513fd4k8m8jml2v:/oauthredirect")
        XCTAssertNil(MacOAuthConfiguration.redirectURL.host)
        XCTAssertEqual(MacOAuthConfiguration.authorizationEndpoint.scheme, "https")
        XCTAssertEqual(MacOAuthConfiguration.tokenEndpoint.scheme, "https")
        XCTAssertEqual(MacOAuthConfiguration.userInfoEndpoint.scheme, "https")
    }

    func testCallbacksRejectOtherSchemesAndIncorrectAuthorityOrPath() {
        let scheme = MacOAuthConfiguration.callbackScheme
        XCTAssertTrue(MacOAuthConfiguration.isCallback(URL(string: "\(scheme):/oauth2callback?code=sample&state=sample")!))
        XCTAssertFalse(MacOAuthConfiguration.isCallback(URL(string: "\(scheme)://oauth2callback")!))
        XCTAssertFalse(MacOAuthConfiguration.isCallback(URL(string: "\(scheme):/different-path")!))
        XCTAssertFalse(MacOAuthConfiguration.isCallback(URL(string: "other.application:/oauth2callback")!))
    }

    func testAppDataAndReadScopesAreDistinctAndMustBeGrantedExplicitly() {
        let read = MacOAuthConfiguration.driveReadScope
        let appData = MacOAuthConfiguration.driveAppDataScope
        XCTAssertTrue(MacOAuthConfiguration.requestedScopes.contains(read))
        XCTAssertTrue(MacOAuthConfiguration.requestedScopes.contains(appData))
        XCTAssertFalse(MacOAuthConfiguration.hasScopes([appData], granted: read))
        XCTAssertFalse(MacOAuthConfiguration.hasScopes([read], granted: nil))
        XCTAssertTrue(MacOAuthConfiguration.hasScopes([read, appData], granted: "openid\n\(read)  \(appData)"))
        XCTAssertFalse(MacOAuthConfiguration.hasScopes([read], granted: "\(read).extra"))
    }
}
