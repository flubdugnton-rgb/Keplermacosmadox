import XCTest
import Security
import GTMAppAuth

final class KeychainInteractionTests: XCTestCase {
    func testAutomaticAccessFailsInsteadOfOpeningPasswordPrompt() {
        let helper = NoninteractiveKeychainHelper(keychainAttributes: [.useFileBasedKeychain])
        let query = helper.keychainQuery(forService: "test-service")
        XCTAssertEqual(query[kSecUseAuthenticationUI as String] as? String, kSecUseAuthenticationUIFail as String)
        XCTAssertEqual(query[kSecAttrService as String] as? String, "test-service")
        XCTAssertEqual(query[kSecAttrAccount as String] as? String, "OAuth")
        XCTAssertEqual(query[kSecUseDataProtectionKeychain as String] as? Bool, false)
        // O wrapper não instala ACLs permissivas nem transfere tokens para arquivos.
        XCTAssertNil(query[kSecAttrAccess as String])
        XCTAssertNil(query[kSecAttrAccessGroup as String])
    }

    func testLegacyInteractionFlagIsRestoredEvenWhenTheOperationThrows() throws {
        enum ExpectedFailure: Error { case test }
        let helper = NoninteractiveKeychainHelper(keychainAttributes: [.useFileBasedKeychain])
        var before: DarwinBoolean = false
        XCTAssertEqual(SecKeychainGetUserInteractionAllowed(&before), errSecSuccess)
        XCTAssertThrowsError(try helper.withInteractionDisabled {
            var during: DarwinBoolean = true
            XCTAssertEqual(SecKeychainGetUserInteractionAllowed(&during), errSecSuccess)
            XCTAssertFalse(during.boolValue)
            throw ExpectedFailure.test
        })
        var after: DarwinBoolean = false
        XCTAssertEqual(SecKeychainGetUserInteractionAllowed(&after), errSecSuccess)
        XCTAssertEqual(after.boolValue, before.boolValue)
    }
}

extension KeychainInteractionTests {
    func testExplicitRecoveryKeepsTheExistingACLAndAllowsTheSystemPrompt() {
        let helper = NoninteractiveKeychainHelper(keychainAttributes: [.useFileBasedKeychain], allowsUserInteraction: true)
        let query = helper.keychainQuery(forService: "isolated-test")
        XCTAssertEqual(query[kSecUseAuthenticationUI as String] as? String, kSecUseAuthenticationUIAllow as String)
        XCTAssertNil(query[kSecAttrAccess as String])
        XCTAssertNil(query[kSecAttrAccessGroup as String])
    }

    func testSavedCredentialSurvivesNewStoreInstancesAndTokenUpdates() throws {
        // Only a unique, synthetic item is created; never reads the user's Google session.
        let service = "com.keplerae.test.\(UUID().uuidString)"
        let first = NoninteractiveKeychainHelper(keychainAttributes: [.useFileBasedKeychain])
        defer { try? first.removePassword(forService: service) }
        try first.setPassword("synthetic-session-v1", forService: service)
        let reopened = NoninteractiveKeychainHelper(keychainAttributes: [.useFileBasedKeychain])
        XCTAssertEqual(try reopened.password(forService: service), "synthetic-session-v1")
        try reopened.setPassword("synthetic-session-v2", forService: service)
        let reopenedAgain = NoninteractiveKeychainHelper(keychainAttributes: [.useFileBasedKeychain])
        XCTAssertEqual(try reopenedAgain.password(forService: service), "synthetic-session-v2")
    }
}
