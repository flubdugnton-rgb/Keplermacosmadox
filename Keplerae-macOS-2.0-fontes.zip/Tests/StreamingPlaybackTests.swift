@preconcurrency import AVFoundation
import XCTest

@MainActor
final class StreamingPlaybackTests: XCTestCase {
    func testActualPlayerAdvancesPausesAndContinuesAfterSeeking() async throws {
        let fixtureURL = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "streaming-fixture", withExtension: "mp4"))
        let fixture = try PlaybackFixture(data: Data(contentsOf: fixtureURL), delay: 0.12)
        defer { fixture.remove() }
        let controller = StreamingPlayerController()
        defer { controller.stop() }
        controller.prepare(stream: fixture.stream, configuration: fixture.configuration) { "synthetic-token" }
        try await waitUntil { controller.state == .ready }
        controller.player.isMuted = true
        controller.player.play()
        try await waitUntil { controller.player.currentTime().seconds > 0.6 }
        controller.player.pause()
        let paused = controller.player.currentTime().seconds
        try await Task.sleep(for: .milliseconds(400))
        XCTAssertEqual(controller.player.currentTime().seconds, paused, accuracy: 0.12)
        let sought = await controller.player.seek(to: CMTime(seconds: 4, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero)
        XCTAssertTrue(sought)
        controller.player.play()
        try await waitUntil { controller.player.currentTime().seconds > 4.6 }
        controller.stop()
        XCTAssertNil(controller.player.currentItem)
        XCTAssertTrue(fixture.ranges.allSatisfy { $0.count <= DriveStreamingPolicy.chunkSize })
        XCTAssertFalse(fixture.ranges.isEmpty)
    }

    func testCancellingAReadStopsWaitingForTheNetworkAndDoesNotPoisonTheSession() async throws {
        let fixture = PlaybackFixture(data: Data(repeating: 1, count: 1024), delay: 0.5)
        defer { fixture.remove() }
        let transport = DriveRangeTransport(stream: fixture.stream, configuration: fixture.configuration) { "synthetic-token" }
        defer { transport.cancel() }
        let read = Task { try await transport.read(offset: 0, remaining: 10) }
        try await waitUntil { !fixture.ranges.isEmpty }
        read.cancel()
        do { _ = try await read.value; XCTFail("Cancelled request returned media") }
        catch is CancellationError {} catch { XCTFail("Unexpected error: \(error)") }
        let next = try await transport.read(offset: 512, remaining: 4)
        XCTAssertEqual(next.data, Data(repeating: 1, count: 4))
        XCTAssertEqual(next.range.start, 512)
    }

    private func waitUntil(_ condition: @MainActor () -> Bool) async throws {
        let deadline = Date().addingTimeInterval(12)
        while !condition() {
            guard Date() < deadline else { XCTFail("Player did not progress before timeout"); throw URLError(.timedOut) }
            try await Task.sleep(for: .milliseconds(50))
        }
    }
}

private final class PlaybackFixture: @unchecked Sendable {
    let host = UUID().uuidString.lowercased() + ".test"
    let data: Data
    let delay: TimeInterval
    private let lock = NSLock()
    private var recorded: [Range<Int>] = []
    init(data: Data, delay: TimeInterval) {
        self.data = data; self.delay = delay
        PlaybackFixtureProtocol.install(self)
    }
    var stream: DriveStreamDescriptor { .init(url: URL(string: "https://\(host)/movie.mp4")!, accessToken: "synthetic-token", mimeType: "video/mp4") }
    var configuration: URLSessionConfiguration {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [PlaybackFixtureProtocol.self]
        return config
    }
    var ranges: [Range<Int>] { lock.lock(); defer { lock.unlock() }; return recorded }
    func record(_ range: Range<Int>) { lock.lock(); defer { lock.unlock() }; recorded.append(range) }
    func remove() { PlaybackFixtureProtocol.remove(host) }
}

private final class PlaybackFixtureProtocol: URLProtocol, @unchecked Sendable {
    private static let lock = NSLock()
    nonisolated(unsafe) private static var fixtures: [String: PlaybackFixture] = [:]
    private var delivery: DispatchWorkItem?
    static func install(_ fixture: PlaybackFixture) { lock.lock(); defer { lock.unlock() }; fixtures[fixture.host] = fixture }
    static func remove(_ host: String) { lock.lock(); defer { lock.unlock() }; fixtures.removeValue(forKey: host) }
    private static func fixture(_ host: String) -> PlaybackFixture? { lock.lock(); defer { lock.unlock() }; return fixtures[host] }
    override class func canInit(with request: URLRequest) -> Bool { request.url?.host?.hasSuffix(".test") == true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        guard let url = request.url, let fixture = Self.fixture(url.host ?? ""),
              let header = request.value(forHTTPHeaderField: "Range") else { return }
        let parts = header.dropFirst(6).split(separator: "-")
        guard parts.count == 2, let start = Int(parts[0]), let end = Int(parts[1]), start < fixture.data.count else { return }
        let range = start..<min(end + 1, fixture.data.count)
        fixture.record(range)
        let work = DispatchWorkItem { [weak self] in
            guard let self else { return }
            let response = HTTPURLResponse(url: url, statusCode: 206, httpVersion: "HTTP/1.1", headerFields: [
                "Content-Type": "video/mp4", "Content-Range": "bytes \(range.lowerBound)-\(range.upperBound - 1)/\(fixture.data.count)",
                "Content-Length": "\(range.count)"
            ])!
            self.client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            self.client?.urlProtocol(self, didLoad: fixture.data.subdata(in: range))
            self.client?.urlProtocolDidFinishLoading(self)
        }
        delivery = work
        DispatchQueue.global().asyncAfter(deadline: .now() + fixture.delay, execute: work)
    }
    override func stopLoading() { delivery?.cancel(); delivery = nil }
}
