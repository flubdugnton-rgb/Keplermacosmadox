import XCTest

final class ThemeSelectionTests: XCTestCase {
    func testThreePositionsPreserveSystemAsARealSelection() {
        XCTAssertEqual(ThemeSelection.options, [.light, .system, .dark])
        XCTAssertEqual(ThemeSelection.theme(at: 1), .system)
        XCTAssertEqual(ThemeSelection.theme(at: -10), .light)
        XCTAssertEqual(ThemeSelection.theme(at: 10), .dark)
    }
    func testDragKeepsItsOriginAndClampsAtTheEnds() {
        XCTAssertEqual(ThemeSelection.dragPosition(origin: 1, translation: 0, travel: 150), 1)
        XCTAssertEqual(ThemeSelection.dragPosition(origin: 1, translation: -20, travel: 150), 0.733333333, accuracy: 0.00001)
        XCTAssertEqual(ThemeSelection.dragPosition(origin: 0, translation: 300, travel: 150), 2)
        XCTAssertEqual(ThemeSelection.dragPosition(origin: 2, translation: -300, travel: 150), 0)
        XCTAssertEqual(ThemeSelection.theme(at: 0.49), .light)
        XCTAssertEqual(ThemeSelection.theme(at: 1.4), .system)
        XCTAssertEqual(ThemeSelection.theme(at: 1.51), .dark)
    }
}
