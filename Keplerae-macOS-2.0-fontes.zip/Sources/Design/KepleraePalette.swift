import SwiftUI

struct SubjectPalette {
    let primary: Color
    let secondary: Color
    let pattern: DotPatternKind

    static func forSubject(_ id: String) -> SubjectPalette {
        switch id {
        case "fisioterapia": return .init(primary: .mint, secondary: .teal, pattern: .wave)
        case "portugues": return .init(primary: .pink, secondary: .purple, pattern: .grid)
        case "matematica": return .init(primary: .blue, secondary: .indigo, pattern: .diagonal)
        case "hu_legislacao": return .init(primary: .orange, secondary: .yellow, pattern: .radial)
        case "sus": return .init(primary: .green, secondary: .mint, pattern: .scatter)
        case "profisio": return .init(primary: .purple, secondary: .indigo, pattern: .wave)
        default: return .init(primary: .blue, secondary: .cyan, pattern: .grid)
        }
    }
}

extension StudyContentType {
    var tint: Color {
        switch self {
        case .lesson: return .blue
        case .pdf: return .purple
        case .audio: return .pink
        }
    }
}
