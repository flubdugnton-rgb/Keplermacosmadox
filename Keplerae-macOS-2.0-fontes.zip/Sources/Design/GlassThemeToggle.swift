import SwiftUI

/// Mantém a preferência e a sincronização já usadas pela raiz do aplicativo.
struct ThemeToggleButton: View {
    @AppStorage("appTheme") private var rawTheme = AppTheme.system.rawValue
    @EnvironmentObject private var cloudSync: CloudSyncService

    var body: some View {
        PixelThemeToggle(theme: Binding(
            get: { AppTheme(rawValue: rawTheme) ?? .system },
            set: { value in
                guard rawTheme != value.rawValue else { return }
                rawTheme = value.rawValue
                cloudSync.localDataDidChange()
            }
        ))
    }
}
