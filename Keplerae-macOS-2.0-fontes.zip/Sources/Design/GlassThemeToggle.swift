import Foundation
import SwiftUI

// MARK: - Botão pronto (lê/grava o tema existente e avisa a sincronização)

/// Usa o mesmo `@AppStorage("appTheme")` do RootView e do Perfil, e chama
/// `cloudSync.localDataDidChange()` como o Perfil faz, para o tema continuar sincronizando.
struct ThemeToggleButton: View {
    @AppStorage("appTheme") private var appThemeRaw = AppTheme.system.rawValue
    @Environment(\.colorScheme) private var scheme
    @EnvironmentObject private var cloudSync: CloudSyncService

    private var theme: AppTheme { AppTheme(rawValue: appThemeRaw) ?? .system }

    private var isDark: Bool {
        theme == .dark || (theme == .system && scheme == .dark)
    }

    var body: some View {
        GlassThemeToggle(
            isDark: Binding(
                get: { isDark },
                set: { newValue in
                    appThemeRaw = (newValue ? AppTheme.dark : AppTheme.light).rawValue
                    cloudSync.localDataDidChange()
                }
            )
        )
        .contextMenu {
            Button("Acompanhar o sistema", systemImage: "macbook.and.iphone") {
                appThemeRaw = AppTheme.system.rawValue
                cloudSync.localDataDidChange()
            }
        }
        .help("Alternar tema claro/escuro (clique direito: acompanhar o sistema)")
    }
}

// MARK: - Seletor desenhado em uma única superfície

struct GlassThemeToggle: View {
    @Binding var isDark: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @GestureState private var dragState: ThemeDragState?

    private let travel: CGFloat = 40
    private var restingX: CGFloat { isDark ? travel : 0 }
    private var knobX: CGFloat {
        guard let dragState else { return restingX }
        return min(max(dragState.origin + dragState.translation, 0), travel)
    }

    var body: some View {
        ThemeToggleArtwork(progress: Double(knobX / travel))
            .frame(width: 80, height: 40)
            .animation(dragState == nil && !reduceMotion ? .easeInOut(duration: 0.32) : nil, value: knobX)
            .contentShape(Capsule())
            .gesture(drag.exclusively(before: TapGesture().onEnded { isDark.toggle() }))
            .focusable()
            .onKeyPress(.space) { isDark.toggle(); return .handled }
            .onKeyPress(.return) { isDark.toggle(); return .handled }
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Tema escuro")
            .accessibilityValue(isDark ? "ligado" : "desligado")
            .accessibilityAddTraits(.isButton)
            .accessibilityAction { isDark.toggle() }
    }

    private var drag: some Gesture {
        DragGesture(minimumDistance: 3)
            .updating($dragState) { value, state, _ in
                state = ThemeDragState(origin: state?.origin ?? restingX, translation: value.translation.width)
            }
            .onEnded { value in
                let end = (dragState?.origin ?? restingX) + value.translation.width
                isDark = end > travel / 2
            }
    }
}

private struct ThemeDragState {
    let origin: CGFloat
    let translation: CGFloat
}

/// Cores explícitas: nenhum material nativo, imagem de máscara ou 81 subviews
/// reconfigurados enquanto o macOS troca a aparência da janela.
private struct ThemeToggleArtwork: View, Animatable {
    var progress: Double
    nonisolated var animatableData: Double {
        get { progress }
        set { progress = newValue }
    }

    var body: some View {
        let p = min(max(progress, 0), 1)
        Canvas { context, size in
            let bounds = CGRect(origin: .zero, size: size)
            let track = Path(roundedRect: bounds.insetBy(dx: 0.5, dy: 0.5), cornerRadius: size.height / 2)
            context.fill(track, with: .linearGradient(
                Gradient(colors: [mix((0.79, 0.91, 0.98), (0.14, 0.20, 0.38), p),
                                  mix((0.94, 0.97, 1.0), (0.24, 0.30, 0.49), p)]),
                startPoint: .zero, endPoint: CGPoint(x: size.width, y: size.height)
            ))
            context.stroke(track, with: .color(.white.opacity(0.65)), lineWidth: 1)
            let thumb = CGRect(x: 4 + 40 * p, y: 4, width: 32, height: 32)
            // Sombra fica confinada ao botão, sem camadas pretas atravessando a trilha.
            var shadow = context
            shadow.addFilter(.shadow(color: .black.opacity(0.16), radius: 2, x: 0, y: 1))
            shadow.fill(Path(ellipseIn: thumb), with: .color(mix((1, 1, 1), (0.22, 0.27, 0.42), p)))
            context.stroke(Path(ellipseIn: thumb.insetBy(dx: 0.5, dy: 0.5)), with: .color(.white.opacity(0.6)), lineWidth: 1)

            for y in 0..<9 {
                for x in 0..<9 {
                    let sun = Self.sun(x, y)
                    let moon = Self.moon(x, y)
                    let phase = min(max((p * 1.32) - Double(x + y) * 0.02, 0), 1)
                    let visibility = (sun ? 1.0 - phase : 0) + (moon ? phase : 0)
                    guard visibility > 0.01 else { continue }
                    let radius = 1.1 * sqrt(visibility)
                    let point = CGPoint(x: thumb.midX + Double(x - 4) * 2.9,
                                        y: thumb.midY + Double(y - 4) * 2.9)
                    let dot = CGRect(x: point.x - radius, y: point.y - radius, width: radius * 2, height: radius * 2)
                    context.fill(Path(ellipseIn: dot), with: .color(mix((0.96, 0.56, 0.12), (0.94, 0.97, 1), p).opacity(visibility)))
                }
            }
        }
        .accessibilityHidden(true)
    }

    private func mix(_ day: (Double, Double, Double), _ night: (Double, Double, Double), _ p: Double) -> Color {
        Color(red: day.0 + (night.0 - day.0) * p,
              green: day.1 + (night.1 - day.1) * p,
              blue: day.2 + (night.2 - day.2) * p)
    }

    private static func moon(_ x: Int, _ y: Int) -> Bool {
        hypot(Double(x) - 4, Double(y) - 4) <= 3.7 && hypot(Double(x) - 5.9, Double(y) - 2.6) > 3.1
    }

    private static func sun(_ x: Int, _ y: Int) -> Bool {
        if hypot(Double(x) - 4, Double(y) - 4) <= 2.1 { return true }
        return [(4, 0), (4, 8), (0, 4), (8, 4), (1, 1), (7, 1), (1, 7), (7, 7)].contains { $0.0 == x && $0.1 == y }
    }
}
