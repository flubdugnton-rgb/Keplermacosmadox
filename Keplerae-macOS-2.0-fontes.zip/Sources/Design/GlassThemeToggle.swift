import Foundation
import SwiftUI

// MARK: - Botão pronto (lê/grava o tema existente e avisa a sincronização)

/// Usa o mesmo `@AppStorage("appTheme")` do RootView e do Perfil, e chama
/// `cloudSync.localDataDidChange()` como o Perfil faz, para o tema continuar sincronizando.
struct ThemeToggleButton: View {
    @AppStorage("appTheme") private var appThemeRaw = AppTheme.system.rawValue
    @Environment(\.colorScheme) private var scheme
    @EnvironmentObject private var cloudSync: CloudSyncService

    private var theme: AppTheme { AppTheme(rawValue: appThemeRaw) ?? .system }

    private var isDark: Bool {
        theme == .dark || (theme == .system && scheme == .dark)
    }

    var body: some View {
        GlassThemeToggle(
            isDark: Binding(
                get: { isDark },
                set: { newValue in
                    appThemeRaw = (newValue ? AppTheme.dark : AppTheme.light).rawValue
                    cloudSync.localDataDidChange()
                }
            )
        )
        .contextMenu {
            Button("Acompanhar o sistema", systemImage: "macbook.and.iphone") {
                appThemeRaw = AppTheme.system.rawValue
                cloudSync.localDataDidChange()
            }
        }
        .help("Alternar tema claro/escuro (clique direito: acompanhar o sistema)")
    }
}

// MARK: - Toggle de vidro (arrasta ou clica)

struct GlassThemeToggle: View {
    @Binding var isDark: Bool

    private let trackW: CGFloat = 80
    private let trackH: CGFloat = 40
    private let knob: CGFloat = 32

    private struct DragState {
        let origin: CGFloat
        let translation: CGFloat
    }

    // O estado do gesto também é limpo quando o arraste é cancelado.
    @GestureState private var dragState: DragState?

    private var pad: CGFloat { (trackH - knob) / 2 }
    private var travel: CGFloat { trackW - knob - pad * 2 }
    private var restingX: CGFloat { isDark ? travel : 0 }
    private var knobX: CGFloat {
        guard let dragState else { return restingX }
        return min(max(dragState.origin + dragState.translation, 0), travel)
    }
    private var darkness: Double { min(max(Double(knobX / travel), 0), 1) }

    var body: some View {
        let night = dragState == nil ? isDark : darkness > 0.5

        ZStack(alignment: .leading) {
            // céu: dia -> noite acompanha o botão
            Capsule()
                .fill(Color(red: 0.55, green: 0.78, blue: 1.0).opacity(0.30 * (1 - darkness)))
            Capsule()
                .fill(Color(red: 0.10, green: 0.12, blue: 0.30).opacity(0.60 * darkness))
        }
        .frame(width: trackW, height: trackH)
        .glassEffect(.regular, in: Capsule())
        // O botão fica acima do material, com tamanho e alinhamento estáveis.
        .overlay(alignment: .leading) {
            knobView(night: night)
                .offset(x: pad + knobX)
        }
        // luz na borda
        .overlay(
            Capsule().strokeBorder(
                LinearGradient(
                    colors: [.white.opacity(0.75), .white.opacity(0.05), .white.opacity(0.35)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                lineWidth: 1
            )
        )
        .contentShape(Capsule())
        // Anima apenas o controle; a troca do tema da janela não herda a animação.
        .animation(dragState == nil ? .easeInOut(duration: 0.24) : nil, value: knobX)
        .gesture(drag.exclusively(before: TapGesture().onEnded { isDark.toggle() }))
        .accessibilityElement()
        .accessibilityLabel("Tema escuro")
        .accessibilityValue(isDark ? "ligado" : "desligado")
        .accessibilityAddTraits(.isButton)
        .accessibilityAction { isDark.toggle() }
    }

    private var drag: some Gesture {
        DragGesture(minimumDistance: 3)
            .updating($dragState) { value, state, _ in
                state = DragState(
                    origin: state?.origin ?? restingX,
                    translation: value.translation.width
                )
            }
            .onEnded { value in
                let origin = dragState?.origin ?? restingX
                let end = min(max(origin + value.translation.width, 0), travel)
                isDark = end > travel / 2
            }
    }

    private func knobView(night: Bool) -> some View {
        ZStack {
            Circle().fill(night ? Color(white: 0.16) : Color.white)
            Circle().strokeBorder(.white.opacity(night ? 0.18 : 0.9), lineWidth: 1)
            PixelGlyph(night: night)
        }
        .frame(width: knob, height: knob)
        .shadow(color: .black.opacity(0.25), radius: 5, y: 2)
        .animation(.smooth(duration: 0.3), value: night)
    }
}

// MARK: - Ícone de pixels: a lua se reconstrói em sol

private struct PixelGlyph: View {
    let night: Bool

    private let n = 9
    private let step: CGFloat = 2.9
    private let dot: CGFloat = 2.2

    var body: some View {
        ZStack {
            ForEach(0..<(n * n), id: \.self) { i in
                let x = i % n
                let y = i / n
                let on = night ? pixelIsMoon(x, y) : pixelIsSun(x, y)

                Circle()
                    .frame(width: dot, height: dot)
                    .scaleEffect(on ? 1 : 0.01)
                    // atraso pela diagonal: os pontos "se reorganizam" em onda
                    .animation(
                        .spring(response: 0.38, dampingFraction: 0.6).delay(Double(x + y) * 0.02),
                        value: night
                    )
                    .position(x: (CGFloat(x) + 0.5) * step, y: (CGFloat(y) + 0.5) * step)
            }
        }
        .frame(width: CGFloat(n) * step, height: CGFloat(n) * step)
        .foregroundStyle(night ? Color.white : Color(red: 0.96, green: 0.56, blue: 0.12))
    }
}

// grade 9x9, centro em (4, 4)
private func pixelIsMoon(_ x: Int, _ y: Int) -> Bool {
    let px = Double(x), py = Double(y)
    let outer = hypot(px - 4, py - 4) <= 3.7
    let cut = hypot(px - 5.9, py - 2.6) <= 3.1
    return outer && !cut
}

private func pixelIsSun(_ x: Int, _ y: Int) -> Bool {
    if hypot(Double(x) - 4, Double(y) - 4) <= 2.1 { return true }
    let rays = [(4, 0), (4, 8), (0, 4), (8, 4), (1, 1), (7, 1), (1, 7), (7, 7)]
    return rays.contains { $0.0 == x && $0.1 == y }
}
