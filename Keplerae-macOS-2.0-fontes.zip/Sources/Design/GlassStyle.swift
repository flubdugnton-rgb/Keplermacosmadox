import SwiftUI

struct KepleraeGlassModifier: ViewModifier {
    let intensity: Double
    let cornerRadius: CGFloat
    let interactive: Bool
    let animatedPattern: Bool
    @State private var cursor: CGPoint?

    func body(content: Content) -> some View {
        let normalized = min(max(intensity, 0), 1)
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        let material: Glass = {
            if normalized <= 0.05 { return .identity }
            if normalized < 0.45 { return .clear }
            return .regular
        }()

        content
            .background {
                if animatedPattern { PatternCardDecoration(cursor: cursor).clipShape(shape) }
            }
            .glassEffect(material.interactive(interactive), in: shape)
            .overlay {
                shape.stroke(
                    Color.white.opacity(0.06 + (0.24 * normalized)),
                    lineWidth: 0.7 + (0.8 * normalized)
                )
            }
            .onContinuousHover { phase in
                switch phase {
                case .active(let location): cursor = location
                case .ended: cursor = nil
                }
            }
            .shadow(
                color: Color.black.opacity(0.03 + (0.11 * normalized)),
                radius: 2 + (7 * normalized),
                y: 1 + (3 * normalized)
            )
    }
}

extension View {
    func kepleraeGlass(
        intensity: Double,
        cornerRadius: CGFloat = 28,
        interactive: Bool = true,
        animatedPattern: Bool = true
    ) -> some View {
        modifier(
            KepleraeGlassModifier(
                intensity: intensity,
                cornerRadius: cornerRadius,
                interactive: interactive,
                animatedPattern: animatedPattern
            )
        )
    }
}
