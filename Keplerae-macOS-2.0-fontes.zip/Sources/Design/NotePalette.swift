import SwiftUI

enum NotePalette {
    // Os primeiros cinco índices mantêm as cores das notas existentes.
    static let colors: [Color] = [.yellow, .mint, .cyan, .purple, .orange, .pink, .blue, .green, .red, .brown]
    static let names = ["Amarelo", "Menta", "Ciano", "Roxo", "Laranja", "Rosa", "Azul", "Verde", "Vermelho", "Marrom"]

    static func normalizedIndex(_ value: Int) -> Int { min(max(value, 0), colors.count - 1) }
    static func color(for value: Int) -> Color { colors[normalizedIndex(value)] }
}
