import Combine
import Foundation

@MainActor
final class PomodoroStore: ObservableObject {
    @Published var settings: PomodoroSettings
    @Published private(set) var phase: PomodoroPhase
    @Published private(set) var running: Bool
    @Published private(set) var remainingSeconds: Int
    @Published private(set) var cycle: Int
    @Published private(set) var history: [FocusRecord]

    private let defaults: UserDefaults
    private let now: () -> Date
    private let soundPlayer: any PomodoroAudioPlaying
    private var timer: Timer?
    private var deadline: Date?

    /// Fim previsto da fase em andamento (nil quando pausado). O dial usa para animar o ponteiro com suavidade.
    var phaseDeadline: Date? { running ? deadline : nil }
    private let key = "keplerae.pomodoro.v1"

    private struct Payload: Codable {
        var settings: PomodoroSettings
        var phase: PomodoroPhase
        var running: Bool
        var remainingSeconds: Int
        var cycle: Int
        var history: [FocusRecord]
        var deadline: Date?
    }

    init(defaults: UserDefaults = .standard, now: @escaping () -> Date = Date.init,
         soundPlayer: (any PomodoroAudioPlaying)? = nil) {
        self.defaults = defaults
        self.now = now
        self.soundPlayer = soundPlayer ?? PomodoroSoundPlayer()
        if let data = defaults.data(forKey: key), let p = try? JSONDecoder().decode(Payload.self, from: data) {
            settings = p.settings; phase = p.phase; running = p.running; remainingSeconds = p.remainingSeconds
            cycle = p.cycle; history = p.history; deadline = p.deadline
        } else {
            settings = PomodoroSettings(); phase = .focus; running = false; remainingSeconds = 25 * 60; cycle = 0; history = []; deadline = nil
        }
        if running { startTicker(); tick(allowAlarm: false) }
    }

    func start() {
        guard !running else { return }
        running = true
        deadline = now().addingTimeInterval(TimeInterval(remainingSeconds))
        syncAudio(); startTicker(); save()
    }

    func pause() { tick(); soundPlayer.stopAll(); running = false; timer?.invalidate(); timer = nil; deadline = nil; save() }

    func reset() {
        soundPlayer.stopAll()
        running = false; timer?.invalidate(); timer = nil; deadline = nil
        remainingSeconds = settings.minutes(for: phase) * 60; save()
    }

    func skip() {
        soundPlayer.stopAll()
        running = false; timer?.invalidate(); timer = nil; deadline = nil
        phase = phase == .focus ? .shortBreak : .focus
        remainingSeconds = settings.minutes(for: phase) * 60; save()
    }

    func configure(_ value: PomodoroSettings) {
        settings = value
        if !running { phase = .focus; cycle = 0; remainingSeconds = value.focusMinutes * 60 }
        syncAudio(); save()
    }

    func replace(settings: PomodoroSettings, history: [FocusRecord]) { self.settings = settings; self.history = history; reset() }

    private func startTicker() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in Task { @MainActor [weak self] in self?.tick() } }
    }

    func tick(allowAlarm: Bool = true) {
        guard running, let deadline else { return }
        remainingSeconds = max(0, Int(ceil(deadline.timeIntervalSince(now()))))
        if remainingSeconds == 0 { finishPhase(allowAlarm: allowAlarm) }
    }

    private func finishPhase(allowAlarm: Bool) {
        let finished = phase
        if finished == .focus {
            history.append(FocusRecord(id: UUID(), finishedAt: now(), durationSeconds: settings.focusMinutes * 60))
            cycle += 1
            phase = cycle >= settings.cycles ? .longBreak : .shortBreak
        } else {
            if finished == .longBreak { cycle = 0 }
            phase = .focus
        }
        running = false; timer?.invalidate(); timer = nil; deadline = nil
        remainingSeconds = settings.minutes(for: phase) * 60
        soundPlayer.stopTicking()
        if allowAlarm && audioEnabled && settings.sounds { soundPlayer.playAlarm(volume: audioVolume) }
        save()
        if settings.autoAdvance { start() }
    }

    private var audioEnabled: Bool {
        (defaults.object(forKey: "pomodoroAmbientEnabled") as? Bool) ?? true
    }
    private var audioVolume: Double {
        (defaults.object(forKey: "pomodoroAmbientVolume") as? Double) ?? 0.35
    }

    /// Abertura de telas nunca inicia o cronômetro. Mudo desliga também o alarme.
    func syncAudio() {
        guard audioEnabled else { soundPlayer.stopAll(); return }
        if running && phase == .focus { soundPlayer.startTicking(volume: audioVolume) }
        else { soundPlayer.stopTicking() }
    }

    private func save() {
        let payload = Payload(settings: settings, phase: phase, running: running, remainingSeconds: remainingSeconds,
                              cycle: cycle, history: history, deadline: deadline)
        if let data = try? JSONEncoder().encode(payload) {
            defaults.set(data, forKey: key)
            NotificationCenter.default.post(name: .kepleraeDataDidChange, object: nil)
        }
    }
}
