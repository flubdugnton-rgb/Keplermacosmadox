import Combine
import Foundation

private struct ResolvedDriveFile: Sendable {
    let id: String
    let mimeType: String
}

private struct DriveFileListResponse: Decodable, Sendable {
    let files: [DriveFileMetadata]
}

private struct DriveFileMetadata: Decodable, Sendable {
    let id: String
    let name: String
    let mimeType: String?
}

@MainActor
final class DriveContentLoader: ObservableObject {
    enum PreparedContent: Equatable {
        case local(URL)
        case stream(DriveStreamDescriptor)
    }

    enum State: Equatable {
        case idle
        case loading
        case ready(PreparedContent)
        case failed(String)
    }

    @Published private(set) var state: State = .idle

    /// PDFs use a bounded document cache. Media is streamed and never written here.
    /// Remove legacy audio/video cache files from older versions on launch.
    nonisolated static func cleanupCache() {
        cleanupCache(excluding: nil)
    }

    nonisolated private static func cleanupCache(excluding protectedURL: URL?) {
        let fileManager = FileManager.default
        guard let base = fileManager.urls(for: .cachesDirectory, in: .userDomainMask).first else { return }
        let directory = base.appendingPathComponent("KepleraeDrive", isDirectory: true)
        guard fileManager.fileExists(atPath: directory.path) else { return }

        let maxAge: TimeInterval = 7 * 24 * 60 * 60
        let maxBytes: Int64 = 1_500_000_000
        let cutoff = Date().addingTimeInterval(-maxAge)
        let keys: Set<URLResourceKey> = [.contentModificationDateKey, .fileSizeKey, .isRegularFileKey]

        guard let urls = try? fileManager.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: Array(keys),
            options: [.skipsHiddenFiles]
        ) else { return }

        struct Entry {
            let url: URL
            let date: Date
            let size: Int64
        }

        var entries: [Entry] = []
        for url in urls {
            guard url != protectedURL,
                  let values = try? url.resourceValues(forKeys: keys),
                  values.isRegularFile == true else { continue }

            if url.pathExtension.lowercased() != "pdf" {
                try? fileManager.removeItem(at: url)
                continue
            }
            let date = values.contentModificationDate ?? .distantPast
            let size = Int64(values.fileSize ?? 0)

            if date < cutoff {
                try? fileManager.removeItem(at: url)
            } else {
                entries.append(Entry(url: url, date: date, size: size))
            }
        }

        var total = entries.reduce(Int64(0)) { $0 + $1.size }
        if total > maxBytes {
            for entry in entries.sorted(by: { $0.date < $1.date }) where total > maxBytes {
                if (try? fileManager.removeItem(at: entry.url)) != nil {
                    total -= entry.size
                }
            }
        }
    }

    func load(item: StudyItem, auth: GoogleAuthStore) async {
        if case .ready = state { return }
        state = .loading

        do {
            guard !item.driveFileID.isEmpty else {
                throw DriveContentError.missingFileID
            }

            let token = try await auth.freshDriveAccessToken()
            guard !Task.isCancelled else { return }

            let resolved = try await Self.resolve(item: item, accessToken: token)
            guard !Task.isCancelled else { return }

            switch item.type {
            case .lesson, .audio:
                state = .ready(.stream(try Self.streamDescriptor(
                    fileID: resolved.id,
                    accessToken: token,
                    mimeType: resolved.mimeType,
                    delivery: item.mediaDelivery ?? .authenticatedAPI
                )))

            case .pdf:
                let localURL = try await Self.downloadResolved(
                    item: item,
                    resolvedFileID: resolved.id,
                    accessToken: token
                )
                guard !Task.isCancelled else { return }
                state = .ready(.local(localURL))
            }
        } catch is CancellationError {
            return
        } catch {
            state = .failed(error.localizedDescription)
        }
    }

    func reset() {
        state = .idle
    }

    nonisolated static func streamDescriptor(
        fileID: String,
        accessToken: String,
        mimeType: String,
        delivery: DriveMediaDelivery = .authenticatedAPI
    ) throws -> DriveStreamDescriptor {
        try DriveStreamingPolicy.descriptor(fileID: fileID, accessToken: accessToken, mimeType: mimeType, delivery: delivery)
    }

    /// Resolves a playable file. Direct links already carry a file ID. Folder-backed
    /// catalog rows (used heavily by Português) are resolved by filename inside the
    /// authenticated Drive folder, so the catalog can preserve the real course structure.
    nonisolated private static func resolve(item: StudyItem, accessToken: String) async throws -> ResolvedDriveFile {
        switch item.linkKind {
        case .file:
            return ResolvedDriveFile(
                id: item.driveFileID,
                mimeType: fallbackMimeType(for: item)
            )

        case .folder:
            guard !item.filename.isEmpty else {
                throw DriveContentError.missingFilename
            }

            if let exact = try await findFile(
                folderID: item.driveFileID,
                filename: item.filename,
                accessToken: accessToken,
                exactName: true
            ) {
                return ResolvedDriveFile(
                    id: exact.id,
                    mimeType: exact.mimeType ?? fallbackMimeType(for: item)
                )
            }

            // Fallback for Drive folders whose files were renamed only by capitalization,
            // spaces or extension case after the spreadsheet was produced.
            if let loose = try await findFile(
                folderID: item.driveFileID,
                filename: item.filename,
                accessToken: accessToken,
                exactName: false
            ) {
                return ResolvedDriveFile(
                    id: loose.id,
                    mimeType: loose.mimeType ?? fallbackMimeType(for: item)
                )
            }

            throw DriveContentError.fileNotFoundInFolder(item.filename)
        }
    }

    nonisolated private static func findFile(
        folderID: String,
        filename: String,
        accessToken: String,
        exactName: Bool
    ) async throws -> DriveFileMetadata? {
        guard var components = URLComponents(string: "https://www.googleapis.com/drive/v3/files") else {
            throw DriveContentError.invalidURL
        }

        let escapedFolder = driveQueryLiteral(folderID)
        let escapedName = driveQueryLiteral(filename)
        var query = "'\(escapedFolder)' in parents and trashed = false"
        if exactName {
            query += " and name = '\(escapedName)'"
        }

        components.queryItems = [
            URLQueryItem(name: "q", value: query),
            URLQueryItem(name: "fields", value: "files(id,name,mimeType)"),
            URLQueryItem(name: "pageSize", value: exactName ? "10" : "1000"),
            URLQueryItem(name: "includeItemsFromAllDrives", value: "true"),
            URLQueryItem(name: "supportsAllDrives", value: "true")
        ]

        guard let url = components.url else {
            throw DriveContentError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 30
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw DriveContentError.invalidResponse
        }
        guard (200...299).contains(http.statusCode) else {
            throw DriveContentError.httpStatus(http.statusCode)
        }

        let decoded = try JSONDecoder().decode(DriveFileListResponse.self, from: data)

        if exactName {
            return decoded.files.first
        }

        let wanted = normalizedFilename(filename)
        return decoded.files.first { normalizedFilename($0.name) == wanted }
    }

    nonisolated private static func downloadResolved(
        item: StudyItem,
        resolvedFileID: String,
        accessToken: String
    ) async throws -> URL {
        guard item.type == .pdf else { throw StreamingError.rangeNotSupported }
        cleanupCache()
        let fileManager = FileManager.default
        let directory = fileManager.urls(for: .cachesDirectory, in: .userDomainMask).first!
            .appendingPathComponent("KepleraeDrive", isDirectory: true)
        try fileManager.createDirectory(at: directory, withIntermediateDirectories: true)

        let ext = preferredExtension(for: item)
        let destination = directory.appendingPathComponent("\(resolvedFileID).\(ext)")

        if fileManager.fileExists(atPath: destination.path),
           let values = try? destination.resourceValues(forKeys: [.fileSizeKey]),
           (values.fileSize ?? 0) > 0 {
            try? fileManager.setAttributes([.modificationDate: Date()], ofItemAtPath: destination.path)
            return destination
        }

        guard let encodedID = resolvedFileID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "https://www.googleapis.com/drive/v3/files/\(encodedID)?alt=media&supportsAllDrives=true") else {
            throw DriveContentError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 180
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/octet-stream", forHTTPHeaderField: "Accept")
        request.cachePolicy = .reloadRevalidatingCacheData

        let configuration = URLSessionConfiguration.default
        configuration.urlCache = URLCache(
            memoryCapacity: 24 * 1024 * 1024,
            diskCapacity: 512 * 1024 * 1024
        )
        configuration.timeoutIntervalForRequest = 180
        configuration.timeoutIntervalForResource = 60 * 60
        let session = URLSession(configuration: configuration)

        let (temporaryURL, response) = try await session.download(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw DriveContentError.invalidResponse
        }
        guard (200...299).contains(http.statusCode) else {
            throw DriveContentError.httpStatus(http.statusCode)
        }

        if fileManager.fileExists(atPath: destination.path) {
            try? fileManager.removeItem(at: destination)
        }
        try fileManager.moveItem(at: temporaryURL, to: destination)
        try? fileManager.setAttributes([.modificationDate: Date()], ofItemAtPath: destination.path)
        cleanupCache(excluding: destination)
        return destination
    }

    nonisolated private static func preferredExtension(for item: StudyItem) -> String {
        let existing = (item.filename as NSString).pathExtension
        if !existing.isEmpty { return existing.lowercased() }

        switch item.type {
        case .lesson: return "mp4"
        case .pdf: return "pdf"
        case .audio: return "mp3"
        }
    }

    nonisolated private static func fallbackMimeType(for item: StudyItem) -> String {
        let ext = preferredExtension(for: item)
        switch ext {
        case "mp4", "m4v", "mov": return "video/mp4"
        case "mp3": return "audio/mpeg"
        case "m4a", "aac": return "audio/mp4"
        case "wav": return "audio/wav"
        case "pdf": return "application/pdf"
        default:
            switch item.type {
            case .lesson: return "video/mp4"
            case .pdf: return "application/pdf"
            case .audio: return "audio/mpeg"
            }
        }
    }

    nonisolated private static func normalizedFilename(_ value: String) -> String {
        value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)
            .replacingOccurrences(of: " ", with: "")
    }

    nonisolated private static func driveQueryLiteral(_ value: String) -> String {
        value
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")
    }
}

enum DriveContentError: LocalizedError {
    case missingFileID
    case missingFilename
    case invalidURL
    case invalidResponse
    case httpStatus(Int)
    case fileNotFoundInFolder(String)

    var errorDescription: String? {
        switch self {
        case .missingFileID:
            return "Este material não possui um ID válido do Google Drive."
        case .missingFilename:
            return "Este material não possui nome de arquivo para localizar dentro da pasta."
        case .invalidURL:
            return "Não foi possível montar o endereço deste material."
        case .invalidResponse:
            return "O Google Drive retornou uma resposta inválida."
        case .httpStatus(let code):
            if code == 401 { return "A sessão do Google expirou. Abra o material novamente." }
            if code == 403 { return "Sua conta não tem permissão para ler este arquivo do Google Drive." }
            if code == 404 { return "O arquivo não foi encontrado no Google Drive." }
            return "Não foi possível carregar o material do Google Drive (erro \(code))."
        case .fileNotFoundInFolder(let filename):
            return "Não encontrei \(filename) dentro da pasta indicada no Google Drive."
        }
    }
}
