import Combine
import Foundation

/// Uma revisão agendada para um material já concluído.
struct ReviewEntry: Identifiable, Hashable, Codable {
    let itemID: String
    /// Índice da próxima revisão em `ReviewStore.intervalsInDays` (0 = 1ª revisão).
    var step: Int
    var dueDate: Date

    var id: String { itemID }
}

/// Revisão espaçada: ao concluir um material, agenda revisões após 1, 7 e 30 dias.
///
/// Os dados ficam só neste Mac (UserDefaults). Não entram no `keplerae-sync-v1.json`,
/// então o contrato de sincronização com Android/iOS não muda.
@MainActor
final class ReviewStore: ObservableObject {
    static let intervalsInDays = [1, 7, 30]

    @Published private(set) var entries: [ReviewEntry] = []

    private let key = "keplerae.reviews.v1"

    init() { load() }

    /// Agenda a 1ª revisão quando o material é concluído.
    func schedule(_ itemID: String, from date: Date = .now) {
        guard !entries.contains(where: { $0.itemID == itemID }) else { return }
        entries.append(ReviewEntry(itemID: itemID, step: 0, dueDate: dueDate(afterDays: Self.intervalsInDays[0], from: date)))
        save()
    }

    /// Material desmarcado como concluído: cancela as revisões.
    func cancel(_ itemID: String) {
        entries.removeAll { $0.itemID == itemID }
        save()
    }

    /// Revisões que já venceram (ou vencem hoje), as mais antigas primeiro.
    func due(on date: Date = .now) -> [ReviewEntry] {
        entries.filter { $0.dueDate <= date }.sorted { $0.dueDate < $1.dueDate }
    }

    /// "Revisei": avança para o próximo intervalo; depois do último, encerra o ciclo.
    func markReviewed(_ itemID: String, on date: Date = .now) {
        guard let index = entries.firstIndex(where: { $0.itemID == itemID }) else { return }
        let next = entries[index].step + 1
        if next < Self.intervalsInDays.count {
            entries[index].step = next
            entries[index].dueDate = dueDate(afterDays: Self.intervalsInDays[next], from: date)
        } else {
            entries.remove(at: index)
        }
        save()
    }

    /// "Esqueci": volta para o intervalo de 1 dia.
    func markForgotten(_ itemID: String, on date: Date = .now) {
        guard let index = entries.firstIndex(where: { $0.itemID == itemID }) else { return }
        entries[index].step = 0
        entries[index].dueDate = dueDate(afterDays: Self.intervalsInDays[0], from: date)
        save()
    }

    // MARK: - Interno

    /// Vence às 00:00 do dia alvo, para aparecer logo de manhã.
    private func dueDate(afterDays days: Int, from date: Date) -> Date {
        let calendar = Calendar.current
        let target = calendar.date(byAdding: .day, value: days, to: date) ?? date
        return calendar.startOfDay(for: target)
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode([ReviewEntry].self, from: data) else { return }
        entries = decoded
    }

    private func save() {
        if let data = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
