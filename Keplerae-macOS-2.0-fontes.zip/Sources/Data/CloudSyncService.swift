import Combine
import Foundation

extension Notification.Name {
    static let kepleraeDataDidChange = Notification.Name("keplerae.data.didChange")
}

@MainActor
final class CloudSyncService: ObservableObject {
    @Published private(set) var status: CloudSyncStatus = .idle
    @Published private(set) var lastSyncDate: Date?

    private let fileName = CrossPlatformOAuth.syncFileName
    private let localModifiedKey = "keplerae.cloud.localModifiedAt"
    private let deviceIDKey = "keplerae.cloud.deviceID"

    private var auth: GoogleAuthStore?
    private var studyState: StudyStateStore?
    private var notes: NotesStore?
    private var questions: QuestionsStore?
    private var pomodoro: PomodoroStore?
    private var cloudFileID: String?
    private var uploadTask: Task<Void, Never>?
    private var automaticRefreshTask: Task<Void, Never>?
    private var isApplyingRemote = false
    private var isBootstrapped = false
    private var appIsActive = false
    private var networkSyncInProgress = false
    private var pendingReconcile = false
    private var accountEmail = ""

    func bootstrap(
        auth: GoogleAuthStore,
        studyState: StudyStateStore,
        notes: NotesStore,
        questions: QuestionsStore,
        pomodoro: PomodoroStore
    ) async {
        self.auth = auth
        self.studyState = studyState
        self.notes = notes
        self.questions = questions
        self.pomodoro = pomodoro

        guard auth.isSignedIn else {
            resetForSignOut()
            return
        }

        if isBootstrapped, accountEmail == auth.email {
            startAutomaticRefreshIfNeeded()
            await performReconcile(showProgress: false)
            return
        }

        accountEmail = auth.email
        isBootstrapped = true
        status = .syncing
        await performReconcile(showProgress: true)
        startAutomaticRefreshIfNeeded()
    }

    func setAppActive(_ active: Bool) {
        appIsActive = active
        if active {
            startAutomaticRefreshIfNeeded()
            if isBootstrapped, auth?.isSignedIn == true {
                Task { [weak self] in await self?.performReconcile(showProgress: false) }
            }
        } else {
            automaticRefreshTask?.cancel()
            automaticRefreshTask = nil
        }
    }

    func resetForSignOut() {
        uploadTask?.cancel()
        uploadTask = nil
        automaticRefreshTask?.cancel()
        automaticRefreshTask = nil
        auth = nil
        studyState = nil
        notes = nil
        questions = nil
        pomodoro = nil
        cloudFileID = nil
        isApplyingRemote = false
        isBootstrapped = false
        networkSyncInProgress = false
        pendingReconcile = false
        accountEmail = ""
        status = .idle
        lastSyncDate = nil
    }

    /// Toda alteração local agenda um envio automático. O debounce evita uma chamada por tecla.
    func localDataDidChange() {
        guard isBootstrapped, !isApplyingRemote, auth?.isSignedIn == true else { return }

        UserDefaults.standard.set(nowSecond(), forKey: localModifiedKey)
        uploadTask?.cancel()
        status = .syncing

        uploadTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: 700_000_000)
            guard !Task.isCancelled else { return }
            await self?.performReconcile(showProgress: true)
        }
    }

    /// Mantido como fallback de interface; o uso normal não depende deste botão.
    func syncNow() async {
        await performReconcile(showProgress: true)
    }

    /// Também é chamado ao retornar ao primeiro plano e pelo polling automático.
    func refreshFromCloudIfNeeded() async {
        await performReconcile(showProgress: false)
    }

    private func startAutomaticRefreshIfNeeded() {
        guard appIsActive, isBootstrapped, auth?.isSignedIn == true else { return }
        guard automaticRefreshTask == nil else { return }

        automaticRefreshTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: CrossPlatformOAuth.automaticPullIntervalNanoseconds)
                guard !Task.isCancelled else { return }
                guard let self, self.appIsActive, self.auth?.isSignedIn == true else { return }
                await self.performReconcile(showProgress: false)
            }
        }
    }

    private func performReconcile(showProgress: Bool) async {
        guard isBootstrapped, !isApplyingRemote, let auth, auth.isSignedIn else { return }

        if networkSyncInProgress {
            pendingReconcile = true
            return
        }

        networkSyncInProgress = true
        if showProgress { status = .syncing }

        do {
            let token = try await auth.freshCloudSyncAccessToken()
            try await reconcile(accessToken: token)
            let now = Date()
            lastSyncDate = now
            status = .synced(now)
        } catch {
            status = .failed(error.localizedDescription)
        }

        networkSyncInProgress = false
        if pendingReconcile {
            pendingReconcile = false
            Task { [weak self] in await self?.performReconcile(showProgress: false) }
        }
    }

    private func reconcile(accessToken: String) async throws {
        let remote = try await fetchRemoteState(accessToken: accessToken)
        if let id = remote.fileID { cloudFileID = id }
        let local = currentState()
        let localModified = UserDefaults.standard.object(forKey: localModifiedKey) as? Date

        guard let remoteState = remote.state else {
            if localModified == nil { UserDefaults.standard.set(nowSecond(), forKey: localModifiedKey) }
            try await uploadCurrentState(accessToken: accessToken)
            return
        }

        // Primeira entrada desta instalação: nuvem vence, salvo quando apenas o aparelho tem dados.
        guard let localModified else {
            if let local, local.hasUserData, !remoteState.hasUserData {
                UserDefaults.standard.set(nowSecond(), forKey: localModifiedKey)
                try await uploadCurrentState(accessToken: accessToken)
            } else {
                apply(remoteState)
            }
            return
        }

        if remoteState.updatedAt > localModified {
            apply(remoteState)
        } else if localModified > remoteState.updatedAt {
            try await uploadCurrentState(accessToken: accessToken)
        }
    }

    private func currentState() -> KepleraeCloudState? {
        guard let studyState, let notes, let questions, let pomodoro else { return nil }

        let updatedAt = UserDefaults.standard.object(forKey: localModifiedKey) as? Date ?? nowSecond()
        let theme = AppTheme(rawValue: UserDefaults.standard.string(forKey: "appTheme") ?? "") ?? .system
        let glassIntensity = UserDefaults.standard.object(forKey: "glassIntensityPercent") as? Int ?? 85

        #if os(macOS)
        let platform = "macos"
        #else
        let platform = "ios"
        #endif

        return KepleraeCloudState(
            schemaVersion: CrossPlatformOAuth.syncSchemaVersion,
            updatedAt: updatedAt,
            sourcePlatform: platform,
            deviceID: deviceID(),
            googleProjectNumber: CrossPlatformOAuth.googleProjectNumber,
            favorites: studyState.favorites.sorted(),
            completed: studyState.completed.sorted(),
            lastOpenedID: studyState.lastOpenedID,
            notes: notes.notes,
            noteTags: notes.tags,
            questionSubjects: questions.subjects,
            questionRecords: questions.records,
            pomodoroSettings: pomodoro.settings,
            pomodoroHistory: pomodoro.history,
            theme: theme,
            glassIntensity: glassIntensity
        )
    }

    private func nowSecond() -> Date {
        Date(timeIntervalSince1970: floor(Date().timeIntervalSince1970))
    }

    private func deviceID() -> String {
        if let value = UserDefaults.standard.string(forKey: deviceIDKey), !value.isEmpty { return value }
        let value = UUID().uuidString
        UserDefaults.standard.set(value, forKey: deviceIDKey)
        return value
    }

    private func apply(_ state: KepleraeCloudState) {
        guard let studyState, let notes, let questions, let pomodoro else { return }

        isApplyingRemote = true

        studyState.replace(
            favorites: Set(state.favorites),
            completed: Set(state.completed),
            lastOpenedID: state.lastOpenedID
        )
        notes.replace(tags: state.noteTags, notes: state.notes)
        questions.replace(subjects: state.questionSubjects, records: state.questionRecords)
        pomodoro.replace(settings: state.pomodoroSettings, history: state.pomodoroHistory)
        UserDefaults.standard.set(state.theme.rawValue, forKey: "appTheme")
        UserDefaults.standard.set(state.glassIntensity, forKey: "glassIntensityPercent")
        UserDefaults.standard.set(state.updatedAt, forKey: localModifiedKey)

        isApplyingRemote = false
    }

    private func uploadCurrentState(accessToken: String) async throws {
        guard let state = currentState() else { return }

        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(state)

        let fileID: String
        if let cloudFileID {
            fileID = cloudFileID
        } else if let existingID = try await findCloudFileID(accessToken: accessToken) {
            fileID = existingID
            self.cloudFileID = existingID
        } else {
            let createdID = try await createCloudFile(accessToken: accessToken)
            fileID = createdID
            self.cloudFileID = createdID
        }

        try await upload(data: data, fileID: fileID, accessToken: accessToken)
        UserDefaults.standard.set(state.updatedAt, forKey: localModifiedKey)
    }

    private func fetchRemoteState(accessToken: String) async throws -> (state: KepleraeCloudState?, fileID: String?) {
        guard let fileID = try await findCloudFileID(accessToken: accessToken) else {
            return (nil, nil)
        }

        guard let encodedID = fileID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "https://www.googleapis.com/drive/v3/files/\(encodedID)?alt=media") else {
            throw CloudSyncError.invalidURL
        }

        var request = URLRequest(url: url)
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = 30

        let (data, response) = try await URLSession.shared.data(for: request)
        try Self.validate(response)

        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let state = try decoder.decode(KepleraeCloudState.self, from: data)
        return (state, fileID)
    }

    private func findCloudFileID(accessToken: String) async throws -> String? {
        var components = URLComponents(string: "https://www.googleapis.com/drive/v3/files")!
        components.queryItems = [
            URLQueryItem(name: "spaces", value: "appDataFolder"),
            URLQueryItem(name: "q", value: "name='\(fileName)' and trashed=false"),
            URLQueryItem(name: "fields", value: "files(id,name,modifiedTime)"),
            URLQueryItem(name: "orderBy", value: "modifiedTime desc"),
            URLQueryItem(name: "pageSize", value: "1")
        ]

        guard let url = components.url else { throw CloudSyncError.invalidURL }
        var request = URLRequest(url: url)
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = 30

        let (data, response) = try await URLSession.shared.data(for: request)
        try Self.validate(response)

        let result = try JSONDecoder().decode(CloudFileList.self, from: data)
        return result.files.first?.id
    }

    private func createCloudFile(accessToken: String) async throws -> String {
        guard let url = URL(string: "https://www.googleapis.com/drive/v3/files?fields=id") else {
            throw CloudSyncError.invalidURL
        }

        let metadata: [String: Any] = [
            "name": fileName,
            "parents": ["appDataFolder"],
            "mimeType": "application/json"
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: metadata)
        request.timeoutInterval = 30

        let (data, response) = try await URLSession.shared.data(for: request)
        try Self.validate(response)

        let created = try JSONDecoder().decode(CreatedCloudFile.self, from: data)
        return created.id
    }

    private func upload(data: Data, fileID: String, accessToken: String) async throws {
        guard let encodedID = fileID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "https://www.googleapis.com/upload/drive/v3/files/\(encodedID)?uploadType=media") else {
            throw CloudSyncError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "PATCH"
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = data
        request.timeoutInterval = 30

        let (_, response) = try await URLSession.shared.data(for: request)
        try Self.validate(response)
    }

    private static func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else {
            throw CloudSyncError.invalidResponse
        }
        guard (200...299).contains(http.statusCode) else {
            throw CloudSyncError.httpStatus(http.statusCode)
        }
    }
}

private struct CloudFileList: Decodable {
    struct File: Decodable {
        let id: String
    }
    let files: [File]
}

private struct CreatedCloudFile: Decodable {
    let id: String
}

enum CloudSyncError: LocalizedError {
    case invalidURL
    case invalidResponse
    case httpStatus(Int)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Não foi possível montar o endereço da sincronização."
        case .invalidResponse:
            return "O Google Drive retornou uma resposta inválida durante a sincronização."
        case .httpStatus(let code):
            if code == 401 { return "A sessão do Google expirou. Entre novamente no Kepleræ." }
            if code == 403 { return "O Google Drive não autorizou a pasta de dados do Kepleræ." }
            return "A sincronização do Google Drive falhou (erro \(code))."
        }
    }
}
