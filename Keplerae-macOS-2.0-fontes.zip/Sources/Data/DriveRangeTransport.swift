import Foundation

/// Ephemeral, bounded range requests. No URLCache, download task, temporary file or disk writes.
actor DriveRangeTransport {
    struct Chunk: Sendable {
        let data: Data
        let range: DriveStreamingPolicy.ContentRange
        let mimeType: String
    }

    private let url: URL
    private var token: String
    private let refreshToken: @Sendable () async throws -> String
    nonisolated let session: URLSession

    init(stream: DriveStreamDescriptor, configuration: URLSessionConfiguration = .ephemeral,
         refreshToken: @escaping @Sendable () async throws -> String) {
        url = stream.url
        token = stream.accessToken
        self.refreshToken = refreshToken
        configuration.urlCache = nil
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.timeoutIntervalForRequest = 45
        configuration.timeoutIntervalForResource = 90
        session = URLSession(configuration: configuration)
    }

    func read(offset: Int64, remaining: Int64) async throws -> Chunk {
        let range = DriveStreamingPolicy.range(offset: offset, remaining: remaining)
        for attempt in 0...1 {
            try Task.checkCancellation()
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            request.setValue("bytes=\(range.lowerBound)-\(range.upperBound)", forHTTPHeaderField: "Range")
            request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
            let (bytes, response) = try await session.bytes(for: request)
            guard let http = response as? HTTPURLResponse else {
                session.invalidateAndCancel()
                throw StreamingError.invalidResponse
            }
            if http.statusCode == 401, attempt == 0 {
                token = try await refreshToken()
                continue
            }
            // Reject a full-file 200 at the headers, BEFORE consuming its body.
            guard http.statusCode == 206 else {
                session.invalidateAndCancel()
                throw http.statusCode == 200 ? StreamingError.rangeNotSupported : StreamingError.httpStatus(http.statusCode)
            }
            let received: DriveStreamingPolicy.ContentRange
            do { received = try DriveStreamingPolicy.ContentRange(http.value(forHTTPHeaderField: "Content-Range")) }
            catch { session.invalidateAndCancel(); throw error }
            guard received.start == range.lowerBound, received.end <= range.upperBound else {
                session.invalidateAndCancel()
                throw StreamingError.invalidRange
            }
            let expectedCount = Int(received.end - received.start + 1)
            var data = Data()
            data.reserveCapacity(expectedCount)
            for try await byte in bytes {
                try Task.checkCancellation()
                guard data.count < expectedCount else {
                    session.invalidateAndCancel()
                    throw StreamingError.invalidResponse
                }
                data.append(byte)
            }
            guard data.count == expectedCount else { throw StreamingError.invalidResponse }
            return Chunk(data: data, range: received, mimeType: response.mimeType ?? "application/octet-stream")
        }
        throw StreamingError.httpStatus(401)
    }

    nonisolated func cancel() { session.invalidateAndCancel() }
    deinit { session.invalidateAndCancel() }
}
