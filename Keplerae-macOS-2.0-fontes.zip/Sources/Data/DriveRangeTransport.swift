import Foundation

/// Ephemeral, bounded range requests. No URLCache, download task, temporary file or disk writes.
actor DriveRangeTransport {
    struct Chunk: Sendable {
        let data: Data
        let range: DriveStreamingPolicy.ContentRange
        let mimeType: String
    }

    private let url: URL
    private var token: String
    private let refreshToken: @Sendable () async throws -> String
    private let responseDelegate = RangeResponseDelegate()
    nonisolated let session: URLSession

    init(stream: DriveStreamDescriptor, configuration: URLSessionConfiguration = .ephemeral,
         refreshToken: @escaping @Sendable () async throws -> String) {
        url = stream.url
        token = stream.accessToken
        self.refreshToken = refreshToken
        configuration.urlCache = nil
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.timeoutIntervalForRequest = 45
        configuration.timeoutIntervalForResource = 90
        session = URLSession(configuration: configuration, delegate: responseDelegate, delegateQueue: nil)
    }

    func read(offset: Int64, remaining: Int64) async throws -> Chunk {
        let range = DriveStreamingPolicy.range(offset: offset, remaining: remaining)
        for attempt in 0...1 {
            try Task.checkCancellation()
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData)
            if !token.isEmpty { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
            request.setValue("bytes=\(range.lowerBound)-\(range.upperBound)", forHTTPHeaderField: "Range")
            request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
            do {
                return try await responseDelegate.read(request, range: range, session: session)
            } catch StreamingError.httpStatus(401) where attempt == 0 && !token.isEmpty {
                token = try await refreshToken()
            }
        }
        throw StreamingError.httpStatus(401)
    }

    nonisolated func cancel() { session.invalidateAndCancel() }
    deinit { session.invalidateAndCancel() }
}

/// URLSession delivers blocks directly into a bounded RAM buffer. Iterating the body
/// one async byte at a time made continuous playback depend on per-byte scheduling.
private final class RangeResponseDelegate: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private let lock = NSLock()
    private var transfers: [Int: RangeTransfer] = [:]

    func read(_ request: URLRequest, range: ClosedRange<Int64>, session: URLSession) async throws -> DriveRangeTransport.Chunk {
        let transfer = RangeTransfer(range: range)
        return try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                let task = session.dataTask(with: request)
                lock.lock(); transfers[task.taskIdentifier] = transfer; lock.unlock()
                transfer.start(task, continuation: continuation)
            }
        } onCancel: { transfer.cancel() }
    }

    private func transfer(for task: URLSessionTask, remove: Bool = false) -> RangeTransfer? {
        lock.lock(); defer { lock.unlock() }
        return remove ? transfers.removeValue(forKey: task.taskIdentifier) : transfers[task.taskIdentifier]
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping @Sendable (URLSession.ResponseDisposition) -> Void) {
        guard let transfer = transfer(for: dataTask) else { completionHandler(.cancel); return }
        do {
            try transfer.accept(response)
            completionHandler(.allow)
        } catch {
            // Reject non-range responses at the headers, before any full-file body.
            completionHandler(.cancel)
            transfer.finish(.failure(error))
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard let transfer = transfer(for: dataTask) else { return }
        do { try transfer.append(data) }
        catch { transfer.finish(.failure(error)); dataTask.cancel() }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let transfer = transfer(for: task, remove: true) else { return }
        if let error { transfer.finish(.failure(error)) }
        else { transfer.complete() }
    }
}

/// Body and metadata are accessed only on URLSession's serial delegate queue.
/// The lock protects cancellation/completion against the calling Swift task.
private final class RangeTransfer: @unchecked Sendable {
    private let requestedRange: ClosedRange<Int64>
    private let lock = NSLock()
    private var task: URLSessionDataTask?
    private var continuation: CheckedContinuation<DriveRangeTransport.Chunk, Error>?
    private var result: Result<DriveRangeTransport.Chunk, Error>?
    private var data = Data()
    private var contentRange: DriveStreamingPolicy.ContentRange?
    private var mimeType = "application/octet-stream"

    init(range: ClosedRange<Int64>) { requestedRange = range }

    func start(_ task: URLSessionDataTask, continuation: CheckedContinuation<DriveRangeTransport.Chunk, Error>) {
        lock.lock()
        self.task = task
        let completed = result
        if completed == nil { self.continuation = continuation }
        lock.unlock()
        if let completed { task.cancel(); continuation.resume(with: completed) }
        else { task.resume() }
    }

    func cancel() {
        finish(.failure(CancellationError()))
        lock.lock(); let task = task; lock.unlock()
        task?.cancel()
    }

    func accept(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { throw StreamingError.invalidResponse }
        guard http.statusCode == 206 else {
            throw http.statusCode == 200 ? StreamingError.rangeNotSupported : StreamingError.httpStatus(http.statusCode)
        }
        let range = try DriveStreamingPolicy.ContentRange(http.value(forHTTPHeaderField: "Content-Range"))
        guard range.start == requestedRange.lowerBound, range.end <= requestedRange.upperBound else {
            throw StreamingError.invalidRange
        }
        contentRange = range
        mimeType = response.mimeType ?? mimeType
        data.reserveCapacity(Int(range.end - range.start + 1))
    }

    func append(_ bytes: Data) throws {
        guard let contentRange, data.count + bytes.count <= Int(contentRange.end - contentRange.start + 1) else {
            throw StreamingError.invalidResponse
        }
        data.append(bytes)
    }

    func complete() {
        guard let contentRange, data.count == Int(contentRange.end - contentRange.start + 1) else {
            finish(.failure(StreamingError.invalidResponse)); return
        }
        finish(.success(.init(data: data, range: contentRange, mimeType: mimeType)))
    }

    func finish(_ value: Result<DriveRangeTransport.Chunk, Error>) {
        lock.lock()
        guard result == nil else { lock.unlock(); return }
        result = value
        let continuation = continuation
        self.continuation = nil
        lock.unlock()
        continuation?.resume(with: value)
    }
}
