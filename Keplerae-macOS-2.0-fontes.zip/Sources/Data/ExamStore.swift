import Combine
import Foundation

struct ExamEvent: Identifiable, Hashable, Codable {
    let id: UUID
    var name: String
    var date: Date
}

/// Provas e concursos cadastrados para a contagem regressiva da tela Início.
///
/// Os dados ficam só neste Mac (UserDefaults), fora do `keplerae-sync-v1.json`.
@MainActor
final class ExamStore: ObservableObject {
    @Published private(set) var exams: [ExamEvent] = []

    private let key = "keplerae.exams.v1"

    init() { load() }

    /// Todas as provas, da mais próxima para a mais distante.
    var all: [ExamEvent] { exams.sorted { $0.date < $1.date } }

    /// Próxima prova que ainda não passou (o próprio dia da prova conta).
    var next: ExamEvent? {
        let today = Calendar.current.startOfDay(for: .now)
        return all.first { Calendar.current.startOfDay(for: $0.date) >= today }
    }

    func add(name: String, date: Date) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        exams.append(ExamEvent(id: UUID(), name: String(trimmed.prefix(60)), date: date))
        save()
    }

    func delete(_ id: UUID) {
        exams.removeAll { $0.id == id }
        save()
    }

    /// Dias inteiros entre hoje e a prova (0 = é hoje).
    static func daysLeft(to date: Date, from now: Date = .now) -> Int {
        let calendar = Calendar.current
        let days = calendar.dateComponents(
            [.day],
            from: calendar.startOfDay(for: now),
            to: calendar.startOfDay(for: date)
        ).day ?? 0
        return max(0, days)
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: key),
              let decoded = try? JSONDecoder().decode([ExamEvent].self, from: data) else { return }
        exams = decoded
    }

    private func save() {
        if let data = try? JSONEncoder().encode(exams) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
