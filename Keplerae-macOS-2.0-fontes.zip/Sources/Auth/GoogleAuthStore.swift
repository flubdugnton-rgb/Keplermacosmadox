import AppKit
import Combine
import Foundation
import AppAuth
import GTMAppAuth
import Security

@MainActor
final class GoogleAuthStore: ObservableObject {
    @Published private(set) var isSignedIn = false
    @Published private(set) var displayName = ""
    @Published private(set) var email = ""
    @Published private(set) var photoURL = ""
    @Published private(set) var isLoading = false
    @Published var errorMessage: String?
    @Published private(set) var credentialNotice: String?

    // The traditional Mac keychain uses the creating app's ACL, without restricted entitlements.
    private let credentialStore = GTMAppAuth.KeychainStore(
        itemName: "com.aistudio.keplerae.stdy.macos.google-oauth",
        keychainHelper: NoninteractiveKeychainHelper(keychainAttributes: [.useFileBasedKeychain])
    )
    private var authState: OIDAuthState?
    private var authorizationFlow: OIDExternalUserAgentSession?
    private var pendingAuthState: OIDAuthState?
    private var profile: GoogleProfile?
    private var sessionVersion: UInt64 = 0

    init() {
        displayName = UserDefaults.standard.string(forKey: "googleDisplayName") ?? ""
        email = UserDefaults.standard.string(forKey: "googleEmail") ?? ""
        photoURL = UserDefaults.standard.string(forKey: "googlePhotoURL") ?? ""
        isLoading = true
        Task { await restorePreviousSignIn() }
    }

    func signIn() {
        guard !isLoading else { return }
        Task {
            do {
                try await authorize(requiredScopes: [], expectedSubject: nil)
            } catch {
                if let message = Self.message(for: error) { errorMessage = message }
            }
        }
    }

    func signOut() {
        sessionVersion &+= 1
        authorizationFlow?.cancel()
        authorizationFlow = nil
        pendingAuthState = nil
        authState = nil
        profile = nil
        isSignedIn = false
        isLoading = false
        displayName = ""
        email = ""
        photoURL = ""
        errorMessage = nil
        credentialNotice = nil
        do {
            try credentialStore.removeAuthSession()
        } catch {
            if !Self.isMissingCredential(error) {
                errorMessage = "A conta saiu desta sessão, mas o macOS não permitiu remover a sessão salva no Chaves."
            }
        }
        for key in ["googleDisplayName", "googleEmail", "googlePhotoURL"] {
            UserDefaults.standard.removeObject(forKey: key)
        }
    }

    func handle(_ url: URL) -> Bool {
        guard MacOAuthConfiguration.isCallback(url), let authorizationFlow else { return false }
        do {
            // AppAuth also validates the exact redirect and cryptographically random state.
            try authorizationFlow.resumeExternalUserAgentFlow(url)
            return true
        } catch {
            return false
        }
    }

    /// Token for reading the study catalog files from Drive.
    func freshDriveAccessToken() async throws -> String {
        try await freshAccessToken(requiredScopes: [MacOAuthConfiguration.driveReadScope])
    }

    /// Token only for the hidden per-user Kepleræ sync file in appDataFolder.
    func freshCloudSyncAccessToken() async throws -> String {
        try await freshAccessToken(requiredScopes: [MacOAuthConfiguration.driveAppDataScope])
    }

    private func authorize(requiredScopes: [String], expectedSubject: String?) async throws {
        guard !isLoading else { throw GoogleDriveAuthError.authorizationInProgress }
        guard let window = Self.presentingWindow() else { throw GoogleDriveAuthError.noPresentingWindow }
        isLoading = true
        errorMessage = nil
        sessionVersion &+= 1
        let version = sessionVersion
        defer {
            if sessionVersion == version {
                authorizationFlow = nil
                pendingAuthState = nil
                isLoading = false
            }
        }

        let configuration = OIDServiceConfiguration(
            authorizationEndpoint: MacOAuthConfiguration.authorizationEndpoint,
            tokenEndpoint: MacOAuthConfiguration.tokenEndpoint
        )
        var parameters = ["access_type": "offline", "prompt": "select_account consent"]
        if expectedSubject != nil, !email.isEmpty { parameters["login_hint"] = email }
        // This initializer generates state, nonce, and a fresh S256 PKCE verifier.
        // The public native client has no embedded secret.
        let request = OIDAuthorizationRequest(
            configuration: configuration,
            clientId: CrossPlatformOAuth.nativeClientID,
            scopes: MacOAuthConfiguration.requestedScopes,
            redirectURL: MacOAuthConfiguration.redirectURL,
            responseType: OIDResponseTypeCode,
            additionalParameters: parameters
        )
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            authorizationFlow = OIDAuthState.authState(byPresenting: request, presenting: window) { [weak self] state, error in
                // AppAuth dispatches authorization/token callbacks to the main queue.
                // Its Objective-C state stays on our actor; only Void crosses this continuation.
                MainActor.assumeIsolated {
                    guard let self, self.sessionVersion == version else {
                        continuation.resume(throwing: GoogleDriveAuthError.sessionChanged)
                        return
                    }
                    if let error {
                        continuation.resume(throwing: error)
                    } else if let state, state.isAuthorized {
                        self.pendingAuthState = state
                        continuation.resume(returning: ())
                    } else {
                        continuation.resume(throwing: GoogleDriveAuthError.noGoogleSession)
                    }
                }
            }
        }
        guard sessionVersion == version, let candidate = pendingAuthState else {
            throw GoogleDriveAuthError.sessionChanged
        }
        let token = try await refreshToken(for: candidate, version: version)
        let candidateProfile = try await Self.fetchProfile(accessToken: token)
        guard sessionVersion == version else { throw GoogleDriveAuthError.sessionChanged }
        if let expectedSubject, candidateProfile.subject != expectedSubject {
            throw GoogleDriveAuthError.accountChanged
        }
        guard MacOAuthConfiguration.hasScopes(requiredScopes, granted: candidate.scope) else {
            throw GoogleDriveAuthError.scopeNotGranted
        }
        try save(candidate, profile: candidateProfile)
        authState = candidate
        apply(candidateProfile)
    }

    private func freshAccessToken(requiredScopes: [String]) async throws -> String {
        guard let current = authState, current.isAuthorized else {
            throw GoogleDriveAuthError.noGoogleSession
        }
        if !MacOAuthConfiguration.hasScopes(requiredScopes, granted: current.scope) {
            // Installed clients request their full scope set again. Check account identity before
            // adopting the new state, so cloud sync cannot silently switch Google accounts.
            try await authorize(requiredScopes: requiredScopes, expectedSubject: profile?.subject)
        }
        guard let state = authState else { throw GoogleDriveAuthError.noGoogleSession }
        let token: String
        do {
            token = try await refreshToken(for: state, version: sessionVersion)
        } catch {
            if authState === state, !state.isAuthorized {
                authState = nil
                isSignedIn = false
                errorMessage = GoogleDriveAuthError.noGoogleSession.localizedDescription
            }
            throw error
        }
        guard authState === state else { throw GoogleDriveAuthError.sessionChanged }
        if let profile { try save(state, profile: profile) }
        return token
    }

    private func refreshToken(for state: OIDAuthState, version: UInt64) async throws -> String {
        let token: String = try await withCheckedThrowingContinuation { continuation in
            state.performAction(freshTokens: { accessToken, _, error in
                if let error {
                    continuation.resume(throwing: error)
                } else if let accessToken, !accessToken.isEmpty {
                    continuation.resume(returning: accessToken)
                } else {
                    continuation.resume(throwing: GoogleDriveAuthError.missingAccessToken)
                }
            })
        }
        guard sessionVersion == version else { throw GoogleDriveAuthError.sessionChanged }
        return token
    }

    private func restorePreviousSignIn() async {
        let version = sessionVersion
        defer { if sessionVersion == version { isLoading = false } }
        do {
            let stored = try credentialStore.retrieveAuthSession()
            let state = stored.authState
            guard state.isAuthorized,
                  state.lastAuthorizationResponse.request.clientID == CrossPlatformOAuth.nativeClientID else {
                errorMessage = GoogleDriveAuthError.noGoogleSession.localizedDescription
                return
            }
            let cachedProfile = GoogleProfile(
                subject: stored.userID ?? "",
                email: stored.userEmail ?? email,
                name: displayName,
                picture: photoURL,
                emailVerified: stored.userEmailIsVerified
            )
            authState = state
            do {
                let token = try await refreshToken(for: state, version: version)
                let restoredProfile = try await Self.fetchProfile(accessToken: token)
                guard sessionVersion == version else { return }
                try save(state, profile: restoredProfile)
                apply(restoredProfile)
            } catch {
                guard sessionVersion == version else { return }
                // A network outage does not invalidate AppAuth's grant. Local data remains usable;
                // refreshing tokens and syncing can retry when the network returns.
                if state.isAuthorized, !cachedProfile.subject.isEmpty, !cachedProfile.email.isEmpty,
                   Self.isNetworkError(error) {
                    apply(cachedProfile)
                } else {
                    authState = nil
                    errorMessage = Self.message(for: error)
                }
            }
        } catch {
            guard sessionVersion == version else { return }
            if Self.requiresKeychainAuthorization(error) {
                errorMessage = "A assinatura desta atualização não tem acesso automático à sessão salva. Entre no Google novamente. Uma versão assinada com o mesmo certificado preserva esse acesso entre atualizações."
            } else if !Self.isMissingCredential(error) {
                errorMessage = GoogleDriveAuthError.keychainUnavailable.localizedDescription
            }
        }
    }

    private func save(_ state: OIDAuthState, profile: GoogleProfile) throws {
        do {
            try credentialStore.save(authSession: GTMAppAuth.AuthSession(
                authState: state,
                serviceProvider: "Google",
                userID: profile.subject,
                userEmail: profile.email,
                userEmailIsVerified: profile.emailVerified == true ? "true" : "false"
            ))
            credentialNotice = nil
        } catch {
            if Self.requiresKeychainAuthorization(error) {
                credentialNotice = "A sessão está ativa apenas até fechar o aplicativo: o Chaves não autorizou esta assinatura a atualizar a sessão salva."
                return
            }
            throw GoogleDriveAuthError.keychainUnavailable
        }
    }

    private func apply(_ profile: GoogleProfile) {
        self.profile = profile
        displayName = profile.name ?? ""
        email = profile.email
        photoURL = profile.picture ?? ""
        isSignedIn = true
        errorMessage = nil
        UserDefaults.standard.set(displayName, forKey: "googleDisplayName")
        UserDefaults.standard.set(email, forKey: "googleEmail")
        UserDefaults.standard.set(photoURL, forKey: "googlePhotoURL")
    }

    nonisolated private static func fetchProfile(accessToken: String) async throws -> GoogleProfile {
        var request = URLRequest(url: MacOAuthConfiguration.userInfoEndpoint)
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = 30
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse else { throw GoogleDriveAuthError.profileUnavailable }
        guard response.statusCode != 401 else { throw GoogleDriveAuthError.noGoogleSession }
        guard response.statusCode == 200 else { throw GoogleDriveAuthError.profileUnavailable }
        let profile = try JSONDecoder().decode(GoogleProfile.self, from: data)
        guard !profile.subject.isEmpty, !profile.email.isEmpty else { throw GoogleDriveAuthError.profileUnavailable }
        return profile
    }

    private static func presentingWindow() -> NSWindow? {
        NSApplication.shared.keyWindow
            ?? NSApplication.shared.mainWindow
            ?? NSApplication.shared.windows.first(where: { $0.isVisible && $0.canBecomeKey })
    }

    nonisolated private static func isMissingCredential(_ error: Error) -> Bool {
        guard let error = error as? GTMAppAuth.KeychainStore.Error else { return false }
        switch error {
        case .passwordNotFound, .failedToDeletePasswordBecauseItemNotFound:
            return true
        case .unhandled(let status):
            return status == -25300 // errSecItemNotFound
        default:
            return false
        }
    }

    nonisolated private static func requiresKeychainAuthorization(_ error: Error) -> Bool {
        guard case GTMAppAuth.KeychainStore.Error.unhandled(let status) = error else { return false }
        return [errSecInteractionNotAllowed, errSecInteractionRequired, errSecAuthFailed,
                errSecUserCanceled, errSecDuplicateItem].contains(status)
    }

    nonisolated private static func isNetworkError(_ error: Error) -> Bool {
        let error = error as NSError
        return error.domain == NSURLErrorDomain ||
            (error.domain == OIDGeneralErrorDomain && error.code == -5)
    }

    nonisolated private static func message(for error: Error) -> String? {
        if let error = error as? GoogleDriveAuthError, error == .sessionChanged { return nil }
        if error is CancellationError { return nil }
        let error = error as NSError
        if error.domain == OIDGeneralErrorDomain, [-3, -4].contains(error.code) { return nil }
        if error.domain == OIDOAuthAuthorizationErrorDomain, error.code == -4 { return nil }
        if error.domain == OIDOAuthTokenErrorDomain { return GoogleDriveAuthError.noGoogleSession.localizedDescription }
        return error.localizedDescription
    }
}

private struct GoogleProfile: Decodable, Sendable {
    let subject: String
    let email: String
    let name: String?
    let picture: String?
    let emailVerified: Bool?

    enum CodingKeys: String, CodingKey {
        case subject = "sub"
        case email, name, picture
        case emailVerified = "email_verified"
    }
}

enum GoogleDriveAuthError: LocalizedError, Equatable {
    case noGoogleSession
    case noPresentingWindow
    case scopeNotGranted
    case missingAccessToken
    case keychainUnavailable
    case authorizationInProgress
    case sessionChanged
    case accountChanged
    case profileUnavailable

    var errorDescription: String? {
        switch self {
        case .noGoogleSession:
            return "Sua sessão do Google expirou. Entre novamente no Kepleræ."
        case .noPresentingWindow:
            return "Não foi possível abrir a autorização do Google Drive."
        case .scopeNotGranted:
            return "O acesso necessário ao Google Drive não foi autorizado. Tente entrar novamente e permitir esse acesso."
        case .missingAccessToken:
            return "O Google não forneceu um token de acesso válido."
        case .keychainUnavailable:
            return "O macOS não permitiu salvar ou ler sua sessão no Chaves. Autorize o acesso ao Chaves e tente novamente."
        case .authorizationInProgress:
            return "Uma autorização do Google já está em andamento. Conclua a janela de login e tente novamente."
        case .sessionChanged:
            return "A sessão foi encerrada."
        case .accountChanged:
            return "Use a mesma conta Google já conectada. Para trocar de conta, saia primeiro no perfil."
        case .profileUnavailable:
            return "Não foi possível carregar seu perfil do Google. Verifique a conexão e tente novamente."
        }
    }
}
