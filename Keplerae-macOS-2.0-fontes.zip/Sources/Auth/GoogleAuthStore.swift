import Foundation
import AppKit
import Combine
import GoogleSignIn

@MainActor
final class GoogleAuthStore: ObservableObject {
    @Published private(set) var isSignedIn = false
    @Published private(set) var displayName = ""
    @Published private(set) var email = ""
    @Published private(set) var photoURL = ""
    @Published private(set) var isLoading = false
    @Published var errorMessage: String?

    private let driveFileScope = "https://www.googleapis.com/auth/drive.file"
    private let driveReadScope = "https://www.googleapis.com/auth/drive.readonly"
    private let driveAppDataScope = "https://www.googleapis.com/auth/drive.appdata"

    init() {
        let clientID = CrossPlatformOAuth.nativeClientID
        if !clientID.isEmpty {
            GIDSignIn.sharedInstance.configuration = GIDConfiguration(clientID: clientID)
        }
        restorePreviousSignIn()
    }

    func signIn() {
        guard !isLoading else { return }
        guard let presentingWindow = Self.presentingWindow() else {
            errorMessage = "Não foi possível abrir a tela de login do Google."
            return
        }

        isLoading = true
        errorMessage = nil

        // Google Sign-In presents the browser authorization session from an AppKit window.
        // Convert the SDK's Objective-C result to value types before updating our main actor.
        GIDSignIn.sharedInstance.signIn(
            withPresenting: presentingWindow,
            hint: nil,
            additionalScopes: [driveFileScope, driveReadScope, driveAppDataScope]
        ) { [weak self] result, error in
            let profile = result.map { GoogleProfileSnapshot(user: $0.user) }
            let message = error.flatMap { Self.signInErrorMessage(for: $0) }

            Task { @MainActor [weak self] in
                guard let self else { return }
                self.isLoading = false

                if let profile {
                    self.applyProfile(name: profile.name, email: profile.email, photoURL: profile.photoURL)
                } else {
                    self.errorMessage = message
                }
            }
        }
    }

    func signOut() {
        GIDSignIn.sharedInstance.signOut()

        displayName = ""
        email = ""
        photoURL = ""
        isSignedIn = false
        errorMessage = nil

        UserDefaults.standard.removeObject(forKey: "googleDisplayName")
        UserDefaults.standard.removeObject(forKey: "googleEmail")
        UserDefaults.standard.removeObject(forKey: "googlePhotoURL")
    }

    func handle(_ url: URL) -> Bool {
        GIDSignIn.sharedInstance.handle(url)
    }

    /// Token used to read the study catalog files from Drive.
    func freshDriveAccessToken() async throws -> String {
        try await freshAccessToken(requiredScopes: [driveReadScope])
    }

    /// Token used only for the hidden per-user Kepleræ sync file in appDataFolder.
    func freshCloudSyncAccessToken() async throws -> String {
        try await freshAccessToken(requiredScopes: [driveAppDataScope])
    }

    private func freshAccessToken(requiredScopes: [String]) async throws -> String {
        guard let currentUser = GIDSignIn.sharedInstance.currentUser else {
            throw GoogleDriveAuthError.noGoogleSession
        }

        let granted = Set(currentUser.grantedScopes ?? [])
        let missing = requiredScopes.filter { !granted.contains($0) }

        if missing.isEmpty {
            return try await refreshToken(for: currentUser)
        }

        guard let presentingWindow = Self.presentingWindow() else {
            throw GoogleDriveAuthError.noPresentingWindow
        }

        return try await withCheckedThrowingContinuation { continuation in
            currentUser.addScopes(missing, presenting: presentingWindow) { result, error in
                if let error {
                    continuation.resume(throwing: Self.actionableAuthenticationError(for: error))
                    return
                }

                guard let scopedUser = result?.user,
                      Set(requiredScopes).isSubset(of: Set(scopedUser.grantedScopes ?? [])) else {
                    continuation.resume(throwing: GoogleDriveAuthError.scopeNotGranted)
                    return
                }

                scopedUser.refreshTokensIfNeeded { refreshedUser, refreshError in
                    if let refreshError {
                        continuation.resume(throwing: Self.actionableAuthenticationError(for: refreshError))
                        return
                    }

                    guard let token = refreshedUser?.accessToken.tokenString, !token.isEmpty else {
                        continuation.resume(throwing: GoogleDriveAuthError.missingAccessToken)
                        return
                    }

                    continuation.resume(returning: token)
                }
            }
        }
    }

    private func refreshToken(for user: GIDGoogleUser) async throws -> String {
        try await withCheckedThrowingContinuation { continuation in
            user.refreshTokensIfNeeded { refreshedUser, error in
                if let error {
                    continuation.resume(throwing: Self.actionableAuthenticationError(for: error))
                    return
                }

                guard let token = refreshedUser?.accessToken.tokenString, !token.isEmpty else {
                    continuation.resume(throwing: GoogleDriveAuthError.missingAccessToken)
                    return
                }

                continuation.resume(returning: token)
            }
        }
    }

    private func restorePreviousSignIn() {
        isLoading = true

        GIDSignIn.sharedInstance.restorePreviousSignIn { [weak self] user, error in
            let restoredName = user?.profile?.name ?? ""
            let restoredEmail = user?.profile?.email ?? ""
            let restoredPhotoURL = user?.profile?.imageURL(withDimension: 320)?.absoluteString ?? ""
            let restoredSignedIn = user != nil
            let keychainMessage = error.flatMap { Self.keychainErrorMessage(for: $0) }

            Task { @MainActor [weak self] in
                guard let self else { return }

                if restoredSignedIn {
                    self.applyProfile(
                        name: restoredName,
                        email: restoredEmail,
                        photoURL: restoredPhotoURL
                    )
                } else {
                    self.displayName = UserDefaults.standard.string(forKey: "googleDisplayName") ?? ""
                    self.email = UserDefaults.standard.string(forKey: "googleEmail") ?? ""
                    self.photoURL = UserDefaults.standard.string(forKey: "googlePhotoURL") ?? ""
                    self.isSignedIn = false
                }

                self.isLoading = false
                self.errorMessage = keychainMessage
            }
        }
    }

    private func applyProfile(name: String, email: String, photoURL: String) {
        displayName = name
        self.email = email
        self.photoURL = photoURL
        isSignedIn = true

        UserDefaults.standard.set(displayName, forKey: "googleDisplayName")
        UserDefaults.standard.set(self.email, forKey: "googleEmail")
        UserDefaults.standard.set(self.photoURL, forKey: "googlePhotoURL")
    }

    private static func presentingWindow() -> NSWindow? {
        NSApplication.shared.keyWindow
            ?? NSApplication.shared.mainWindow
            ?? NSApplication.shared.windows.first(where: { $0.isVisible && $0.canBecomeKey })
    }

    nonisolated private static func signInErrorMessage(for error: Error) -> String? {
        let nsError = error as NSError
        if nsError.domain == kGIDSignInErrorDomain, nsError.code == -5 {
            return nil // Closing the authorization window is an ordinary cancellation.
        }
        return keychainErrorMessage(for: error) ?? error.localizedDescription
    }

    nonisolated private static func keychainErrorMessage(for error: Error) -> String? {
        let nsError = error as NSError
        guard nsError.domain == kGIDSignInErrorDomain, nsError.code == -2 else { return nil }
        return GoogleDriveAuthError.keychainUnavailable.localizedDescription
    }

    nonisolated private static func actionableAuthenticationError(for error: Error) -> Error {
        keychainErrorMessage(for: error) == nil ? error : GoogleDriveAuthError.keychainUnavailable
    }
}

private struct GoogleProfileSnapshot: Sendable {
    let name: String
    let email: String
    let photoURL: String

    init(user: GIDGoogleUser) {
        name = user.profile?.name ?? ""
        email = user.profile?.email ?? ""
        photoURL = user.profile?.imageURL(withDimension: 320)?.absoluteString ?? ""
    }
}

enum GoogleDriveAuthError: LocalizedError {
    case noGoogleSession
    case noPresentingWindow
    case scopeNotGranted
    case missingAccessToken
    case keychainUnavailable

    var errorDescription: String? {
        switch self {
        case .noGoogleSession:
            return "Sua sessão do Google expirou. Entre novamente no Kepleræ."
        case .noPresentingWindow:
            return "Não foi possível abrir a autorização do Google Drive."
        case .scopeNotGranted:
            return "O acesso necessário ao Google Drive não foi autorizado."
        case .missingAccessToken:
            return "O Google não forneceu um token de acesso válido."
        case .keychainUnavailable:
            return "O macOS não conseguiu salvar sua sessão do Google. Esta versão do Kepleræ precisa de uma assinatura com certificado da Apple e acesso ao Chaves configurado."
        }
    }
}
