import Foundation

/// IDs públicos dos clientes OAuth do mesmo projeto Google Cloud do Kepleræ.
///
/// Apenas client IDs públicos ficam no app. Client secret não deve ser empacotado em iOS/macOS.
/// O cliente macOS usa o mesmo projeto Google e documento de sincronização no appDataFolder.
/// O cliente OAuth do Mac é do tipo iOS para usar seu URI scheme nativo com PKCE,
/// sem segredo de cliente. Ele deve estar registrado com o bundle ID do alvo Mac.
enum CrossPlatformOAuth {
    static let googleProjectNumber = "240965240632"
    static let iOSClientID = "240965240632-re20f1uta49pcuorpveqabrvii76r8o9.apps.googleusercontent.com"
    static let macOSClientID = "240965240632-qd0sekmr9ukauuh7lnc2cmct75ja5grf.apps.googleusercontent.com"
    static let syncFileName = "keplerae-sync-v1.json"
    static let syncSchemaVersion = 2
    static let automaticPullIntervalNanoseconds: UInt64 = 20_000_000_000

    static var nativeClientID: String {
        #if os(macOS)
        macOSClientID
        #else
        iOSClientID
        #endif
    }
}
