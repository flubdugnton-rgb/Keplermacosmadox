import SwiftUI

enum MainDestination: Int, CaseIterable, Identifiable, Hashable {
    case home = 0
    case pomodoro
    case questions
    case notes

    var id: Int { rawValue }

    var title: String {
        switch self {
        case .home: return "Início"
        case .pomodoro: return "Pomodoro"
        case .questions: return "Questões"
        case .notes: return "Notas"
        }
    }

    var icon: String {
        switch self {
        case .home: return "house"
        case .pomodoro: return "timer"
        case .questions: return "questionmark.square"
        case .notes: return "note.text"
        }
    }

    var selectedIcon: String {
        switch self {
        case .home: return "house.fill"
        case .pomodoro: return "timer"
        case .questions: return "questionmark.square.fill"
        case .notes: return "note.text"
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var auth: GoogleAuthStore
    @State private var selection: MainDestination = .home
    @State private var showProfile = false
    @State private var showSearch = false
    @State private var homeResetID = UUID()
    @AppStorage("appTheme") private var appThemeRaw = AppTheme.system.rawValue

    private var theme: AppTheme { AppTheme(rawValue: appThemeRaw) ?? .system }

    private var preferredScheme: ColorScheme? {
        switch theme {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }

    var body: some View {
        ZStack {
            if auth.isSignedIn {
                mainShell
                    .transition(.opacity.combined(with: .scale(scale: 1.005)))
            } else {
                LoginView()
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.24), value: auth.isSignedIn)
        .preferredColorScheme(preferredScheme)
    }

    private var mainShell: some View {
        NavigationSplitView {
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    Image("KepleraeLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 38, height: 38)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Kepleræ")
                            .font(.title2.bold())
                        Text("Seu espaço de estudo")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                .padding(20)

                Button {
                    showSearch = true
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "magnifyingglass")
                        Text("Buscar")
                        Spacer(minLength: 0)
                        Text("⌘K")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .font(.subheadline)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    .background(.quaternary.opacity(0.6), in: Capsule())
                    .contentShape(Capsule())
                }
                .buttonStyle(.plain)
                .keyboardShortcut("k", modifiers: .command)
                .help("Buscar aulas, PDFs, áudios e notas (⌘K)")
                .padding(.horizontal, 16)
                .padding(.bottom, 6)

                List {
                    Section("Estudo") {
                        ForEach(MainDestination.allCases) { destination in
                            Button {
                                select(destination)
                            } label: {
                                HStack(spacing: 9) {
                                    Image(systemName: selection == destination ? destination.selectedIcon : destination.icon)
                                        .frame(width: 18)
                                    Text(destination.title)
                                }
                                .font(.body.weight(selection == destination ? .semibold : .regular))
                                .foregroundStyle(selection == destination ? Color.accentColor : Color.primary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.vertical, 8)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .keyboardShortcut(KeyEquivalent(Character(String(destination.rawValue + 1))), modifiers: .command)
                            .listRowBackground(selection == destination ? Color.accentColor.opacity(0.12) : Color.clear)
                            .accessibilityAddTraits(selection == destination ? .isSelected : [])
                            .help("\(destination.title) (⌘\(destination.rawValue + 1))")
                        }
                    }
                }
                .listStyle(.sidebar)

                HStack {
                    Label("Aparência", systemImage: "circle.lefthalf.filled")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Spacer(minLength: 8)
                    ThemeToggleButton()
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 10)

                Divider()
                    .padding(.horizontal, 16)

                Button {
                    showProfile = true
                } label: {
                    HStack(spacing: 12) {
                        AvatarView(photoURL: auth.photoURL)
                            .frame(width: 38, height: 38)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(auth.displayName.isEmpty ? "Meu perfil" : auth.displayName)
                                .font(.subheadline.weight(.semibold))
                                .lineLimit(1)
                            Text("Perfil e ajustes")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer(minLength: 0)
                        Image(systemName: "gearshape")
                            .foregroundStyle(.secondary)
                    }
                    .padding(12)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .keyboardShortcut(",", modifiers: .command)
                .help("Perfil e ajustes (⌘,)")
                .padding(8)
            }
            .navigationSplitViewColumnWidth(min: 220, ideal: 240, max: 280)
        } detail: {
            selectedContent
                .id(selectedContentID)
                .background(AmbientBackground(style: selection == .pomodoro ? .focus : .standard))
        }
        .navigationSplitViewStyle(.balanced)
        .frame(minWidth: 900, minHeight: 640)
        .sheet(isPresented: $showProfile) {
            ProfileSettingsView()
                .preferredColorScheme(preferredScheme)
                .frame(minWidth: 580, idealWidth: 660, minHeight: 600, idealHeight: 760)
        }
        .sheet(isPresented: $showSearch) {
            GlobalSearchView(onOpenNotes: { selection = .notes })
                .preferredColorScheme(preferredScheme)
        }
    }

    @ViewBuilder
    private var selectedContent: some View {
        switch selection {
        case .home:
            HomeView(resetID: homeResetID)
        case .pomodoro:
            PomodoroView()
        case .questions:
            QuestionsView()
        case .notes:
            NotesView()
        }
    }

    private var selectedContentID: AnyHashable {
        selection == .home ? AnyHashable(homeResetID) : AnyHashable(selection)
    }

    private func select(_ destination: MainDestination) {
        if destination == .home && selection == .home {
            homeResetID = UUID()
        }
        selection = destination
    }
}

struct AvatarView: View {
    let photoURL: String

    var body: some View {
        ZStack {
            Circle().fill(.thinMaterial)

            if let url = URL(string: photoURL), !photoURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().scaledToFill()
                    default:
                        Image(systemName: "person.fill")
                            .font(.system(size: 15, weight: .semibold))
                    }
                }
            } else {
                Image(systemName: "person.fill")
                    .font(.system(size: 15, weight: .semibold))
            }
        }
        .clipShape(Circle())
        .overlay(Circle().stroke(.white.opacity(0.62), lineWidth: 1.0))
        .shadow(color: .black.opacity(0.07), radius: 4, y: 2)
    }
}
