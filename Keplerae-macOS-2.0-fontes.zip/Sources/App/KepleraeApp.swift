import SwiftUI

@main
struct KepleraeApp: App {
    @Environment(\.scenePhase) private var scenePhase

    init() {
        MediaAudioSession.activatePlayback()
        DriveContentLoader.cleanupCache()

    }

    @StateObject private var auth = GoogleAuthStore()
    @StateObject private var catalog = CatalogStore()
    @StateObject private var notes = NotesStore()
    @StateObject private var questions = QuestionsStore()
    @StateObject private var pomodoro = PomodoroStore()
    @StateObject private var studyState = StudyStateStore()
    @StateObject private var cloudSync = CloudSyncService()

    var body: some Scene {
        WindowGroup("Kepleræ", id: "main") {
            RootView()
                .environmentObject(auth)
                .environmentObject(catalog)
                .environmentObject(notes)
                .environmentObject(questions)
                .environmentObject(pomodoro)
                .environmentObject(studyState)
                .environmentObject(cloudSync)
                .frame(minWidth: 960, minHeight: 680)
                .onOpenURL { url in _ = auth.handle(url) }
                .task(id: auth.isSignedIn) {
                    if auth.isSignedIn {
                        await cloudSync.bootstrap(
                            auth: auth,
                            studyState: studyState,
                            notes: notes,
                            questions: questions,
                            pomodoro: pomodoro
                        )
                    } else {
                        cloudSync.resetForSignOut()
                    }
                }
                .onReceive(NotificationCenter.default.publisher(for: .kepleraeDataDidChange)) { _ in
                    cloudSync.localDataDidChange()
                }
                .onAppear {
                    cloudSync.setAppActive(scenePhase == .active)
                }
                .onChange(of: scenePhase) { _, phase in
                    let active = phase == .active
                    cloudSync.setAppActive(active)
                    guard active, auth.isSignedIn else { return }
                    DriveContentLoader.cleanupCache()
                    Task { await cloudSync.refreshFromCloudIfNeeded() }
                }
        }
        .defaultSize(width: 1180, height: 820)
        .windowResizability(.contentMinSize)
    }
}
