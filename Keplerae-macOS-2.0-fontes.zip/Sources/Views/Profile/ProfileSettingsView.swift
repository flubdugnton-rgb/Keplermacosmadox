import SwiftUI
import UniformTypeIdentifiers

struct ProfileSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var auth: GoogleAuthStore
    @EnvironmentObject private var notes: NotesStore
    @EnvironmentObject private var questions: QuestionsStore
    @EnvironmentObject private var pomodoro: PomodoroStore
    @EnvironmentObject private var studyState: StudyStateStore
    @EnvironmentObject private var cloudSync: CloudSyncService
    @AppStorage("appTheme") private var appThemeRaw = AppTheme.system.rawValue
    @AppStorage("glassIntensityPercent") private var glassIntensityPercent = 85
    @State private var exportDocument: BackupDocument?
    @State private var exporting = false
    @State private var importing = false
    @State private var message: String?

    private var intensity: Double { Double(glassIntensityPercent) / 100 }
    private var theme: AppTheme { AppTheme(rawValue: appThemeRaw) ?? .system }
    private var preferredScheme: ColorScheme? {
        switch theme {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AmbientBackground()

                ScrollView {
                    VStack(spacing: 18) {
                        profileHeader
                        appearanceSection
                        googleSection
                        dataSection

                        Button(role: .destructive) {
                            auth.signOut()
                            dismiss()
                        } label: {
                            Label("Desconectar", systemImage: "rectangle.portrait.and.arrow.right")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .frame(height: 48)
                        }
                        .buttonStyle(.glass)
                        .buttonBorderShape(.capsule)
                        .tint(.red)

                        Text("Kepleræ 2.0 · macOS")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .padding(.top, 2)
                    }
                    .padding(20)
                    .padding(.bottom, 28)
                }
                .scrollIndicators(.hidden)
            }
            .navigationTitle("Perfil")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Fechar") { dismiss() }
                        .buttonStyle(.glass)
                        .keyboardShortcut(.cancelAction)
                }
            }
        }
        .preferredColorScheme(preferredScheme)
        .fileExporter(isPresented: $exporting, document: exportDocument, contentType: .json, defaultFilename: "Keplerae-backup-2.0") { result in
            if case .failure(let error) = result {
                message = error.localizedDescription
            }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
            importBackup(result)
        }
        .alert("Transferência de dados", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("OK") { message = nil }
        } message: {
            Text(message ?? "")
        }
    }

    private var profileHeader: some View {
        VStack(spacing: 10) {
            AvatarView(photoURL: auth.photoURL)
                .frame(width: 94, height: 94)
            Text(auth.displayName.isEmpty ? "Minha conta" : auth.displayName)
                .font(.title2.bold())
            Text(auth.email)
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text("Seu espaço, do seu jeito.")
                .font(.headline)
                .padding(.top, 2)
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background(
            LinearGradient(colors: [.blue.opacity(0.12), .purple.opacity(0.09), .clear], startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 32, style: .continuous)
        )
        .kepleraeGlass(intensity: intensity, cornerRadius: 32, interactive: false)
    }

    private var appearanceSection: some View {
        SettingsSection(title: "Aparência", icon: "circle.lefthalf.filled", intensity: intensity) {
            HStack {
                Text("Liquid Glass").font(.headline)
                Spacer()
                Text("\(glassIntensityPercent)%")
                    .font(.headline.monospacedDigit())
                    .foregroundStyle(.secondary)
            }

            Slider(
                value: Binding(
                    get: { Double(glassIntensityPercent) },
                    set: {
                        glassIntensityPercent = Int($0.rounded())
                        cloudSync.localDataDidChange()
                    }
                ),
                in: 0...100,
                step: 5
            )
            .tint(.cyan)

            HStack {
                Text("Mais sutil")
                Spacer()
                Text("Mais intenso")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
    }

    private var googleSection: some View {
        SettingsSection(title: "Google", icon: "person.crop.circle.badge.checkmark", intensity: intensity) {
            if let notice = auth.credentialNotice {
                Label(notice, systemImage: "lock.trianglebadge.exclamationmark")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(.blue.opacity(0.10)).frame(width: 42, height: 42)
                    Text("G").font(.title3.bold()).foregroundStyle(.blue)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Conta conectada").font(.headline)
                    Text(auth.email).font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "checkmark.seal.fill").foregroundStyle(.green)
            }

            Divider()

            HStack(spacing: 12) {
                Image(systemName: "icloud.and.arrow.up.fill")
                    .font(.title3)
                    .foregroundStyle(.cyan)
                    .frame(width: 36)

                VStack(alignment: .leading, spacing: 2) {
                    Text("Sincronização automática").font(.headline)
                    Text(syncSubtitle)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Spacer()

                if case .syncing = cloudSync.status {
                    ProgressView().controlSize(.small)
                } else {
                    Image(systemName: syncIcon)
                        .foregroundStyle(syncTint)
                }
            }

            Button {
                Task { await cloudSync.syncNow() }
            } label: {
                Label("Sincronizar agora", systemImage: "arrow.triangle.2.circlepath")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .frame(height: 40)
            }
            .buttonStyle(.glass)
            .buttonBorderShape(.capsule)

            Text("Cada alteração é enviada automaticamente à sua conta Google. Enquanto o app está aberto, mudanças feitas no Android, iPhone/iPad e Mac são consultadas em segundo plano. Vídeos, PDFs e áudios em cache não são enviados para a nuvem.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private var syncSubtitle: String {
        switch cloudSync.status {
        case .idle:
            return "Aguardando a conta Google"
        case .syncing:
            return "Salvando suas alterações…"
        case .synced(let date):
            return "Atualizado em " + date.formatted(date: .omitted, time: .shortened)
        case .failed(let message):
            return message
        }
    }

    private var syncIcon: String {
        switch cloudSync.status {
        case .failed: return "exclamationmark.icloud.fill"
        case .synced: return "checkmark.icloud.fill"
        default: return "icloud.fill"
        }
    }

    private var syncTint: Color {
        if case .failed = cloudSync.status { return .orange }
        return .green
    }

    private var dataSection: some View {
        SettingsSection(title: "Seus dados", icon: "arrow.up.arrow.down.circle", intensity: intensity) {
            Button { prepareExport() } label: {
                Label("Exportar dados e configurações", systemImage: "square.and.arrow.up")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            Divider()

            Button { importing = true } label: {
                Label("Importar dados e configurações", systemImage: "square.and.arrow.down")
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
    }

    private func prepareExport() {
        let backup = KepleraeBackup(
            schemaVersion: 2,
            appVersion: "2.0",
            exportedAt: .now,
            notes: notes.notes,
            noteTags: notes.tags,
            questionSubjects: questions.subjects,
            questionRecords: questions.records,
            pomodoroSettings: pomodoro.settings,
            pomodoroHistory: pomodoro.history,
            theme: AppTheme(rawValue: appThemeRaw) ?? .system,
            glassIntensity: glassIntensityPercent,
            googleEmail: auth.email,
            favorites: studyState.favorites.sorted(),
            completed: studyState.completed.sorted(),
            lastOpenedID: studyState.lastOpenedID
        )

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601

        if let data = try? encoder.encode(backup) {
            exportDocument = BackupDocument(data: data)
            exporting = true
        }
    }

    private func importBackup(_ result: Result<URL, Error>) {
        do {
            let url = try result.get()
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }

            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            let backup = try decoder.decode(KepleraeBackup.self, from: data)

            notes.replace(tags: backup.noteTags, notes: backup.notes)
            questions.replace(subjects: backup.questionSubjects, records: backup.questionRecords)
            pomodoro.replace(settings: backup.pomodoroSettings, history: backup.pomodoroHistory)
            if let favorites = backup.favorites, let completed = backup.completed {
                studyState.replace(
                    favorites: Set(favorites),
                    completed: Set(completed),
                    lastOpenedID: backup.lastOpenedID
                )
            }
            appThemeRaw = backup.theme.rawValue
            glassIntensityPercent = backup.glassIntensity
            cloudSync.localDataDidChange()
            message = "Dados importados com sucesso e preparados para sincronização."
        } catch {
            message = "Não foi possível importar: \(error.localizedDescription)"
        }
    }
}

private struct SettingsSection<Content: View>: View {
    let title: String
    let icon: String
    let intensity: Double
    let content: Content

    init(title: String, icon: String, intensity: Double, @ViewBuilder content: () -> Content) {
        self.title = title
        self.icon = icon
        self.intensity = intensity
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label(title, systemImage: icon).font(.title3.bold())
            content
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(20)
        .kepleraeGlass(intensity: intensity, cornerRadius: 28, interactive: false)
    }
}
