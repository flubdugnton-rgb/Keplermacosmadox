import SwiftUI

// MARK: - Contagem regressiva da próxima prova

struct ExamCountdownCard: View {
    @EnvironmentObject private var exams: ExamStore

    /// Materiais ainda não concluídos (para calcular o ritmo diário).
    let remainingMaterials: Int
    let intensity: Double
    let onManage: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label("Próxima prova", systemImage: "calendar.badge.clock")
                    .font(.title3.bold())
                Spacer()
                Button(exams.next == nil ? "Adicionar" : "Gerenciar", action: onManage)
                    .buttonStyle(.glass)
                    .buttonBorderShape(.capsule)
            }

            if let exam = exams.next {
                let days = ExamStore.daysLeft(to: exam.date)

                HStack(alignment: .center, spacing: 20) {
                    VStack(spacing: 0) {
                        Text(days == 0 ? "Hoje" : "\(days)")
                            .font(.system(size: days == 0 ? 34 : 46, weight: .bold, design: .rounded))
                            .monospacedDigit()
                        if days > 0 {
                            Text(days == 1 ? "dia" : "dias")
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(.secondary)
                        }
                    }
                    .frame(minWidth: 78)

                    VStack(alignment: .leading, spacing: 4) {
                        Text(exam.name)
                            .font(.headline)
                            .lineLimit(2)
                        Text(exam.date.formatted(date: .long, time: .omitted))
                            .font(.subheadline)
                            .foregroundStyle(.secondary)

                        if days > 0, remainingMaterials > 0 {
                            let perDay = Int((Double(remainingMaterials) / Double(days)).rounded(.up))
                            Text("Para ver todos os materiais até lá: cerca de \(perDay) por dia")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    Spacer(minLength: 0)
                }
            } else {
                Text("Cadastre a data da sua prova para ver a contagem regressiva e o ritmo de estudo.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(20)
        .background(
            LinearGradient(
                colors: [.orange.opacity(0.16), .pink.opacity(0.08), .clear],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ),
            in: RoundedRectangle(cornerRadius: 30, style: .continuous)
        )
        .kepleraeGlass(intensity: intensity, cornerRadius: 30, interactive: false)
    }
}

// MARK: - Revisões que vencem hoje

struct ReviewsDueCard: View {
    @EnvironmentObject private var reviews: ReviewStore
    @EnvironmentObject private var catalog: CatalogStore

    let intensity: Double

    private let maxRows = 5

    private var dueEntries: [ReviewEntry] { reviews.due() }

    var body: some View {
        let entries = dueEntries

        if !entries.isEmpty {
            let itemsByID = Dictionary(catalog.items.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first })

            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Label("Revisões de hoje", systemImage: "arrow.triangle.2.circlepath")
                        .font(.title3.bold())
                    Spacer()
                    Text("\(entries.count)")
                        .font(.headline.monospacedDigit())
                        .foregroundStyle(.secondary)
                }

                ForEach(entries.prefix(maxRows)) { entry in
                    if let item = itemsByID[entry.itemID] {
                        row(entry: entry, item: item)
                    }
                }

                if entries.count > maxRows {
                    Text("+ \(entries.count - maxRows) revisões")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(20)
            .background(
                LinearGradient(
                    colors: [.mint.opacity(0.16), .teal.opacity(0.08), .clear],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 30, style: .continuous)
            )
            .kepleraeGlass(intensity: intensity, cornerRadius: 30, interactive: false)
        }
    }

    private func row(entry: ReviewEntry, item: StudyItem) -> some View {
        let subject = catalog.subjects.first(where: { $0.id == item.subjectID })?.title ?? item.type.title
        let total = ReviewStore.intervalsInDays.count

        return HStack(spacing: 10) {
            NavigationLink {
                StudyItemView(item: item)
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: item.type.icon)
                        .font(.title3)
                        .foregroundStyle(item.type.tint)
                        .frame(width: 26)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(item.title)
                            .font(.subheadline.weight(.semibold))
                            .lineLimit(2)
                            .multilineTextAlignment(.leading)
                        Text("\(subject) · revisão \(entry.step + 1) de \(total)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 0)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            Button {
                reviews.markForgotten(entry.itemID)
            } label: {
                Image(systemName: "arrow.counterclockwise")
            }
            .buttonStyle(.glass)
            .buttonBorderShape(.circle)
            .help("Esqueci: rever amanhã")
            .accessibilityLabel("Esqueci, rever amanhã")

            Button {
                reviews.markReviewed(entry.itemID)
            } label: {
                Image(systemName: "checkmark")
            }
            .buttonStyle(.glassProminent)
            .buttonBorderShape(.circle)
            .tint(.mint)
            .help("Revisei")
            .accessibilityLabel("Revisei")
        }
    }
}

// MARK: - Gerenciador de provas

struct ExamManagerView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var exams: ExamStore

    @State private var name = ""
    @State private var date = Calendar.current.date(byAdding: .day, value: 30, to: .now) ?? .now

    private var canAdd: Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Provas e concursos")
                    .font(.title2.bold())
                Spacer()
                Button("Fechar") { dismiss() }
                    .keyboardShortcut(.cancelAction)
            }

            HStack(spacing: 10) {
                TextField("Nome (ex.: concurso, seleção, prova)", text: $name)
                    .textFieldStyle(.roundedBorder)
                    .onSubmit(add)
                DatePicker("Data", selection: $date, displayedComponents: .date)
                    .labelsHidden()
                Button("Adicionar", action: add)
                    .buttonStyle(.borderedProminent)
                    .disabled(!canAdd)
            }

            if exams.all.isEmpty {
                ContentUnavailableView(
                    "Nenhuma prova cadastrada",
                    systemImage: "calendar",
                    description: Text("Adicione uma data para ver a contagem regressiva na tela Início.")
                )
                .frame(maxWidth: .infinity, minHeight: 160)
            } else {
                List {
                    ForEach(exams.all) { exam in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(exam.name).font(.headline)
                                Text(detail(for: exam))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button(role: .destructive) {
                                exams.delete(exam.id)
                            } label: {
                                Image(systemName: "trash")
                            }
                            .buttonStyle(.borderless)
                            .help("Remover")
                            .accessibilityLabel("Remover \(exam.name)")
                        }
                        .padding(.vertical, 2)
                    }
                }
                .frame(minHeight: 180)
            }
        }
        .padding(22)
        .frame(minWidth: 560, minHeight: 400)
    }

    private func add() {
        guard canAdd else { return }
        exams.add(name: name, date: date)
        name = ""
    }

    private func detail(for exam: ExamEvent) -> String {
        let formatted = exam.date.formatted(date: .long, time: .omitted)
        let today = Calendar.current.startOfDay(for: .now)
        if Calendar.current.startOfDay(for: exam.date) < today {
            return "\(formatted) · já passou"
        }
        let days = ExamStore.daysLeft(to: exam.date)
        return days == 0 ? "\(formatted) · hoje" : "\(formatted) · em \(days) \(days == 1 ? "dia" : "dias")"
    }
}
