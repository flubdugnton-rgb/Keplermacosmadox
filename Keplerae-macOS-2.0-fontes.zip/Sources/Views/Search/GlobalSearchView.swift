import SwiftUI

/// Busca global aberta com ⌘K: materiais do catálogo (título, arquivo, matéria e pastas) e notas.
/// Ignora acentos e maiúsculas; várias palavras funcionam como "E".
struct GlobalSearchView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var catalog: CatalogStore
    @EnvironmentObject private var notes: NotesStore
    @EnvironmentObject private var studyState: StudyStateStore

    /// Chamado ao escolher uma nota (o RootView troca para a aba Notas).
    let onOpenNotes: () -> Void

    @State private var query = ""
    @FocusState private var focused: Bool

    private let maxItems = 50
    private let maxNotes = 8

    private var trimmedQuery: String {
        query.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var isSearching: Bool { trimmedQuery.count >= 2 }

    private var itemResults: [StudyItem] {
        guard isSearching else { return [] }
        let words = fold(trimmedQuery).split(separator: " ").map(String.init)
        var found: [StudyItem] = []

        for item in catalog.items {
            let haystack = fold("\(item.title) \(item.filename) \(subjectTitle(for: item)) \(item.folderPath.joined(separator: " "))")
            if words.allSatisfy({ haystack.contains($0) }) {
                found.append(item)
                if found.count >= maxItems { break }
            }
        }
        return found
    }

    private var noteResults: [StudyNote] {
        guard isSearching else { return [] }
        return Array(notes.visible(tagID: nil, query: trimmedQuery).prefix(maxNotes))
    }

    var body: some View {
        let items = itemResults
        let foundNotes = noteResults

        NavigationStack {
            VStack(spacing: 0) {
                searchField

                Divider()

                List {
                    if !items.isEmpty {
                        Section("Materiais") {
                            ForEach(items) { item in
                                NavigationLink(value: item) {
                                    itemRow(item)
                                }
                            }
                        }
                    }

                    if !foundNotes.isEmpty {
                        Section("Notas") {
                            ForEach(foundNotes) { note in
                                Button {
                                    dismiss()
                                    onOpenNotes()
                                } label: {
                                    noteRow(note)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .overlay {
                    if !isSearching {
                        ContentUnavailableView(
                            "Buscar no Kepleræ",
                            systemImage: "magnifyingglass",
                            description: Text("Digite ao menos 2 letras para procurar aulas, PDFs, áudios e notas.")
                        )
                    } else if items.isEmpty && foundNotes.isEmpty {
                        ContentUnavailableView.search(text: trimmedQuery)
                    }
                }
            }
            .navigationDestination(for: StudyItem.self) { item in
                StudyItemView(item: item)
            }
        }
        .frame(minWidth: 780, minHeight: 580)
        .onAppear { focused = true }
    }

    // MARK: - Partes

    private var searchField: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.secondary)

            TextField("Buscar aulas, PDFs, áudios e notas", text: $query)
                .textFieldStyle(.plain)
                .font(.title3)
                .focused($focused)

            if !query.isEmpty {
                Button {
                    query = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Limpar busca")
            }

            Button("Fechar") { dismiss() }
                .keyboardShortcut(.cancelAction)
        }
        .padding(16)
    }

    private func itemRow(_ item: StudyItem) -> some View {
        HStack(spacing: 12) {
            Image(systemName: item.type.icon)
                .foregroundStyle(item.type.tint)
                .frame(width: 24)

            VStack(alignment: .leading, spacing: 2) {
                Text(item.title)
                    .font(.body.weight(.medium))
                    .lineLimit(2)
                Text(context(for: item))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }

            Spacer(minLength: 0)

            if studyState.isCompleted(item.id) {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.green)
                    .accessibilityLabel("Concluído")
            }
        }
        .padding(.vertical, 3)
    }

    private func noteRow(_ note: StudyNote) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "note.text")
                .foregroundStyle(.orange)
                .frame(width: 24)

            VStack(alignment: .leading, spacing: 2) {
                Text(note.title.isEmpty ? "Sem título" : note.title)
                    .font(.body.weight(.medium))
                    .lineLimit(1)
                Text(note.body)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
        }
        .padding(.vertical, 3)
        .contentShape(Rectangle())
    }

    // MARK: - Utilidades

    private func subjectTitle(for item: StudyItem) -> String {
        catalog.subjects.first(where: { $0.id == item.subjectID })?.title ?? ""
    }

    private func context(for item: StudyItem) -> String {
        var parts = [subjectTitle(for: item)]
        if let folder = item.folderPath.last { parts.append(folder) }
        return parts.filter { !$0.isEmpty }.joined(separator: " · ")
    }

    private func fold(_ text: String) -> String {
        text.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: .current)
    }
}
