@preconcurrency import AVFoundation
import Combine
import Foundation
import UniformTypeIdentifiers

@MainActor
final class StreamingPlayerController: ObservableObject {
    enum State: Equatable { case preparing, ready, failed(String) }
    @Published private(set) var state: State = .preparing
    let player = AVPlayer()
    private var loader: DriveStreamingResourceLoader?
    private var observation: NSKeyValueObservation?

    func prepare(stream: DriveStreamDescriptor, refreshToken: @escaping @Sendable () async throws -> String) {
        stop()
        state = .preparing
        let loader = DriveStreamingResourceLoader(stream: stream, refreshToken: refreshToken)
        self.loader = loader
        let ext = UTType(mimeType: stream.mimeType)?.preferredFilenameExtension ?? "mp4"
        let url = URL(string: "keplerae-stream://media/\(UUID().uuidString).\(ext)")!
        let asset = AVURLAsset(url: url)
        asset.resourceLoader.setDelegate(loader, queue: .main)
        let item = AVPlayerItem(asset: asset)
        item.preferredForwardBufferDuration = 3
        observation = item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            Task { @MainActor [weak self] in
                guard let self, self.player.currentItem === item else { return }
                switch item.status {
                case .readyToPlay: self.state = .ready
                case .failed: self.state = .failed(item.error?.localizedDescription ?? "Não foi possível iniciar o streaming.")
                default: break
                }
            }
        }
        player.automaticallyWaitsToMinimizeStalling = true
        player.isMuted = false
        player.volume = 1
        player.replaceCurrentItem(with: item)
    }

    func stop() {
        player.pause()
        observation = nil
        player.replaceCurrentItem(with: nil)
        loader?.cancelAll()
        loader = nil
    }
}

/// AVFoundation receives only the requested byte ranges, streamed through RAM.
/// Its cancellation callbacks stop outstanding seeks/loads when the user leaves the player.
@MainActor
private final class DriveStreamingResourceLoader: NSObject, AVAssetResourceLoaderDelegate {
    private let transport: DriveRangeTransport
    private let mimeType: String
    private var tasks: [ObjectIdentifier: Task<Void, Never>] = [:]

    init(stream: DriveStreamDescriptor, refreshToken: @escaping @Sendable () async throws -> String) {
        transport = DriveRangeTransport(stream: stream, refreshToken: refreshToken)
        mimeType = stream.mimeType
    }

    nonisolated func resourceLoader(_ resourceLoader: AVAssetResourceLoader,
                                   shouldWaitForLoadingOfRequestedResource request: AVAssetResourceLoadingRequest) -> Bool {
        MainActor.assumeIsolated { begin(request) }
        return true
    }

    nonisolated func resourceLoader(_ resourceLoader: AVAssetResourceLoader,
                                   didCancel request: AVAssetResourceLoadingRequest) {
        MainActor.assumeIsolated { tasks.removeValue(forKey: ObjectIdentifier(request))?.cancel() }
    }

    private func begin(_ request: AVAssetResourceLoadingRequest) {
        let id = ObjectIdentifier(request)
        tasks[id] = Task { [weak self] in
            guard let self else { return }
            defer { tasks.removeValue(forKey: id) }
            do {
                let dataRequest = request.dataRequest
                var offset = max(dataRequest?.requestedOffset ?? 0, dataRequest?.currentOffset ?? 0)
                let requestedEnd: Int64 = {
                    guard let dataRequest, !dataRequest.requestsAllDataToEndOfResource else { return .max }
                    let (end, overflow) = dataRequest.requestedOffset.addingReportingOverflow(Int64(dataRequest.requestedLength))
                    return overflow ? .max : end
                }()
                repeat {
                    try Task.checkCancellation()
                    guard !request.isCancelled else { return }
                    let chunk = try await transport.read(offset: offset, remaining: dataRequest == nil ? 2 : max(1, requestedEnd - offset))
                    try Task.checkCancellation()
                    guard !request.isCancelled else { return }
                    if let info = request.contentInformationRequest {
                        info.contentType = UTType(mimeType: mimeType)?.identifier ?? UTType(mimeType: chunk.mimeType)?.identifier
                        info.contentLength = chunk.range.total
                        info.isByteRangeAccessSupported = true
                    }
                    guard let dataRequest else { break }
                    dataRequest.respond(with: chunk.data)
                    offset = chunk.range.end + 1
                    if offset >= min(requestedEnd, chunk.range.total) { break }
                } while true
                if !request.isCancelled { request.finishLoading() }
            } catch is CancellationError {
                if !request.isCancelled { request.finishLoading(with: URLError(.cancelled)) }
            } catch {
                if !request.isCancelled { request.finishLoading(with: error) }
            }
        }
    }

    func cancelAll() {
        tasks.values.forEach { $0.cancel() }
        tasks.removeAll()
        transport.cancel()
    }
}
