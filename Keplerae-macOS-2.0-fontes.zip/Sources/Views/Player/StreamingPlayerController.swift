@preconcurrency import AVFoundation
import Combine
import Foundation
import UniformTypeIdentifiers

@MainActor
final class StreamingPlayerController: ObservableObject {
    enum State: Equatable { case preparing, ready, failed(String) }
    @Published private(set) var state: State = .preparing
    let player = AVPlayer()
    private var loader: DriveStreamingResourceLoader?
    private var observations: [NSKeyValueObservation] = []

    func prepare(stream: DriveStreamDescriptor, configuration: URLSessionConfiguration = .ephemeral,
                 refreshToken: @escaping @Sendable () async throws -> String) {
        stop()
        state = .preparing
        let asset: AVURLAsset
        if stream.delivery == .publicDownload {
            // Native HTTP can fetch the audio and video ranges independently in
            // non-interleaved MP4s. Public delivery never carries a Google token.
            asset = AVURLAsset(url: stream.url)
        } else {
            let loader = DriveStreamingResourceLoader(stream: stream, configuration: configuration, refreshToken: refreshToken)
            self.loader = loader
            let ext = UTType(mimeType: stream.mimeType)?.preferredFilenameExtension ?? "mp4"
            let url = URL(string: "keplerae-stream://media/\(UUID().uuidString).\(ext)")!
            asset = AVURLAsset(url: url)
            asset.resourceLoader.setDelegate(loader, queue: .main)
        }
        let item = AVPlayerItem(asset: asset)
        item.preferredForwardBufferDuration = 3
        observations.append(item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            Task { @MainActor [weak self] in
                guard let self, self.player.currentItem === item else { return }
                switch item.status {
                case .readyToPlay: self.state = .ready; self.startBufferedPlaybackIfRequested()
                case .failed: self.state = .failed(item.error?.localizedDescription ?? "Não foi possível iniciar o streaming.")
                default: break
                }
            }
        })
        observations.append(item.observe(\.loadedTimeRanges, options: [.new]) { [weak self] item, _ in
            Task { @MainActor [weak self] in
                guard let self, self.player.currentItem === item else { return }
                self.startBufferedPlaybackIfRequested()
            }
        })
        observations.append(player.observe(\.timeControlStatus, options: [.new]) { [weak self] _, _ in
            Task { @MainActor [weak self] in self?.startBufferedPlaybackIfRequested() }
        })
        observations.append(player.observe(\.reasonForWaitingToPlay, options: [.new]) { [weak self] _, _ in
            Task { @MainActor [weak self] in self?.startBufferedPlaybackIfRequested() }
        })
        player.automaticallyWaitsToMinimizeStalling = true
        player.isMuted = false
        player.volume = 1
        player.replaceCurrentItem(with: item)
    }

    func stop() {
        player.pause()
        observations.removeAll()
        player.replaceCurrentItem(with: nil)
        loader?.cancelAll()
        loader = nil
    }

    /// Long, custom-scheme Drive assets cannot reliably predict whether the whole
    /// lesson will play without a stall. Start once a short playable range exists.
    /// Native Pause changes timeControlStatus, so buffering never overrides it.
    private func startBufferedPlaybackIfRequested() {
        guard state == .ready,
              player.timeControlStatus == .waitingToPlayAtSpecifiedRate,
              player.reasonForWaitingToPlay == .toMinimizeStalls,
              player.rate > 0,
              let item = player.currentItem else { return }
        let time = player.currentTime().seconds
        guard time.isFinite else { return }
        let hasBuffer = item.loadedTimeRanges.contains { value in
            let range = value.timeRangeValue
            return range.start.seconds <= time + 0.05 && CMTimeRangeGetEnd(range).seconds - time >= 0.35
        }
        if hasBuffer { player.playImmediately(atRate: player.rate) }
    }
}

/// AVFoundation receives only the requested byte ranges, streamed through RAM.
/// Its cancellation callbacks stop outstanding seeks/loads when the user leaves the player.
@MainActor
private final class DriveStreamingResourceLoader: NSObject, AVAssetResourceLoaderDelegate {
    private let transport: DriveRangeTransport
    private let mimeType: String
    private var tasks: [ObjectIdentifier: Task<Void, Never>] = [:]

    init(stream: DriveStreamDescriptor, configuration: URLSessionConfiguration,
         refreshToken: @escaping @Sendable () async throws -> String) {
        transport = DriveRangeTransport(stream: stream, configuration: configuration, refreshToken: refreshToken)
        mimeType = stream.mimeType
    }

    nonisolated func resourceLoader(_ resourceLoader: AVAssetResourceLoader,
                                   shouldWaitForLoadingOfRequestedResource request: AVAssetResourceLoadingRequest) -> Bool {
        MainActor.assumeIsolated { begin(request) }
        return true
    }

    nonisolated func resourceLoader(_ resourceLoader: AVAssetResourceLoader,
                                   didCancel request: AVAssetResourceLoadingRequest) {
        MainActor.assumeIsolated { tasks.removeValue(forKey: ObjectIdentifier(request))?.cancel() }
    }

    private func begin(_ request: AVAssetResourceLoadingRequest) {
        let id = ObjectIdentifier(request)
        tasks[id] = Task { [weak self] in
            guard let self else { return }
            defer { tasks.removeValue(forKey: id) }
            do {
                let dataRequest = request.dataRequest
                var offset = max(dataRequest?.requestedOffset ?? 0, dataRequest?.currentOffset ?? 0)
                let requestedEnd: Int64 = {
                    guard let dataRequest, !dataRequest.requestsAllDataToEndOfResource else { return .max }
                    let (end, overflow) = dataRequest.requestedOffset.addingReportingOverflow(Int64(dataRequest.requestedLength))
                    return overflow ? .max : end
                }()
                repeat {
                    try Task.checkCancellation()
                    guard !request.isCancelled else { return }
                    let chunk = try await transport.read(offset: offset, remaining: dataRequest == nil ? 2 : max(1, requestedEnd - offset))
                    try Task.checkCancellation()
                    guard !request.isCancelled else { return }
                    if let info = request.contentInformationRequest {
                        info.contentType = UTType(mimeType: mimeType)?.identifier ?? UTType(mimeType: chunk.mimeType)?.identifier
                        info.contentLength = chunk.range.total
                        info.isByteRangeAccessSupported = true
                    }
                    guard let dataRequest else { break }
                    dataRequest.respond(with: chunk.data)
                    offset = chunk.range.end + 1
                    if offset >= min(requestedEnd, chunk.range.total) { break }
                } while true
                if !request.isCancelled { request.finishLoading() }
            } catch is CancellationError {
                if !request.isCancelled { request.finishLoading(with: URLError(.cancelled)) }
            } catch {
                if !request.isCancelled { request.finishLoading(with: error) }
            }
        }
    }

    func cancelAll() {
        tasks.values.forEach { $0.cancel() }
        tasks.removeAll()
        transport.cancel()
    }
}
