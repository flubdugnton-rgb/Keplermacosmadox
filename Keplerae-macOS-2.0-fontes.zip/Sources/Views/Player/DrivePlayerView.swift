@preconcurrency import AVFoundation
import AppKit
import AVKit
import Combine
import PDFKit
import SwiftUI

struct DrivePlayerView: View {
    @EnvironmentObject private var auth: GoogleAuthStore
    @StateObject private var loader = DriveContentLoader()
    @State private var retryID = 0

    let item: StudyItem

    var body: some View {
        Group {
            switch loader.state {
            case .idle, .loading:
                loadingView("Preparando conteúdo…")

            case .ready(let content):
                NativeStudyContentView(item: item, content: content)

            case .failed(let message):
                ContentUnavailableView {
                    Label("Não foi possível abrir", systemImage: "exclamationmark.triangle.fill")
                } description: {
                    Text(message)
                } actions: {
                    Button("Tentar novamente") {
                        loader.reset()
                        retryID += 1
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
        }
        .task(id: "\(item.id)-\(retryID)") {
            await loader.load(item: item, auth: auth)
        }
    }

    private func loadingView(_ title: String) -> some View {
        VStack(spacing: 14) {
            ProgressView()
                .controlSize(.large)
            Text(title)
                .font(.headline)
            Text("Usando a conta Google já conectada ao Kepleræ.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

private struct NativeStudyContentView: View {
    let item: StudyItem
    let content: DriveContentLoader.PreparedContent

    var body: some View {
        switch (item.type, content) {
        case (.pdf, .local(let url)):
            PDFReaderView(url: url)

        case (.lesson, .stream(let stream)):
            VideoStudyPlayer(item: item, stream: stream)

        case (.audio, .stream(let stream)):
            AudioStudyPlayer(item: item, stream: stream)

        case (.lesson, .local), (.audio, .local):
            ContentUnavailableView("Abra o material novamente", systemImage: "play.circle", description: Text("A reprodução agora usa streaming."))

        case (.pdf, .stream):
            ContentUnavailableView("PDF indisponível", systemImage: "doc.text")
        }
    }
}

private struct PDFReaderView: View {
    let url: URL
    @StateObject private var readerWindow = PDFReaderWindowController()

    var body: some View {
        ZStack(alignment: .topTrailing) {
            PDFDocumentCanvas(url: url)

            Button {
                readerWindow.show(url: url)
            } label: {
                Label("Tela cheia", systemImage: "arrow.up.left.and.arrow.down.right")
                    .font(.subheadline.weight(.semibold))
                    .padding(.horizontal, 12)
                    .frame(height: 42)
            }
            .buttonStyle(.glassProminent)
            .buttonBorderShape(.capsule)
            .padding(12)
            .accessibilityLabel("Abrir PDF em tela cheia")
        }
        .onDisappear {
            readerWindow.close()
        }
    }
}

/// A separate document window participates in macOS Spaces, native full screen,
/// keyboard navigation, and the system's standard window controls.
@MainActor
private final class PDFReaderWindowController: NSObject, ObservableObject, NSWindowDelegate {
    private var window: NSWindow?
    private var documentURL: URL?

    func show(url: URL) {
        if let window, documentURL == url {
            window.makeKeyAndOrderFront(nil)
            if !window.styleMask.contains(.fullScreen) {
                window.toggleFullScreen(nil)
            }
            return
        }

        close()

        let newWindow = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 900, height: 700),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered,
            defer: false
        )
        newWindow.title = "Leitor de PDF — Kepleræ"
        newWindow.minSize = NSSize(width: 500, height: 400)
        newWindow.collectionBehavior = [.fullScreenPrimary]
        newWindow.isReleasedWhenClosed = false
        newWindow.delegate = self
        newWindow.contentView = NSHostingView(rootView: PDFReaderWindowContent(url: url) { [weak self] in
            self?.close()
        })
        newWindow.center()

        window = newWindow
        documentURL = url
        newWindow.makeKeyAndOrderFront(nil)
        newWindow.toggleFullScreen(nil)
    }

    func close() {
        window?.close()
        window = nil
        documentURL = nil
    }

    func windowWillClose(_ notification: Notification) {
        window = nil
        documentURL = nil
    }
}

private struct PDFReaderWindowContent: View {
    let url: URL
    let close: () -> Void

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color(nsColor: .windowBackgroundColor)
            PDFDocumentCanvas(url: url)

            Button(action: close) {
                Label("Fechar leitor", systemImage: "xmark")
                    .padding(.horizontal, 10)
                    .frame(height: 36)
            }
            .buttonStyle(.glassProminent)
            .buttonBorderShape(.capsule)
            .padding(12)
        }
    }
}

private struct PDFDocumentCanvas: NSViewRepresentable {
    let url: URL

    func makeNSView(context: Context) -> PDFView {
        let view = PDFView()
        view.autoScales = true
        view.displayMode = .singlePageContinuous
        view.displayDirection = .vertical
        view.pageShadowsEnabled = true
        view.backgroundColor = .clear
        view.document = PDFDocument(url: url)
        return view
    }

    func updateNSView(_ nsView: PDFView, context: Context) {
        if nsView.document?.documentURL != url {
            nsView.document = PDFDocument(url: url)
        }
    }
}

private struct VideoStudyPlayer: View {
    @EnvironmentObject private var auth: GoogleAuthStore
    @StateObject private var controller = StreamingPlayerController()
    let item: StudyItem
    let stream: DriveStreamDescriptor

    var body: some View {
        ZStack {
            Color.black
            MacVideoPlayer(player: controller.player)
            switch controller.state {
            case .preparing:
                VStack(spacing: 10) {
                    ProgressView().tint(.white)
                    Text("Conectando ao vídeo…").font(.headline)
                    Text("Reprodução por streaming").font(.caption)
                }
                .foregroundStyle(.white).padding(24)
            case .failed(let message):
                ContentUnavailableView("Não foi possível iniciar o streaming", systemImage: "wifi.exclamationmark", description: Text(message))
                    .foregroundStyle(.white)
            case .ready: EmptyView()
            }
        }
        .task(id: stream.url) {
            MediaAudioSession.activatePlayback()
            controller.prepare(stream: stream) { [auth] in try await auth.freshDriveAccessToken() }
        }
        .onDisappear { controller.stop() }
    }
}

private struct AudioStudyPlayer: View {
    @EnvironmentObject private var auth: GoogleAuthStore
    @StateObject private var controller = StreamingPlayerController()
    @State private var isPlaying = false
    let item: StudyItem
    let stream: DriveStreamDescriptor

    var body: some View {
        VStack(spacing: 22) {
            Spacer()
            Image(systemName: "waveform.circle.fill")
                .font(.system(size: 90)).foregroundStyle(.purple.gradient)
                .symbolEffect(.pulse, isActive: isPlaying)
            Text(item.title).font(.title3.bold()).multilineTextAlignment(.center).lineLimit(3)
            switch controller.state {
            case .preparing: ProgressView("Conectando ao áudio…")
            case .failed(let message): Text(message).font(.caption).foregroundStyle(.secondary)
            case .ready: Text(isPlaying ? "Reproduzindo" : "Pronto para ouvir").foregroundStyle(.secondary)
            }
            Button {
                if isPlaying { controller.player.pause() } else { controller.player.play() }
                isPlaying.toggle()
            } label: {
                Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 28, weight: .semibold)).frame(width: 76, height: 76)
            }
            .buttonStyle(.glassProminent).buttonBorderShape(.circle).tint(.purple)
            .disabled(controller.state != .ready)
            Spacer()
        }
        .padding(28)
        .task(id: stream.url) {
            MediaAudioSession.activatePlayback()
            controller.prepare(stream: stream) { [auth] in try await auth.freshDriveAccessToken() }
        }
        .onDisappear { controller.stop(); isPlaying = false }
    }
}

/// AppKit's AVPlayerView avoids the AVKit SwiftUI VideoPlayer metadata crash
/// present on macOS 27 while retaining native playback controls.
private struct MacVideoPlayer: NSViewRepresentable {
    let player: AVPlayer

    func makeNSView(context: Context) -> AVPlayerView {
        let view = AVPlayerView()
        view.controlsStyle = .floating
        view.showsFullScreenToggleButton = true
        view.player = player
        return view
    }

    func updateNSView(_ nsView: AVPlayerView, context: Context) {
        if nsView.player !== player {
            nsView.player = player
        }
    }
}
