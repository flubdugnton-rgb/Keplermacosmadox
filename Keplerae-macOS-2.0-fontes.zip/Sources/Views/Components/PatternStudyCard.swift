import SwiftUI

private struct PatternColors {
    let background: Color
    let foreground: Color
    let dots: Color
    let glow: Color
    let glowOpacity: Double

    static func forVariant(_ variant: PatternCardVariant, subjectID: String?) -> Self {
        switch subjectID {
        case "hu_legislacao":
            return .init(background: Color(red: 36/255, green: 74/255, blue: 130/255), foreground: .white,
                         dots: .white, glow: .cyan, glowOpacity: 0.35)
        case "sus":
            return .init(background: Color(red: 27/255, green: 113/255, blue: 85/255), foreground: .white,
                         dots: .white, glow: .mint, glowOpacity: 0.35)
        case "profisio":
            return .init(background: Color(red: 119/255, green: 85/255, blue: 166/255), foreground: .white,
                         dots: .white, glow: .pink, glowOpacity: 0.35)
        default: break
        }
        switch variant {
        case .a: return .init(background: Color(red: 10/255, green: 10/255, blue: 10/255), foreground: .white,
                             dots: .white, glow: .white, glowOpacity: 0.12)
        case .b: return .init(background: Color(red: 1, green: 110/255, blue: 0), foreground: .white,
                             dots: .white, glow: Color(red: 1, green: 176/255, blue: 102/255), glowOpacity: 0.55)
        case .c: return .init(background: Color(red: 236/255, green: 235/255, blue: 233/255),
                             foreground: Color(white: 31/255), dots: Color(red: 1, green: 110/255, blue: 0),
                             glow: Color(red: 1, green: 110/255, blue: 0), glowOpacity: 0.18)
        }
    }
}

/// Mesmo componente nos cards da home e no topo de cada matéria/pasta.
struct PatternStudyCard: View {
    let title: String
    let subtitle: String
    let count: Int
    let variant: PatternCardVariant
    let subjectID: String?
    var progress: Double? = nil
    var height: Double = PatternCardParameters.defaults.card.height
    var dimPattern = false
    var onHoverChange: (Bool) -> Void = { _ in }

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var visible = false
    @State private var cursor: CGPoint? = nil
    @State private var hoverStart = 0.0
    @State private var engine = PatternAnimationEngine(variant: .a)

    init(title: String, subtitle: String, count: Int, variant: PatternCardVariant, subjectID: String? = nil, progress: Double? = nil,
         height: Double = PatternCardParameters.defaults.card.height, dimPattern: Bool = false,
         onHoverChange: @escaping (Bool) -> Void = { _ in }) {
        self.title = title
        self.subtitle = subtitle
        self.count = count
        self.variant = variant
        self.subjectID = subjectID
        self.progress = progress
        self.height = height
        self.dimPattern = dimPattern
        self.onHoverChange = onHoverChange
        let seed = title.utf8.reduce(UInt64(5381)) { ($0 &* 33) &+ UInt64($1) }
        _engine = State(initialValue: PatternAnimationEngine(variant: variant, seed: seed))
    }

    private let p = PatternCardParameters.defaults

    var body: some View {
        let colors = PatternColors.forVariant(variant, subjectID: subjectID)
        GeometryReader { geometry in
            let banner = height < p.card.height
            let padding = banner ? 28.0 : (geometry.size.width * 0.118).rounded()
            ZStack(alignment: banner ? .leading : .bottomLeading) {
                colors.background
                artwork(size: geometry.size, padding: padding, banner: banner, colors: colors)
                VStack(alignment: .leading, spacing: (0.018 * height).rounded()) {
                    Text(title)
                        .font(.system(size: p.typography.titleSize, weight: .bold))
                        .tracking(-0.02 * p.typography.titleSize)
                        .lineLimit(banner ? 3 : 2)
                        .minimumScaleFactor(0.65)
                        .multilineTextAlignment(.leading)
                    Text(subtitle)
                        .font(.system(size: p.typography.descriptionSize, weight: .thin))
                        .tracking(-0.01 * p.typography.descriptionSize)
                        .opacity(0.7)
                        .lineLimit(banner ? 2 : 1)
                        .multilineTextAlignment(.leading)
                    HStack {
                        Text(count == 1 ? "1 material" : "\(count) materiais")
                        Spacer(minLength: 0)
                        if let progress { Text("\(Int(progress * 100))%").monospacedDigit() }
                    }
                    .font(.caption)
                    .opacity(0.7)
                    if let progress {
                        ThinProgressBar(value: progress, tint: colors.foreground)
                            .frame(height: 4)
                    }
                }
                .foregroundStyle(colors.foreground)
                .frame(maxWidth: banner ? geometry.size.width * 0.57 : .infinity, alignment: .leading)
                .padding(padding)
            }
            .clipShape(RoundedRectangle(cornerRadius: 44.875, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 44.875, style: .continuous))
            .onContinuousHover { phase in
                switch phase {
                case .active(let location):
                    if cursor == nil {
                        hoverStart = Date.now.timeIntervalSinceReferenceDate
                        onHoverChange(true)
                    }
                    cursor = location
                case .ended:
                    cursor = nil
                    onHoverChange(false)
                }
            }
        }
        .frame(height: height)
        .onAppear { visible = true }
        .onDisappear { visible = false; cursor = nil; onHoverChange(false) }
        .accessibilityElement(children: .combine)
    }

    private func artwork(size: CGSize, padding: Double, banner: Bool, colors: PatternColors) -> some View {
        TimelineView(.animation(minimumInterval: 1.0 / 60, paused: !visible || reduceMotion || scenePhase != .active)) { timeline in
            let time = timeline.date.timeIntervalSinceReferenceDate
            Canvas { context, canvasSize in
                drawHighlight(context: &context, size: canvasSize, colors: colors)
                let patternSize: Double = {
                    switch variant {
                    case .a: return p.patternA.size
                    case .b: return p.patternB.size
                    case .c: return p.patternC.size
                    }
                }()
                let scale = p.effect.scale
                let span = patternSize * scale
                // Cabeçalhos largos reservam uma coluna própria para a arte.
                // A área do texto nunca participa das colisões/centralização dos círculos.
                let origin = CGPoint(x: banner ? size.width * 0.78 - span / 2 : padding,
                                     y: banner ? (height - span) / 2 : padding)
                let centerOffset = banner ? CGPoint.zero : CGPoint(
                    x: ((size.width - span) / 2 - padding) / scale,
                    y: ((height - span) / 2 - padding + p.tilt.centerOffsetY) / scale
                )
                let localCursor = cursor.map { CGPoint(x: ($0.x - origin.x) / scale, y: ($0.y - origin.y) / scale) }
                let footerEstimate = (1.05 * p.typography.titleSize + 2.5 * p.typography.descriptionSize + 0.018 * height).rounded() + 32
                let fallHeight = max(0, height - 2 * padding - patternSize - footerEstimate) / scale
                let targetOpacity = p.tilt.fadeOthers && dimPattern ? p.tilt.othersOpacity : 1
                let frame = engine.frame(time: time, cursor: localCursor, centerOffset: centerOffset,
                                         fallHeight: fallHeight, staticTarget: targetOpacity,
                                         parameters: p, reducedMotion: reduceMotion)
                var pattern = context
                if banner {
                    pattern.clip(to: Path(CGRect(x: size.width * 0.64, y: 0, width: size.width * 0.36, height: height)))
                }
                pattern.translateBy(x: origin.x, y: origin.y)
                pattern.scaleBy(x: scale, y: scale)
                draw(frame.dots, context: &pattern, color: colors.dots)
                draw(frame.particles, context: &pattern, color: colors.dots)
                if cursor != nil && !reduceMotion { drawShimmer(context: &context, size: canvasSize, elapsed: time - hoverStart) }
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    private func draw(_ dots: [PatternAnimationEngine.Dot], context: inout GraphicsContext, color: Color) {
        for dot in dots {
            if dot.solidRadius > 0.01 {
                context.fill(Path(ellipseIn: rect(center: dot.center, radius: dot.solidRadius)),
                             with: .color(color.opacity(dot.opacity)))
            }
            if dot.ringRadius > 0 {
                context.stroke(Path(ellipseIn: rect(center: dot.center, radius: dot.ringRadius)),
                               with: .color(color.opacity(dot.ringOpacity * dot.opacity)), lineWidth: dot.ringWidth)
            }
        }
    }

    private func drawHighlight(context: inout GraphicsContext, size: CGSize, colors: PatternColors) {
        context.drawLayer { layer in
            layer.addFilter(.blur(radius: 8))
            let diameter = size.width * 1.45
            layer.fill(Path(CGRect(origin: .zero, size: size)), with: .radialGradient(
                Gradient(stops: [.init(color: colors.glow.opacity(colors.glowOpacity), location: 0),
                                 .init(color: colors.glow.opacity(colors.glowOpacity), location: 0.18),
                                 .init(color: .clear, location: 0.65)]),
                center: CGPoint(x: p.highlight.x * size.width, y: p.highlight.y * size.height),
                startRadius: 0, endRadius: diameter / sqrt(2)
            ))
        }
    }

    private func drawShimmer(context: inout GraphicsContext, size: CGSize, elapsed: Double) {
        guard p.shimmer.enabled else { return }
        let width = size.width * p.shimmer.widthPct / 100
        let tangent = tan(p.shimmer.angleDeg * .pi / 180)
        let overshoot = size.height * abs(tangent)
        let start = -width - overshoot
        let distance = size.width + overshoot - start
        let duration = distance / (size.width / max(1, p.shimmer.durationMs)) / 1000
        let phase = elapsed.truncatingRemainder(dividingBy: duration + p.shimmer.loopDelayMs / 1000)
        guard phase >= 0 && phase < duration else { return }
        let t = phase / duration
        let eased = t < 0.5 ? 4 * t * t * t : 1 - pow(-2 * t + 2, 3) / 2
        context.drawLayer { layer in
            layer.blendMode = .screen
            layer.opacity = p.shimmer.intensity
            layer.addFilter(.blur(radius: p.shimmer.blurPx))
            layer.concatenate(CGAffineTransform(a: 1, b: 0, c: -tangent, d: 1, tx: start + eased * distance, ty: -size.height / 2))
            layer.fill(Path(CGRect(x: 0, y: 0, width: width, height: size.height * 2)), with: .linearGradient(
                Gradient(stops: [.init(color: .clear, location: 0), .init(color: .white.opacity(0.08), location: 0.2),
                                 .init(color: .white.opacity(0.35), location: 0.38), .init(color: .white.opacity(0.85), location: 0.5),
                                 .init(color: .white.opacity(0.35), location: 0.62), .init(color: .white.opacity(0.08), location: 0.8),
                                 .init(color: .clear, location: 1)]), startPoint: .zero, endPoint: CGPoint(x: width, y: 0)))
        }
    }

    private func rect(center: CGPoint, radius: Double) -> CGRect {
        CGRect(x: center.x - radius, y: center.y - radius, width: radius * 2, height: radius * 2)
    }
}
