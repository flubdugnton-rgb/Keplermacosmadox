import SwiftUI

/// The same fill/ring/particle engine used on the home cards, adapted to smaller cards.
/// Artwork stays behind the existing content and never takes focus or clicks from controls.
struct PatternCardDecoration: View {
    let cursor: CGPoint?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @State private var visible = false
    @State private var hoverStart = 0.0
    @State private var engine = PatternAnimationEngine(variant: .a)

    var body: some View {
        GeometryReader { geometry in
            TimelineView(.animation(minimumInterval: 1.0 / 30,
                                    paused: !visible || reduceMotion || scenePhase != .active)) { timeline in
                Canvas { context, size in
                    let p = PatternCardParameters.defaults
                    let side = min(106, max(44, size.height * 0.72))
                    let scale = side / p.patternA.size
                    let origin = CGPoint(x: max(0, size.width - side - 18), y: (size.height - side) / 2)
                    let localCursor = cursor.map { CGPoint(x: ($0.x - origin.x) / scale, y: ($0.y - origin.y) / scale) }
                    let frame = engine.frame(time: timeline.date.timeIntervalSinceReferenceDate,
                                             cursor: localCursor, centerOffset: .zero, fallHeight: 35,
                                             staticTarget: 1, parameters: p, reducedMotion: reduceMotion)
                    let originalContext = context
                    context.translateBy(x: origin.x, y: origin.y)
                    context.scaleBy(x: scale, y: scale)
                    let color = Color.primary.opacity(cursor == nil ? 0.09 : 0.18)
                    for dot in frame.dots + frame.particles {
                        func circle(_ radius: Double) -> Path {
                            Path(ellipseIn: CGRect(x: dot.center.x - radius, y: dot.center.y - radius,
                                                   width: radius * 2, height: radius * 2))
                        }
                        if dot.solidRadius > 0 { context.fill(circle(dot.solidRadius), with: .color(color.opacity(dot.opacity))) }
                        if dot.ringRadius > 0 {
                            context.stroke(circle(dot.ringRadius), with: .color(color.opacity(dot.ringOpacity * dot.opacity)), lineWidth: dot.ringWidth)
                        }
                    }
                    if cursor != nil && !reduceMotion {
                        let elapsed = timeline.date.timeIntervalSinceReferenceDate - hoverStart
                        let phase = elapsed.truncatingRemainder(dividingBy: 3)
                        if phase < 0.8 {
                            var sheen = originalContext
                            sheen.addFilter(.blur(radius: 10))
                            let x = -size.width * 0.4 + phase / 0.8 * size.width * 1.8
                            sheen.fill(Path(CGRect(x: x, y: 0, width: size.width * 0.35, height: size.height)), with: .linearGradient(
                                Gradient(colors: [.clear, .white.opacity(0.12), .clear]),
                                startPoint: CGPoint(x: x, y: 0), endPoint: CGPoint(x: x + size.width * 0.35, y: 0)))
                        }
                    }
                }
                .frame(width: geometry.size.width, height: geometry.size.height)
            }
        }
        .clipped()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
        .onChange(of: cursor != nil) { _, active in
            if active { hoverStart = Date.now.timeIntervalSinceReferenceDate }
        }
        .onAppear { visible = true }
        .onDisappear { visible = false }
        .onScrollVisibilityChange(threshold: 0.01) { visible = $0 }
    }
}
