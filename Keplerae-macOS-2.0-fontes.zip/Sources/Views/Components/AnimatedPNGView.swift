import AppKit
import ImageIO
import SwiftUI

/// Displays the original APNG frames with their transparent alpha and timing.
struct AnimatedPNGView: NSViewRepresentable {
    let resourceName: String

    func makeNSView(context: Context) -> AnimatedPNGImageView {
        let view = AnimatedPNGImageView()
        view.imageScaling = .scaleProportionallyUpOrDown
        view.imageFrameStyle = .none
        view.load(resourceName: resourceName)
        return view
    }

    func updateNSView(_ nsView: AnimatedPNGImageView, context: Context) {
        nsView.load(resourceName: resourceName)
    }

    static func dismantleNSView(_ nsView: AnimatedPNGImageView, coordinator: ()) {
        nsView.stopAnimating()
    }
}

@MainActor
final class AnimatedPNGImageView: NSImageView {
    private struct Frame {
        let image: NSImage
        let duration: TimeInterval
    }

    private var resourceName: String?
    private var frames: [Frame] = []
    private var frameIndex = 0
    private var animationTask: Task<Void, Never>?

    // SwiftUI controls layout; the bitmap's pixel dimensions must not impose a
    // minimum size on the Pomodoro panel.
    override var intrinsicContentSize: NSSize {
        NSSize(width: NSView.noIntrinsicMetric, height: NSView.noIntrinsicMetric)
    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        if window == nil {
            stopAnimating()
        } else {
            startAnimating()
        }
    }

    func load(resourceName name: String) {
        guard resourceName != name else {
            startAnimating()
            return
        }

        stopAnimating()
        resourceName = name
        setAccessibilityIdentifier(name)
        frames = Self.readFrames(named: name)
        frameIndex = 0
        image = frames.first?.image
        startAnimating()
    }

    func stopAnimating() {
        animationTask?.cancel()
        animationTask = nil
    }

    private func startAnimating() {
        guard window != nil, frames.count > 1, animationTask == nil else { return }

        animationTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                guard let duration = self?.currentFrameDuration else { return }
                do {
                    try await Task.sleep(for: .seconds(duration))
                } catch {
                    return
                }
                guard !Task.isCancelled else { return }
                self?.advanceFrame()
            }
        }
    }

    private var currentFrameDuration: TimeInterval {
        frames[frameIndex].duration
    }

    private func advanceFrame() {
        guard !frames.isEmpty else { return }
        frameIndex = (frameIndex + 1) % frames.count
        image = frames[frameIndex].image
    }

    private static func readFrames(named name: String) -> [Frame] {
        let url = Bundle.main.url(forResource: name, withExtension: "png")
            ?? Bundle.main.url(forResource: name, withExtension: "png", subdirectory: "Animations")
            ?? Bundle.main.url(forResource: name, withExtension: "png", subdirectory: "Resources/Animations")
        guard let url,
              let source = CGImageSourceCreateWithURL(url as CFURL, nil) else { return [] }

        let count = CGImageSourceGetCount(source)
        var frames: [Frame] = []
        frames.reserveCapacity(count)

        for index in 0..<count {
            guard let cgImage = CGImageSourceCreateImageAtIndex(source, index, nil) else { continue }
            let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [String: Any]
            let png = properties?[kCGImagePropertyPNGDictionary as String] as? [String: Any]
            let delay = (png?[kCGImagePropertyAPNGUnclampedDelayTime as String] as? NSNumber)?.doubleValue
                ?? (png?[kCGImagePropertyAPNGDelayTime as String] as? NSNumber)?.doubleValue
                ?? 0.13
            let image = NSImage(
                cgImage: cgImage,
                size: NSSize(width: cgImage.width, height: cgImage.height)
            )
            // The included animations contain 12 frames at 0.13 s. Reading the
            // metadata also preserves timing if the original artwork changes.
            frames.append(Frame(image: image, duration: delay > 0 ? delay : 0.13))
        }
        return frames
    }
}
