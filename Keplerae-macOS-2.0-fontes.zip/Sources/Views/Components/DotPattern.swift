import Foundation
import SwiftUI

/// Padrões de pontos usados como arte dos cards de matéria.
enum DotPatternKind: CaseIterable, Sendable {
    case grid       // grade uniforme
    case wave       // ondas de tamanho variável
    case radial     // nasce do canto superior direito e se dissolve
    case diagonal   // faixas diagonais
    case scatter    // pontos espalhados (determinístico)
}

/// Desenha pontos em `Canvas` (sem imagens). Com `animated` os pontos pulsam em onda;
/// a animação só roda enquanto `animated` é verdadeiro.
struct DotPattern: View {
    var kind: DotPatternKind
    var color: Color
    var spacing: CGFloat = 13
    var animated = false

    @State private var start: Date?

    var body: some View {
        let k = kind
        let c = color
        let s = spacing
        let isAnimated = animated

        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !isAnimated)) { timeline in
            let t = start.map { timeline.date.timeIntervalSince($0) * 1.6 } ?? 0

            Canvas { ctx, size in
                drawDots(into: &ctx, size: size, kind: k, color: c, spacing: s, pulse: isAnimated ? t : nil)
            }
        }
        .onChange(of: animated) { _, isOn in
            start = isOn ? .now : nil
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

// MARK: - Desenho (funções livres: o Canvas não precisa capturar a View)

private func drawDots(
    into ctx: inout GraphicsContext,
    size: CGSize,
    kind: DotPatternKind,
    color: Color,
    spacing: CGFloat,
    pulse: Double?
) {
    let cols = Int(size.width / spacing) + 1
    let rows = Int(size.height / spacing) + 1

    for row in 0..<rows {
        for col in 0..<cols {
            let x = CGFloat(col) * spacing + spacing / 2
            let y = CGFloat(row) * spacing + spacing / 2

            var r = dotRadius(kind: kind, col: col, row: row, x: x, y: y, size: size)
            if let t = pulse {
                r *= 1 + 0.25 * CGFloat(sin(t * 2 + Double(col + row) * 0.35))
            }
            guard r > 0.25 else { continue }

            let rect = CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)
            ctx.fill(Path(ellipseIn: rect), with: .color(color))
        }
    }
}

private func dotRadius(kind: DotPatternKind, col: Int, row: Int, x: CGFloat, y: CGFloat, size: CGSize) -> CGFloat {
    switch kind {
    case .grid:
        return 1.5
    case .wave:
        let s = sin(Double(x) / 26 + Double(y) / 17)
        return CGFloat(0.6 + 1.9 * (0.5 + 0.5 * s))
    case .radial:
        let d = hypot(x - size.width, y) / max(size.width, 1)
        return max(0, 2.8 - d * 3.4)
    case .diagonal:
        return (col + row) % 4 == 0 ? 2.2 : 0.8
    case .scatter:
        let h = dotHash(col, row)
        return h > 0.5 ? CGFloat(h) * 2.4 : 0
    }
}

private func dotHash(_ a: Int, _ b: Int) -> Double {
    var h = UInt64(truncatingIfNeeded: a) &* 374_761_393 &+ UInt64(truncatingIfNeeded: b) &* 668_265_263
    h = (h ^ (h >> 13)) &* 1_274_126_177
    return Double((h ^ (h >> 16)) & 0xFFFF) / 65_535.0
}

// MARK: - Barra de progresso fina dos cards

struct ThinProgressBar: View {
    let value: Double
    let tint: Color

    var body: some View {
        Capsule()
            .fill(tint.opacity(0.18))
            .overlay(alignment: .leading) {
                GeometryReader { geo in
                    let w = geo.size.width * min(max(value, 0), 1)
                    Capsule()
                        .fill(tint)
                        .frame(width: value > 0 ? max(5, w) : 0)
                }
            }
            .frame(height: 5)
    }
}
