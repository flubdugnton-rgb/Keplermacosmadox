import SwiftUI

struct LibraryView: View {
    @EnvironmentObject private var catalog: CatalogStore
    @AppStorage("glassIntensityPercent") private var glassIntensityPercent = 85
    private let initialType: StudyContentType?
    private let embedded: Bool
    init(initialType: StudyContentType? = nil, embedded: Bool = false) {
        self.initialType = initialType
        self.embedded = embedded
    }
    private var intensity: Double { Double(glassIntensityPercent) / 100 }

    var body: some View {
        Group {
            if embedded {
                libraryContent
            } else {
                NavigationStack {
                    libraryContent
                        .navigationDestination(for: StudyRoute.self) { route in
                            StudyRouteDestination(route: route)
                        }
                }
            }
        }
    }

    private var libraryContent: some View {
        ZStack {
            AmbientBackground(style: .library)
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(initialType?.title ?? "Biblioteca")
                            .font(.largeTitle.bold())
                        Text("Aulas, PDFs e áudios do seu catálogo.")
                            .foregroundStyle(.secondary)
                        Text("\(catalog.items.count) materiais · \(catalog.count(for: .lesson)) aulas · \(catalog.count(for: .pdf)) PDFs · \(catalog.count(for: .audio)) áudios")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.secondary)
                        if let error = catalog.loadError {
                            Label(error, systemImage: "exclamationmark.triangle.fill")
                                .font(.caption)
                                .foregroundStyle(.orange)
                        }
                    }

                    ForEach(catalog.subjects) { subject in
                        NavigationLink(value: StudyRoute.subject(subject, type: initialType)) {
                            LibrarySubjectCard(subject: subject, count: catalog.items(for: subject, type: initialType).count, intensity: intensity)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 24)
                .padding(.bottom, 32)
                .frame(maxWidth: 1040)
                .frame(maxWidth: .infinity)
            }
            .scrollIndicators(.hidden)
        }
        .navigationTitle(initialType?.title ?? "Biblioteca")
    }
}

private struct LibrarySubjectCard: View {
    let subject: Subject
    let count: Int
    let intensity: Double

    var body: some View {
        PatternStudyCard(
            title: subject.title, subtitle: subject.subtitle,
            count: count, variant: .forSubject(subject.id), subjectID: subject.id, height: 280
        )
    }
}
