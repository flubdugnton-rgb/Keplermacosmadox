import SwiftUI

struct StudyRouteDestination: View {
    let route: StudyRoute

    var body: some View {
        switch route {
        case .library(let type):
            LibraryView(initialType: type, embedded: true)
        case .subject(let subject, let type):
            SubjectDetailView(subject: subject, preferredType: type)
        case .folder(let subject, let type, let status, let path):
            FolderBrowserView(
                subject: subject, type: type,
                status: StudyStatusFilter(rawValue: status) ?? .all, path: path
            )
        case .item(let item):
            StudyItemView(item: item)
        }
    }
}
