import SwiftUI

struct StudyItemView: View {
    @EnvironmentObject private var studyState: StudyStateStore
    @EnvironmentObject private var reviews: ReviewStore
    @AppStorage("glassIntensityPercent") private var glassIntensityPercent = 85

    let item: StudyItem

    private var intensity: Double { Double(glassIntensityPercent) / 100 }

    var body: some View {
        GeometryReader { proxy in
            ZStack {
                AmbientBackground(style: .library)

                ScrollView {
                    VStack(spacing: 12) {
                        player(proxy: proxy)

                        actionButtons
                    }
                    .padding(.horizontal, 24)
                    .padding(.top, 6)
                    .padding(.bottom, 32)
                    .frame(maxWidth: 1200)
                    .frame(maxWidth: .infinity)
                }
                .scrollIndicators(.hidden)
            }
        }
        .navigationTitle(item.title)
        .onAppear { studyState.markOpened(item.id) }
    }

    @ViewBuilder
    private func player(proxy: GeometryProxy) -> some View {
        if !item.driveFileID.isEmpty {
            DrivePlayerView(item: item)
                .frame(height: playerHeight(width: min(proxy.size.width, 1200) - 48, viewportHeight: proxy.size.height))
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                .kepleraeGlass(intensity: intensity, cornerRadius: 24, interactive: false, animatedPattern: false)
        } else {
            ContentUnavailableView(
                "Conteúdo indisponível",
                systemImage: item.type.icon,
                description: Text("O link deste conteúdo não é válido.")
            )
            .frame(height: 300)
        }
    }

    private var actionButtons: some View {
        HStack(spacing: 10) {
            Button {
                studyState.toggleFavorite(item.id)
            } label: {
                Label(
                    studyState.isFavorite(item.id) ? "Favoritado" : "Favoritar",
                    systemImage: studyState.isFavorite(item.id) ? "star.fill" : "star"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)
            .buttonBorderShape(.capsule)

            Button {
                let wasCompleted = studyState.isCompleted(item.id)
                studyState.toggleCompleted(item.id)
                if wasCompleted {
                    reviews.cancel(item.id)
                } else {
                    reviews.schedule(item.id)
                }
            } label: {
                Label(
                    studyState.isCompleted(item.id) ? "Concluído" : "Concluir",
                    systemImage: studyState.isCompleted(item.id) ? "checkmark.circle.fill" : "checkmark.circle"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .buttonBorderShape(.capsule)
        }
        .controlSize(.large)
        .padding(.top, 2)
    }

    private func playerHeight(width: CGFloat, viewportHeight: CGFloat) -> CGFloat {
        switch item.type {
        case .lesson:
            return min(max(width * 9.0 / 16.0, 280), max(viewportHeight - 150, 320))
        case .pdf:
            return max(viewportHeight - 150, 440)
        case .audio:
            return min(max(viewportHeight * 0.48, 320), 440)
        }
    }
}
