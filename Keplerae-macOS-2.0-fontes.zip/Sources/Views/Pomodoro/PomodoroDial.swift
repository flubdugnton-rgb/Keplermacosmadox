import Foundation
import SwiftUI

// MARK: - Acabamentos (tokens de cor) por fase

/// Cores de um "acabamento" do dial. Cada fase do Pomodoro usa um.
struct DialFinish {
    let surface: Color   // corpo do widget
    let ink: Color       // textos e marcações
    let accent: Color    // ponteiro, marcas percorridas
    let shadow: Color    // sombra colorida

    /// Foco: grafite com o roxo do app
    static let graphite = DialFinish(
        surface: Color(dialHex: 0x1E1E24),
        ink: Color(dialHex: 0xF2F2F4),
        accent: Color(dialHex: 0xB69CFF),
        shadow: Color(dialHex: 0xB69CFF).opacity(0.28)
    )

    /// Pausa curta: porcelana com verde-água
    static let porcelain = DialFinish(
        surface: Color(dialHex: 0xF6F6F8),
        ink: Color(dialHex: 0x2C2C2F),
        accent: Color(dialHex: 0x1FA38A),
        shadow: Color.black.opacity(0.16)
    )

    /// Pausa longa: azul profundo com azul-gelo
    static let deepSea = DialFinish(
        surface: Color(dialHex: 0x22395A),
        ink: Color(dialHex: 0xE6F1FF),
        accent: Color(dialHex: 0x8CCBFF),
        shadow: Color(dialHex: 0x8CCBFF).opacity(0.24)
    )
}

private extension Color {
    init(dialHex hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }
}

extension PomodoroPhase {
    var finish: DialFinish {
        switch self {
        case .focus: return .graphite
        case .shortBreak: return .porcelain
        case .longBreak: return .deepSea
        }
    }
}

// MARK: - Widget do dial

struct PomodoroDial: View {
    @EnvironmentObject private var store: PomodoroStore

    /// "2 de 4": foco em andamento conta o atual; pausas mostram quantos já foram concluídos.
    private var cyclePosition: Int {
        let position = store.phase == .focus ? store.cycle + 1 : store.cycle
        return min(max(position, 1), max(store.settings.cycles, 1))
    }

    var body: some View {
        let finish = store.phase.finish
        let corner: CGFloat = 48

        ZStack {
            RoundedRectangle(cornerRadius: corner, style: .continuous)
                .fill(finish.surface)
                .overlay(
                    RoundedRectangle(cornerRadius: corner, style: .continuous)
                        .strokeBorder(
                            LinearGradient(
                                colors: [.white.opacity(0.32), .clear],
                                startPoint: .top,
                                endPoint: .bottom
                            ),
                            lineWidth: 1.2
                        )
                )
                .shadow(color: finish.shadow, radius: 30, y: 18)

            // 30 quadros/s só enquanto o timer roda; parado, desenha uma vez
            TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !store.running)) { timeline in
                ZStack {
                    DialFace(finish: finish, progress: progress(at: timeline.date))
                        .padding(.horizontal, 30)
                        .padding(.vertical, 74)

                    VStack {
                        pill(finish) {
                            Text(timeString(store.remainingSeconds))
                                .font(.system(size: 30, weight: .light, design: .rounded))
                                .monospacedDigit()
                                .contentTransition(.numericText(countsDown: true))
                                .animation(.snappy, value: store.remainingSeconds)
                        }
                        Spacer()
                        pill(finish) {
                            Text("\(store.phase.title) · \(cyclePosition) de \(max(store.settings.cycles, 1))")
                                .font(.system(size: 12, weight: .medium, design: .monospaced))
                        }
                    }
                    .padding(.vertical, 20)
                    .foregroundStyle(finish.ink)
                }
            }
        }
        .frame(width: 380, height: 400)
        // todas as cores do acabamento interpolam quando a fase muda
        .animation(.easeInOut(duration: 0.7), value: store.phase)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Pomodoro, \(store.phase.title)")
        .accessibilityValue("Restam \(timeString(store.remainingSeconds))")
    }

    /// Progresso suave (0...1) usando o fim previsto da fase; parado, usa os segundos restantes.
    private func progress(at date: Date) -> Double {
        let total = Double(max(1, store.settings.minutes(for: store.phase) * 60))
        let remaining: Double
        if store.running, let end = store.phaseDeadline {
            remaining = max(0, end.timeIntervalSince(date))
        } else {
            remaining = Double(store.remainingSeconds)
        }
        return min(max(1 - remaining / total, 0), 1)
    }

    private func timeString(_ seconds: Int) -> String {
        String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }

    private func pill<Content: View>(_ f: DialFinish, @ViewBuilder _ content: () -> Content) -> some View {
        content()
            .padding(.horizontal, 20)
            .padding(.vertical, 7)
            .background(f.ink.opacity(0.08), in: Capsule())
            .overlay(Capsule().strokeBorder(f.ink.opacity(0.10), lineWidth: 1))
    }
}

// MARK: - Mostrador

private struct DialFace: View {
    let finish: DialFinish
    let progress: Double

    var body: some View {
        let finish = self.finish
        let progress = self.progress

        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height)
            let r = size / 2

            ZStack {
                // 60 marcas; a cada 5 uma maior. As já percorridas acendem.
                Canvas { ctx, canvasSize in
                    let c = CGPoint(x: canvasSize.width / 2, y: canvasSize.height / 2)
                    let outer = r - 4

                    func tick(_ i: Int) -> Path {
                        let major = i % 5 == 0
                        let a = Double(i) / 60 * 2 * .pi - .pi / 2
                        let inner = outer - (major ? 14 : 7)
                        var p = Path()
                        p.move(to: dialPoint(c, a, inner))
                        p.addLine(to: dialPoint(c, a, outer))
                        return p
                    }

                    for i in 0..<60 {
                        let major = i % 5 == 0
                        let passed = progress > 0 && Double(i) / 60 <= progress
                        let color: Color = passed
                            ? finish.accent
                            : finish.ink.opacity(major ? 0.55 : 0.28)
                        ctx.stroke(
                            tick(i),
                            with: .color(color),
                            style: StrokeStyle(lineWidth: major ? 2.4 : 1.2, lineCap: .round)
                        )
                    }

                    // brilho nas marcas principais já percorridas
                    ctx.drawLayer { layer in
                        layer.addFilter(.shadow(color: finish.accent.opacity(0.9), radius: 5))
                        for i in stride(from: 0, to: 60, by: 5) where progress > 0 && Double(i) / 60 <= progress {
                            layer.stroke(
                                tick(i),
                                with: .color(finish.accent),
                                style: StrokeStyle(lineWidth: 2.4, lineCap: .round)
                            )
                        }
                    }
                }

                // ponteiro de progresso: uma volta = a fase inteira
                ZStack {
                    Capsule()
                        .fill(finish.accent)
                        .frame(width: 4, height: r - 34)
                        .offset(y: -(r - 34) / 2)
                    Capsule()
                        .fill(finish.ink.opacity(0.7))
                        .frame(width: 4, height: 22)
                        .offset(y: 11)
                }
                .rotationEffect(.degrees(progress * 360))

                // eixo
                Circle().fill(finish.surface).frame(width: 16, height: 16)
                Circle().strokeBorder(finish.accent, lineWidth: 3).frame(width: 16, height: 16)
            }
            .frame(width: size, height: size)
            .position(x: geo.size.width / 2, y: geo.size.height / 2)
        }
    }
}

private func dialPoint(_ c: CGPoint, _ angle: Double, _ radius: CGFloat) -> CGPoint {
    CGPoint(x: c.x + CGFloat(cos(angle)) * radius, y: c.y + CGFloat(sin(angle)) * radius)
}
