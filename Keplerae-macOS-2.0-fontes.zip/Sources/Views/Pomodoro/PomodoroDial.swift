import SwiftUI

private enum DialFinish: Int, CaseIterable, Identifiable {
    case porcelain, graphite, clay, deepSea, signal
    var id: Int { rawValue }
    var name: String {
        switch self {
        case .porcelain: return "Porcelana"
        case .graphite: return "Grafite"
        case .clay: return "Argila"
        case .deepSea: return "Azul profundo"
        case .signal: return "Sinal"
        }
    }
    var surface: Color {
        switch self {
        case .porcelain: return Color(dialHex: 0xF6F6F8)
        case .graphite: return Color(dialHex: 0x2C2C2F)
        case .clay: return Color(dialHex: 0xF3E7D6)
        case .deepSea: return Color(dialHex: 0x22395A)
        case .signal: return Color(dialHex: 0xFF6A3A)
        }
    }
    var ink: Color {
        switch self {
        case .porcelain, .clay: return Color(dialHex: 0x353532)
        case .graphite: return Color(dialHex: 0xEDEDE9)
        case .deepSea: return Color(dialHex: 0xD5EBFA)
        case .signal: return Color(dialHex: 0xFFF0CB)
        }
    }
    var accent: Color {
        switch self {
        case .porcelain, .graphite: return Color(dialHex: 0xB3D45E)
        case .clay: return Color(dialHex: 0xB96547)
        case .deepSea: return Color(dialHex: 0xA6DCFA)
        case .signal: return Color(dialHex: 0xFFF0CB)
        }
    }
}

private extension Color {
    init(dialHex hex: UInt32) {
        self.init(.sRGB, red: Double((hex >> 16) & 255) / 255,
                  green: Double((hex >> 8) & 255) / 255,
                  blue: Double(hex & 255) / 255, opacity: 1)
    }
}

struct PomodoroDial: View {
    @EnvironmentObject private var store: PomodoroStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("pomodoroDialFinish") private var finishRaw = DialFinish.graphite.rawValue

    private var finish: DialFinish { DialFinish(rawValue: finishRaw) ?? .graphite }
    private var cyclePosition: Int {
        min(max(store.phase == .focus ? store.cycle + 1 : store.cycle, 1), max(store.settings.cycles, 1))
    }

    var body: some View {
        VStack(spacing: 20) {
            TimelineView(.animation(minimumInterval: reduceMotion ? 1 : 1.0 / 30,
                                    paused: !store.running || scenePhase != .active)) { timeline in
                let reading = PomodoroDialReading(
                    totalSeconds: store.settings.minutes(for: store.phase) * 60,
                    remainingSeconds: store.remainingSeconds,
                    deadline: store.phaseDeadline, date: timeline.date
                )
                ZStack(alignment: .topLeading) {
                    RoundedRectangle(cornerRadius: 68, style: .continuous)
                        .fill(finish.surface.gradient)
                    DialFace(finish: finish, reading: reading)
                    VStack(alignment: .leading) {
                        Text(timeString(store.remainingSeconds))
                            .font(.system(size: 24, weight: .medium, design: .monospaced))
                            .monospacedDigit()
                            .padding(.horizontal, 12).padding(.vertical, 7)
                            .background(finish.ink.opacity(0.045), in: Capsule())
                            .background(finish.surface, in: Capsule())
                        Spacer()
                        VStack(alignment: .leading, spacing: 4) {
                            Text(store.phase.title.uppercased())
                                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                                .tracking(2)
                            Text("\(finish.name)  \(cyclePosition) / \(max(store.settings.cycles, 1))")
                                .font(.system(size: 10, design: .monospaced))
                                .opacity(0.65)
                        }
                        .padding(.horizontal, 12).padding(.vertical, 10)
                        .background(finish.ink.opacity(0.045), in: Capsule())
                    }
                    .padding(28)
                    .foregroundStyle(finish.ink)
                }
                .clipShape(RoundedRectangle(cornerRadius: 68, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 68, style: .continuous)
                    .strokeBorder(.white.opacity(0.10), lineWidth: 1))
                // No inherited phase/style animation may interpolate the hands backwards on reset.
                .transaction { $0.animation = nil }
                .shadow(color: .black.opacity(0.12), radius: 18, y: 12)
            }
            .frame(width: 380, height: 380)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Pomodoro, \(store.phase.title)")
            .accessibilityValue("Restam \(timeString(store.remainingSeconds))")

            HStack(spacing: 13) {
                ForEach(DialFinish.allCases) { value in
                    Button { finishRaw = value.rawValue } label: {
                        Circle().fill(value.surface)
                            .overlay(Circle().strokeBorder(Color.primary.opacity(0.15), lineWidth: 1))
                            .padding(3)
                            .overlay(Circle().strokeBorder(finish == value ? Color.primary.opacity(0.5) : .clear, lineWidth: 1.5))
                            .frame(width: 24, height: 24)
                            .padding(4)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Acabamento \(value.name)")
                    .accessibilityAddTraits(finish == value ? .isSelected : [])
                    .help(value.name)
                }
            }
        }
    }

    private func timeString(_ seconds: Int) -> String {
        String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }
}

private struct DialFace: View {
    let finish: DialFinish
    let reading: PomodoroDialReading

    var body: some View {
        Canvas { context, size in
            let center = CGPoint(x: size.width * 0.25, y: size.height * 0.50)
            let radius = size.width * 0.65
            func point(_ degrees: Double, _ length: CGFloat) -> CGPoint {
                // SwiftUI's downward Y axis makes increasing angles travel clockwise.
                let angle = (degrees - 90) * .pi / 180
                return CGPoint(x: center.x + cos(angle) * length, y: center.y + sin(angle) * length)
            }
            func line(_ start: CGPoint, _ end: CGPoint, color: Color, width: CGFloat) {
                var path = Path()
                path.move(to: start); path.addLine(to: end)
                context.stroke(path, with: .color(color), style: StrokeStyle(lineWidth: width, lineCap: .round))
            }
            for index in 0..<60 {
                let angle = Double(index) * 6
                let major = index % 5 == 0
                if major {
                    line(center, point(angle, radius), color: finish.ink.opacity(0.035), width: 1)
                }
                line(point(angle, radius - (major ? 19 : 7)), point(angle, radius),
                     color: major ? finish.accent.opacity(0.90) : finish.ink.opacity(0.20), width: major ? 4 : 1)
                if major {
                    var label = context
                    let position = point(angle, radius - 35)
                    label.translateBy(x: position.x, y: position.y)
                    label.rotate(by: .degrees(angle))
                    label.draw(Text("\(index == 0 ? 12 : index / 5)")
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundStyle(finish.ink.opacity(0.50)), at: .zero)
                }
            }
            func hand(_ degrees: Double, length: CGFloat, width: CGFloat) {
                line(point(degrees + 180, 13), point(degrees, length), color: .black.opacity(0.12), width: width + 3)
                line(point(degrees + 180, 12), point(degrees, length), color: finish.ink.opacity(0.48), width: width)
                line(point(degrees, length * 0.48), point(degrees, length - 4), color: finish.accent, width: width * 0.40)
            }
            hand(reading.hourDegrees, length: radius * 0.42, width: 8)
            hand(reading.minuteDegrees, length: radius * 0.79, width: 6)
            line(point(reading.secondDegrees + 180, 35), point(reading.secondDegrees, radius * 0.88),
                 color: finish.accent.opacity(0.75), width: 1)
            let hub = CGRect(x: center.x - 9, y: center.y - 9, width: 18, height: 18)
            context.fill(Path(ellipseIn: hub), with: .color(finish.surface))
            context.stroke(Path(ellipseIn: hub), with: .color(finish.ink.opacity(0.3)), lineWidth: 1)
            context.fill(Path(ellipseIn: hub.insetBy(dx: 6, dy: 6)), with: .color(finish.accent))
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}
