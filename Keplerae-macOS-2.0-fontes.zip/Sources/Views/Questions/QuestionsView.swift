import SwiftUI

struct QuestionsView: View {
    @EnvironmentObject private var store: QuestionsStore
    @AppStorage("glassIntensityPercent") private var glassIntensityPercent = 85
    @State private var selectedSubject: UUID?
    @State private var showCreate = false
    @State private var showAdd = false
    private var intensity: Double { Double(glassIntensityPercent) / 100 }
    private var filteredRecords: [QuestionRecord] { store.records.filter { selectedSubject == nil || $0.subjectID == selectedSubject } }
    private var totals: (correct: Int, wrong: Int, total: Int, accuracy: Double) { store.totals(subjectID: selectedSubject) }

    var body: some View {
        NavigationStack {
            ZStack {
                AmbientBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        HStack(alignment: .top) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text("Questões").font(.largeTitle.bold())
                                Text("Registre acertos e erros para acompanhar sua evolução.").foregroundStyle(.secondary)
                            }
                            Spacer()
                            Button { showCreate = true } label: { Image(systemName: "folder.badge.plus") }
                                .buttonStyle(.bordered)
                                .help("Criar matéria")
                                .accessibilityLabel("Criar matéria")
                        }

                        ScrollView(.horizontal) {
                            HStack {
                                FilterChip(title: "Geral", selected: selectedSubject == nil) { selectedSubject = nil }
                                ForEach(store.subjects) { subject in FilterChip(title: subject.name, selected: selectedSubject == subject.id) { selectedSubject = subject.id } }
                            }
                        }.scrollIndicators(.hidden)

                        HStack(spacing: 10) {
                            MetricCard(title: "Questões", value: totals.total, intensity: intensity)
                            MetricCard(title: "Acertos", value: totals.correct, intensity: intensity)
                            MetricCard(title: "Erros", value: totals.wrong, intensity: intensity)
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Taxa de acerto").font(.caption).foregroundStyle(.secondary)
                                Text(totals.total == 0 ? "—" : String(format: "%.1f%%", totals.accuracy))
                                    .font(.title2.bold()).monospacedDigit()
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(14)
                            .kepleraeGlass(intensity: intensity, cornerRadius: 20, interactive: false)
                        }

                        Button {
                            if store.subjects.isEmpty { showCreate = true } else { showAdd = true }
                        } label: {
                            Label("Registrar e calcular", systemImage: "plus.circle.fill").frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                        .keyboardShortcut("n", modifiers: .command)

                        Text("Histórico").font(.title2.bold())
                        if filteredRecords.isEmpty {
                            Label("Adicione uma matéria e registre sua primeira sessão.", systemImage: "chart.line.uptrend.xyaxis")
                                .font(.subheadline).foregroundStyle(.secondary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(14)
                                .kepleraeGlass(intensity: intensity, cornerRadius: 20, interactive: false)
                        } else {
                            LazyVGrid(columns: [GridItem(.adaptive(minimum: 300, maximum: 490), spacing: 12)], spacing: 12) {
                                ForEach(filteredRecords.sorted(by: { $0.recordedAt > $1.recordedAt })) { record in
                                    QuestionHistoryRow(record: record, subject: store.subjects.first(where: { $0.id == record.subjectID }), onDelete: { store.deleteRecord(record.id) }, intensity: intensity)
                                }
                            }
                        }

                        ErrorNotebookSection(subjectID: selectedSubject, intensity: intensity)
                            .padding(.top, 8)
                    }.padding(20)
                        .padding(.bottom, 32)
                        .frame(maxWidth: 1040)
                        .frame(maxWidth: .infinity)
                }
            }.navigationTitle("Questões")
        }
        .sheet(isPresented: $showCreate) {
            CreateQuestionSubjectSheet { id in
                selectedSubject = id
                showCreate = false
            }
            .frame(minWidth: 460, idealWidth: 520, minHeight: 260)
        }
        .sheet(isPresented: $showAdd) {
            AddQuestionRecordSheet(initialSubject: selectedSubject)
                .frame(minWidth: 480, idealWidth: 560, minHeight: 380)
        }
    }
}

private struct FilterChip: View {
    let title: String; let selected: Bool; let action: () -> Void
    var body: some View { Button(action: action) { Text(title).font(.subheadline.weight(.medium)).padding(.horizontal, 12).padding(.vertical, 8).background(selected ? Color.accentColor.opacity(0.18) : Color.secondary.opacity(0.08), in: Capsule()) }.buttonStyle(.plain) }
}

private struct MetricCard: View {
    let title: String; let value: Int; let intensity: Double
    var body: some View { VStack(alignment: .leading, spacing: 4) { Text(title).font(.caption).foregroundStyle(.secondary); Text("\(value)").font(.title2.bold()) }.frame(maxWidth: .infinity, alignment: .leading).padding(14).kepleraeGlass(intensity: intensity, cornerRadius: 20, interactive: false) }
}

private struct QuestionHistoryRow: View {
    let record: QuestionRecord; let subject: QuestionSubject?; let onDelete: () -> Void; let intensity: Double
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(subject?.name ?? "Matéria").font(.subheadline.weight(.semibold)).lineLimit(1)
                Text(record.recordedAt.formatted(date: .abbreviated, time: .omitted)).font(.caption).foregroundStyle(.secondary)
                Text("\(record.correct) acertos • \(record.wrong) erros • \(String(format: "%.1f%%", record.accuracy))")
                    .font(.caption)
            }
            Spacer(); Button(role: .destructive, action: onDelete) { Image(systemName: "trash") }.buttonStyle(.plain)
        }.padding(12).kepleraeGlass(intensity: intensity, cornerRadius: 20, interactive: false)
    }
}

private struct CreateQuestionSubjectSheet: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: QuestionsStore
    @State private var name = ""
    @State private var error: String?
    let onCreated: (UUID) -> Void

    var body: some View {
        NavigationStack {
            Form {
                Section("Nova matéria") {
                    TextField("Nome do bloco", text: $name)
                    if let error {
                        Text(error).foregroundStyle(.red)
                    }
                }
            }
            .formStyle(.grouped)
            .navigationTitle("Criar bloco")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") { dismiss() }
                        .keyboardShortcut(.cancelAction)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Criar") {
                        do {
                            onCreated(try store.createSubject(name))
                            dismiss()
                        } catch {
                            self.error = error.localizedDescription
                        }
                    }
                    .keyboardShortcut(.defaultAction)
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}

private struct AddQuestionRecordSheet: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: QuestionsStore
    @State private var selected: UUID?
    @State private var correct = ""
    @State private var wrong = ""
    @State private var error: String?
    let initialSubject: UUID?

    var body: some View {
        NavigationStack {
            Form {
                Section("Matéria") {
                    Picker("Matéria", selection: $selected) {
                        ForEach(store.subjects) {
                            Text($0.name).tag(Optional($0.id))
                        }
                    }
                }
                Section("Resultado") {
                    TextField("Acertos", text: $correct)
                        .textFieldStyle(.roundedBorder)
                    TextField("Erros", text: $wrong)
                        .textFieldStyle(.roundedBorder)
                    if let error { Text(error).foregroundStyle(.red) }
                }
            }
            .formStyle(.grouped)
            .navigationTitle("Registrar questões")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") { dismiss() }
                        .keyboardShortcut(.cancelAction)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Salvar") { save() }
                        .keyboardShortcut("s", modifiers: .command)
                }
            }
            .onAppear { selected = initialSubject ?? store.subjects.first?.id }
        }
    }

    private func save() {
        guard let selected,
              let correct = Int(correct.trimmingCharacters(in: .whitespacesAndNewlines)),
              let wrong = Int(wrong.trimmingCharacters(in: .whitespacesAndNewlines)) else {
            error = "Preencha os números e escolha uma matéria."
            return
        }
        do {
            try store.add(subjectID: selected, correct: correct, wrong: wrong)
            dismiss()
        } catch {
            self.error = error.localizedDescription
        }
    }
}
