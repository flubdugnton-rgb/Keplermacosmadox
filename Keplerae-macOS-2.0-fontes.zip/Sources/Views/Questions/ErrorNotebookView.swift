import SwiftUI

struct ErrorNotebookSection: View {
    @EnvironmentObject private var store: QuestionsStore
    let subjectID: UUID?
    let intensity: Double
    @State private var query = ""
    @State private var status: MistakeReviewStatus?
    @State private var editing: QuestionMistake?

    private var entries: [QuestionMistake] {
        store.mistakes.filter {
            (subjectID == nil || $0.subjectID == subjectID) &&
            (status == nil || $0.status == status) &&
            (query.isEmpty || $0.searchableText.localizedStandardContains(query))
        }.sorted { $0.updatedAt > $1.updatedAt }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Label("Caderno de erros", systemImage: "book.closed")
                        .font(.title2.bold())
                    Text("Entenda o erro, registre a correção e volte para revisar.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Button {
                    editing = QuestionMistake(subjectID: subjectID)
                } label: {
                    Label("Adicionar erro", systemImage: "plus")
                }
                .buttonStyle(.borderedProminent)
            }

            HStack(spacing: 12) {
                TextField("Buscar assunto, origem ou correção", text: $query)
                    .textFieldStyle(.roundedBorder)
                Picker("Revisão", selection: $status) {
                    Text("Todos").tag(Optional<MistakeReviewStatus>.none)
                    ForEach(MistakeReviewStatus.allCases) { Text($0.title).tag(Optional($0)) }
                }
                .frame(maxWidth: 180)
            }

            if entries.isEmpty {
                Text(store.mistakes.isEmpty ? "Adicione uma questão que você errou para começar seu caderno." : "Nenhum erro encontrado com estes filtros.")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(16)
                    .kepleraeGlass(intensity: intensity, cornerRadius: 22, interactive: false)
            } else {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 270, maximum: 490), spacing: 14)], spacing: 14) {
                    ForEach(entries) { entry in
                        Button { editing = entry } label: {
                            VStack(alignment: .leading, spacing: 9) {
                                HStack {
                                    Text(entry.topic).font(.headline).lineLimit(1)
                                    Spacer(minLength: 4)
                                    Image(systemName: entry.status == .learned ? "checkmark.circle.fill" : "arrow.clockwise")
                                        .foregroundStyle(entry.status == .learned ? Color.green : .orange)
                                }
                                Text(store.subjects.first(where: { $0.id == entry.subjectID })?.name ?? "Sem matéria")
                                    .font(.caption).foregroundStyle(.secondary)
                                Text([entry.source, entry.location].filter { !$0.isEmpty }.joined(separator: " · "))
                                    .font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                Text(entry.explanation.isEmpty ? entry.question : entry.explanation)
                                    .font(.subheadline).lineLimit(2)
                                Spacer(minLength: 0)
                                HStack {
                                    Text(entry.status.title)
                                        .font(.caption.weight(.semibold))
                                    Spacer()
                                    if entry.isDue {
                                        Label("Revisar hoje", systemImage: "calendar.badge.clock")
                                            .foregroundStyle(.orange)
                                    } else if let date = entry.reviewDate, entry.status != .learned {
                                        Text(date, format: .dateTime.day().month())
                                    }
                                }.font(.caption)
                            }
                            .frame(maxWidth: .infinity, minHeight: 142, maxHeight: 142, alignment: .topLeading)
                            .padding(16)
                            .kepleraeGlass(intensity: intensity, cornerRadius: 24)
                        }
                        .buttonStyle(.plain)
                        .contextMenu {
                            ForEach(MistakeReviewStatus.allCases) { status in
                                Button(status.title) { store.setMistakeStatus(entry.id, status: status) }
                            }
                        }
                    }
                }
            }
        }
        .sheet(item: $editing) { entry in
            ErrorNotebookEditor(entry: entry)
                .frame(minWidth: 580, idealWidth: 680, minHeight: 650, idealHeight: 760)
        }
    }
}

private struct ErrorNotebookEditor: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: QuestionsStore
    @State private var entry: QuestionMistake
    @State private var scheduleReview: Bool
    @State private var reviewDate: Date
    @State private var error: String?
    @State private var confirmDelete = false

    init(entry: QuestionMistake) {
        _entry = State(initialValue: entry)
        _scheduleReview = State(initialValue: entry.reviewDate != nil)
        _reviewDate = State(initialValue: entry.reviewDate ?? Calendar.current.date(byAdding: .day, value: 1, to: .now) ?? .now)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Onde você errou") {
                    TextField("Assunto", text: $entry.topic)
                    Picker("Matéria", selection: $entry.subjectID) {
                        Text("Sem matéria").tag(Optional<UUID>.none)
                        ForEach(store.subjects) { Text($0.name).tag(Optional($0.id)) }
                    }
                    TextField("Origem: prova, site, livro ou aula", text: $entry.source)
                    TextField("Localização: banca, ano, questão ou página", text: $entry.location)
                }
                Section("Questão") {
                    TextEditor(text: $entry.question)
                        .frame(minHeight: 70)
                        .accessibilityLabel("Enunciado da questão")
                    TextField("Minha resposta", text: $entry.markedAnswer, axis: .vertical)
                    TextField("Resposta correta", text: $entry.correctAnswer, axis: .vertical)
                }
                Section("O que aprender com o erro") {
                    Picker("Motivo", selection: $entry.reason) {
                        ForEach(MistakeReason.allCases) { Text($0.title).tag($0) }
                    }
                    TextEditor(text: $entry.explanation)
                        .frame(minHeight: 90)
                        .accessibilityLabel("Explicação e correção do erro")
                }
                Section("Revisão") {
                    Picker("Situação", selection: $entry.status) {
                        ForEach(MistakeReviewStatus.allCases) { Text($0.title).tag($0) }
                    }
                    Toggle("Agendar próxima revisão", isOn: $scheduleReview)
                    if scheduleReview {
                        DatePicker("Revisar em", selection: $reviewDate, displayedComponents: .date)
                    }
                }
                if let error { Text(error).foregroundStyle(.red) }
                if store.mistakes.contains(where: { $0.id == entry.id }) {
                    Section {
                        Button("Excluir do caderno", role: .destructive) { confirmDelete = true }
                    }
                }
            }
            .formStyle(.grouped)
            .navigationTitle("Caderno de erros")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") { dismiss() }.keyboardShortcut(.cancelAction)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Salvar") {
                        entry.reviewDate = scheduleReview ? reviewDate : nil
                        do { try store.upsertMistake(entry); dismiss() }
                        catch { self.error = error.localizedDescription }
                    }
                    .keyboardShortcut("s", modifiers: .command)
                    .disabled(entry.topic.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .confirmationDialog("Excluir este registro do caderno de erros?", isPresented: $confirmDelete) {
                Button("Excluir", role: .destructive) { store.deleteMistake(entry.id); dismiss() }
                Button("Cancelar", role: .cancel) { }
            }
        }
    }
}
