import Foundation

enum MistakeReason: String, CaseIterable, Codable, Identifiable {
    case content, interpretation, attention, calculation, other
    var id: String { rawValue }
    var title: String {
        switch self {
        case .content: return "Conteúdo"
        case .interpretation: return "Interpretação"
        case .attention: return "Atenção"
        case .calculation: return "Cálculo"
        case .other: return "Outro"
        }
    }
}

enum MistakeReviewStatus: String, CaseIterable, Codable, Identifiable {
    case pending, reviewing, learned
    var id: String { rawValue }
    var title: String {
        switch self {
        case .pending: return "A revisar"
        case .reviewing: return "Em revisão"
        case .learned: return "Aprendido"
        }
    }
}

struct QuestionMistake: Identifiable, Hashable, Codable {
    var id = UUID()
    var subjectID: UUID?
    var topic = ""
    var source = ""
    var location = ""
    var question = ""
    var markedAnswer = ""
    var correctAnswer = ""
    var explanation = ""
    var reason: MistakeReason = .content
    var status: MistakeReviewStatus = .pending
    var reviewDate: Date?
    var createdAt = Date()
    var updatedAt = Date()

    var searchableText: String {
        [topic, source, location, question, markedAnswer, correctAnswer, explanation].joined(separator: " ")
    }

    var isDue: Bool {
        status != .learned && (reviewDate.map { Calendar.current.startOfDay(for: $0) <= Calendar.current.startOfDay(for: .now) } ?? false)
    }
}
