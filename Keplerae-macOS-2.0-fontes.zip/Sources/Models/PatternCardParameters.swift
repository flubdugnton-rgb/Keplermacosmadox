import Foundation

/// Defaults solicitados para Pattern Cards, compartilhados pelo app e pelo protótipo.
struct PatternCardParameters: Codable, Equatable, Sendable {
    struct Typography: Codable, Equatable, Sendable {
        let titleSize: Double
        let titleWeight: Double
        let descriptionSize: Double
        let descriptionWeight: Double
    }
    let typography: Typography

    struct Highlight: Codable, Equatable, Sendable {
        let x: Double
        let y: Double
    }
    let highlight: Highlight

    struct Card: Codable, Equatable, Sendable {
        let height: Double
    }
    let card: Card

    struct Effect: Codable, Equatable, Sendable {
        let scale: Double
    }
    let effect: Effect

    struct Animation: Codable, Equatable, Sendable {
        let speed: Double
        let phaseSpread: Double
        let easing: Double
        let fillBias: Double
    }
    let animation: Animation

    struct Particles: Codable, Equatable, Sendable {
        let spawnRate: Double
        let fallSpeed: Double
        let jitter: Double
        let lifetime: Double
        let fadeStart: Double
        let startOpacity: Double
    }
    let particles: Particles

    struct PatternA: Codable, Equatable, Sendable {
        let size: Double
        let dotScale: Double
        let ringStrokeScale: Double
    }
    let patternA: PatternA

    struct PatternB: Codable, Equatable, Sendable {
        let size: Double
        let dotScale: Double
        let ringStrokeScale: Double
    }
    let patternB: PatternB

    struct PatternC: Codable, Equatable, Sendable {
        let size: Double
        let dotScale: Double
        let ringStrokeScale: Double
    }
    let patternC: PatternC

    struct Tilt: Codable, Equatable, Sendable {
        let maxAngle: Double
        let randomness: Double
        let perspective: Double
        let scaleMax: Double
        let scaleRadius: Double
        let packIterations: Double
        let easing: Double
        let centerDurationMs: Double
        let centerStaggerMs: Double
        let centerOffsetY: Double
        let keepInGrid: Bool
        let pushSmoothingMs: Double
        let scaleSmoothingMs: Double
        let fadeOthers: Bool
        let othersOpacity: Double
    }
    let tilt: Tilt

    struct Shimmer: Codable, Equatable, Sendable {
        let enabled: Bool
        let intensity: Double
        let widthPct: Double
        let angleDeg: Double
        let blurPx: Double
        let durationMs: Double
        let loopDelayMs: Double
        let color: String
        let blendMode: String
    }
    let shimmer: Shimmer

    static let reference = Self(
        typography: .init(titleSize: 33.0, titleWeight: 700.0, descriptionSize: 17.0, descriptionWeight: 200.0),
        highlight: .init(x: 0.11, y: -0.09),
        card: .init(height: 289.8),
        effect: .init(scale: 0.76),
        animation: .init(speed: 0.44, phaseSpread: 2.25, easing: 3.0, fillBias: -0.34),
        particles: .init(spawnRate: 0.6, fallSpeed: 47.0, jitter: 0.26, lifetime: 1.7, fadeStart: 0.0, startOpacity: 0.28),
        patternA: .init(size: 127.0, dotScale: 0.86, ringStrokeScale: 0.06),
        patternB: .init(size: 127.0, dotScale: 0.86, ringStrokeScale: 0.06),
        patternC: .init(size: 127.0, dotScale: 0.86, ringStrokeScale: 0.06),
        tilt: .init(maxAngle: 0.0, randomness: 0.56, perspective: 520.0, scaleMax: 3.8, scaleRadius: 161.0, packIterations: 40.0, easing: 1.6, centerDurationMs: 420.0, centerStaggerMs: 320.0, centerOffsetY: -43.0, keepInGrid: false, pushSmoothingMs: 260.0, scaleSmoothingMs: 220.0, fadeOthers: true, othersOpacity: 0.12),
        shimmer: .init(enabled: true, intensity: 0.2, widthPct: 162.0, angleDeg: 38.0, blurPx: 60.0, durationMs: 320.0, loopDelayMs: 8000.0, color: "#ffffff", blendMode: "screen")
    )

    static let defaults: Self = {
        guard let url = Bundle.main.url(forResource: "PatternCards.defaults", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let value = try? Self(flatJSON: data) else { return .reference }
        return value
    }()

}

extension PatternCardParameters {
    init(flatJSON data: Data) throws {
        let flat = try JSONSerialization.jsonObject(with: data) as? [String: Any] ?? [:]
        var nested: [String: [String: Any]] = [:]
        for (key, value) in flat {
            let parts = key.split(separator: ".", maxSplits: 1).map(String.init)
            guard parts.count == 2 else { continue }
            nested[parts[0], default: [:]][parts[1]] = value
        }
        self = try JSONDecoder().decode(Self.self, from: JSONSerialization.data(withJSONObject: nested))
    }
}
