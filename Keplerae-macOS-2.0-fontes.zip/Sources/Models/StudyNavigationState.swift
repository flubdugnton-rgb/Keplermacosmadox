import Foundation

/// Todas as telas de estudo pertencem à mesma pilha, inclusive pastas aninhadas.
enum StudyRoute: Hashable {
    case library(type: StudyContentType?)
    case subject(Subject, type: StudyContentType?)
    case folder(Subject, type: StudyContentType?, status: String, path: [String])
    case item(StudyItem)
}

struct StudyNavigationState {
    var path: [StudyRoute] = []

    mutating func returnHome() {
        path.removeAll()
    }
}
