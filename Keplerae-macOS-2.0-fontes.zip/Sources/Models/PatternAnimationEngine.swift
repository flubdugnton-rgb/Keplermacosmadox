import Foundation
import CoreGraphics

enum PatternCardVariant: String, CaseIterable, Sendable {
    case a, b, c

    var occupiedCells: [Int] {
        switch self {
        case .a: return [2, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 18, 19, 22]
        case .b: return [0, 1, 5, 6, 7, 11, 12, 13, 17, 18, 19, 23, 24]
        case .c: return [2, 7, 10, 11, 12, 13, 14, 17, 22]
        }
    }

    static func forSubject(_ id: String) -> Self {
        switch id {
        case "portugues", "sus": return .b
        case "matematica", "profisio": return .c
        default: return .a
        }
    }
}

/// Port nativo da geometria 5×5, preenchimento/anel, partículas e colisões
/// observados em experiments.thisiswhitespace.com/pattern-cards.
/// Não usa WebView nem executa código remoto dentro do aplicativo.
final class PatternAnimationEngine {
    struct Dot {
        let center: CGPoint
        let solidRadius: Double
        let ringRadius: Double
        let ringWidth: Double
        let ringOpacity: Double
        let opacity: Double
    }

    struct Frame {
        let dots: [Dot]
        let particles: [Dot]
    }

    private struct Particle {
        var center: CGPoint
        var age: Double
        let phase: Double
        let scale: Double
    }

    private struct Tween {
        var start: CGPoint = .zero
        var target: CGPoint = .zero
        var began = 0.0
    }

    let variant: PatternCardVariant
    private var previousTime: Double?
    private var elapsed = 0.0
    private var hovering = false
    private var centerTweens: [Int: Tween] = [:]
    private var centers: [Int: CGPoint] = [:]
    private var scales: [Int: Double] = [:]
    private var particles: [Particle] = []
    private var lastSpawn: [Int: Double] = [:]
    private var staticOpacity = 1.0
    private var particleOpacity = 1.0
    private var randomState: UInt64
    private let intensities: [Double]

    init(variant: PatternCardVariant, seed: UInt64 = 1) {
        self.variant = variant
        randomState = seed &+ 1
        intensities = (0..<25).map { index in
            let hash = (UInt64(index + 1) &* 2_654_435_761) ^ seed
            return 0.15 + 0.85 * Double(hash % 65_535) / 65_535
        }
    }

    func frame(time: Double, cursor: CGPoint?, centerOffset: CGPoint, fallHeight: Double,
               staticTarget: Double, parameters p: PatternCardParameters, reducedMotion: Bool = false) -> Frame {
        let dt = previousTime.map { min(max(time - $0, 0), 0.05) } ?? 0
        previousTime = time
        if !reducedMotion { elapsed += dt }
        let style: PatternCardParameters.PatternA
        // Os três defaults têm o mesmo esquema, mas continuam configuráveis separadamente.
        switch variant {
        case .a: style = p.patternA
        case .b: style = .init(size: p.patternB.size, dotScale: p.patternB.dotScale, ringStrokeScale: p.patternB.ringStrokeScale)
        case .c: style = .init(size: p.patternC.size, dotScale: p.patternC.dotScale, ringStrokeScale: p.patternC.ringStrokeScale)
        }
        let cell = style.size / 5
        let radius = cell * style.dotScale / 2
        let stroke = 2 * radius * style.ringStrokeScale
        let ringRadius = max(0, radius - stroke / 2)
        let indices = variant.occupiedCells
        let active = cursor != nil && !reducedMotion

        if active != hovering {
            for index in indices {
                let current = centerValue(for: index, parameters: p, reducedMotion: reducedMotion)
                centerTweens[index] = Tween(start: current, target: active ? centerOffset : .zero, began: elapsed)
            }
            hovering = active
        }
        let localCursor = active ? cursor.map { CGPoint(x: $0.x - centerOffset.x, y: $0.y - centerOffset.y) } : nil
        let base = indices.map { CGPoint(x: Double($0 % 5) * cell + cell / 2, y: Double($0 / 5) * cell + cell / 2) }
        var targets = base
        let radii: [Double] = indices.enumerated().map { offset, index in
            guard let cursor = localCursor, p.tilt.scaleMax > 1 else { return radius }
            let distance = hypot(cursor.x - base[offset].x, cursor.y - base[offset].y)
            let normalized = max(0, 1 - distance / max(0.001, p.tilt.scaleRadius))
            let randomness = 1 + (intensities[index] - 1) * p.tilt.randomness
            return radius * (1 + pow(normalized, max(0.05, p.tilt.easing)) * (p.tilt.scaleMax - 1) * randomness)
        }

        if active && !p.tilt.keepInGrid && p.tilt.scaleMax > 1 {
            for _ in 0..<max(0, Int(p.tilt.packIterations.rounded())) {
                for a in 0..<indices.count {
                    for b in (a + 1)..<indices.count {
                        let dx = targets[b].x - targets[a].x
                        let dy = targets[b].y - targets[a].y
                        let distance = hypot(dx, dy)
                        let baseGap = hypot(base[b].x - base[a].x, base[b].y - base[a].y) - 2 * radius
                        let minimum = radii[a] + radii[b] + baseGap
                        if distance > 0.0001 && distance < minimum {
                            let push = (minimum - distance) / 2
                            targets[a].x -= dx / distance * push
                            targets[a].y -= dy / distance * push
                            targets[b].x += dx / distance * push
                            targets[b].y += dy / distance * push
                        }
                    }
                }
            }
        }

        let pushAlpha = reducedMotion ? 1 : 1 - exp(-dt / max(0.001, p.tilt.pushSmoothingMs / 1000))
        let scaleAlpha = reducedMotion ? 1 : 1 - exp(-dt / max(0.001, p.tilt.scaleSmoothingMs / 1000))
        let fadeAlpha = reducedMotion ? 1 : 1 - exp(-dt / max(0.001, p.tilt.centerDurationMs / 1000))
        staticOpacity += (staticTarget - staticOpacity) * fadeAlpha
        particleOpacity += ((active ? 0.0 : 1.0) - particleOpacity) * fadeAlpha
        var dots: [Dot] = []
        for (offset, index) in indices.enumerated() {
            let previous = centers[index] ?? base[offset]
            let center = CGPoint(x: previous.x + (targets[offset].x - previous.x) * pushAlpha,
                                 y: previous.y + (targets[offset].y - previous.y) * pushAlpha)
            let oldScale = scales[index] ?? 1
            let scale = oldScale + (radii[offset] / max(radius, 0.000001) - oldScale) * scaleAlpha
            centers[index] = center
            scales[index] = scale
            let move = centerValue(for: index, parameters: p, reducedMotion: reducedMotion)
            dots.append(dot(center: CGPoint(x: center.x + move.x, y: center.y + move.y),
                            phase: phase(index), scale: scale, opacity: staticOpacity,
                            radius: radius, ringRadius: ringRadius, stroke: stroke, parameters: p))
        }

        if !reducedMotion {
            particles = particles.compactMap { particle in
                var updated = particle
                updated.age += dt
                updated.center.y += p.particles.fallSpeed * dt
                return updated.age < p.particles.lifetime && updated.center.y <= style.size + fallHeight + cell ? updated : nil
            }
            if p.particles.spawnRate > 0 {
                let interval = 1 / p.particles.spawnRate
                let bottom = Dictionary(grouping: indices, by: { $0 % 5 }).values.compactMap { $0.max() }
                for index in bottom.sorted() {
                    let last = lastSpawn[index] ?? -interval
                    let jitter = (random() - 0.5) * p.particles.jitter * interval
                    if elapsed - last >= interval + jitter {
                        lastSpawn[index] = elapsed
                        let point = centers[index] ?? CGPoint(x: Double(index % 5) * cell + cell / 2,
                                                              y: Double(index / 5 + 1) * cell + cell / 2)
                        particles.append(Particle(center: CGPoint(x: point.x, y: point.y + cell), age: 0,
                                                  phase: phase(index) + 1.5 * random(), scale: scales[index] ?? 1))
                    }
                }
            }
        }

        let falling: [Dot] = reducedMotion ? [] : particles.map { particle in
            let life = particle.age / max(0.001, p.particles.lifetime)
            let fade = life > p.particles.fadeStart
                ? max(0, 1 - (life - p.particles.fadeStart) / max(0.001, 1 - p.particles.fadeStart)) : 1
            return dot(center: particle.center, phase: particle.phase, scale: particle.scale,
                       opacity: p.particles.startOpacity * fade * particleOpacity, radius: radius, ringRadius: ringRadius,
                       stroke: stroke, parameters: p)
        }
        return Frame(dots: dots, particles: falling)
    }

    private func centerValue(for index: Int, parameters p: PatternCardParameters, reducedMotion: Bool) -> CGPoint {
        let centerTween = centerTweens[index] ?? Tween()
        if reducedMotion { return centerTween.target }
        let delay = max(0, min(1, (intensities[index] - 0.15) / 0.85)) * p.tilt.centerStaggerMs / 1000
        let fraction = min(max((elapsed - centerTween.began - delay) / max(0.001, p.tilt.centerDurationMs / 1000), 0), 1)
        let eased = Self.centerEase(fraction)
        return CGPoint(x: centerTween.start.x + (centerTween.target.x - centerTween.start.x) * eased,
                       y: centerTween.start.y + (centerTween.target.y - centerTween.start.y) * eased)
    }

    private func phase(_ index: Int) -> Double { 0.45 * Double(index / 5) + 0.7 * Double(index % 5) }

    private func dot(center: CGPoint, phase: Double, scale: Double, opacity: Double, radius: Double,
                     ringRadius: Double, stroke: Double, parameters p: PatternCardParameters) -> Dot {
        let wave = min(max((sin(elapsed * p.animation.speed * .pi * 2 + phase * p.animation.phaseSpread) + p.animation.fillBias + 1) / 2, 0), 1)
        let mix = wave < 0.5 ? pow(2 * wave, p.animation.easing) / 2 : 1 - pow(2 * (1 - wave), p.animation.easing) / 2
        return Dot(center: center, solidRadius: max(0, radius * (1 - mix)) * scale,
                   ringRadius: ringRadius * scale, ringWidth: stroke * scale,
                   ringOpacity: mix, opacity: opacity)
    }

    private func random() -> Double {
        randomState = randomState &* 6_364_136_223_846_793_005 &+ 1
        return Double(randomState >> 11) / Double(UInt64.max >> 11)
    }

    /// Resolve cubic-bezier(.22,.61,.36,1), igual à transição de centralização.
    static func centerEase(_ fraction: Double) -> Double {
        var low = 0.0, high = 1.0
        for _ in 0..<16 {
            let t = (low + high) / 2
            let x = 3 * (1 - t) * (1 - t) * t * 0.22 + 3 * (1 - t) * t * t * 0.36 + t * t * t
            if x < fraction { low = t } else { high = t }
        }
        let t = (low + high) / 2
        return 3 * (1 - t) * (1 - t) * t * 0.61 + 3 * (1 - t) * t * t + t * t * t
    }
}
