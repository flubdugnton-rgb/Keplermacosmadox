import Foundation

struct DriveStreamDescriptor: Equatable, Sendable {
    let url: URL
    let accessToken: String
    let mimeType: String
}

/// Every network request is bounded; playback never requests or caches a complete media file.
enum DriveStreamingPolicy {
    static let chunkSize = 256 * 1024

    static func range(offset: Int64, remaining: Int64) -> ClosedRange<Int64> {
        let start = max(0, offset)
        let count = min(Int64(chunkSize), max(1, remaining))
        let (end, overflow) = start.addingReportingOverflow(count - 1)
        return start...(overflow ? Int64.max : end)
    }

    struct ContentRange: Equatable, Sendable {
        let start: Int64
        let end: Int64
        let total: Int64

        init(_ header: String?) throws {
            guard let header, header.lowercased().hasPrefix("bytes ") else { throw StreamingError.invalidRange }
            let parts = header.dropFirst(6).split(separator: "/")
            guard parts.count == 2, let total = Int64(parts[1]), total > 0 else { throw StreamingError.invalidRange }
            let bounds = parts[0].split(separator: "-", omittingEmptySubsequences: false)
            guard bounds.count == 2, let start = Int64(bounds[0]), let end = Int64(bounds[1]),
                  start >= 0, end >= start, end < total else { throw StreamingError.invalidRange }
            self.start = start; self.end = end; self.total = total
        }
    }
}

enum StreamingError: LocalizedError {
    case invalidRange, rangeNotSupported, invalidResponse, httpStatus(Int)
    var errorDescription: String? {
        switch self {
        case .invalidRange, .invalidResponse: return "O servidor retornou um trecho de mídia inválido. Tente abrir a aula novamente."
        case .rangeNotSupported: return "Este arquivo não respondeu ao streaming por trechos. Nenhuma cópia local será criada. Tente novamente."
        case .httpStatus(let status):
            if status == 401 { return "Não foi possível renovar a sessão do vídeo. Abra a aula novamente." }
            if status == 403 { return "Sua conta não tem acesso a este arquivo do Drive." }
            return "Não foi possível conectar ao streaming (erro \(status))."
        }
    }
}
