import Foundation

/// Countdown text uses remaining time; analog hands use elapsed time.
/// Angles deliberately stay unwrapped, so 59 → 60 seconds never rotates backwards.
struct PomodoroDialReading {
    let elapsed: TimeInterval

    init(totalSeconds: Int, remainingSeconds: Int, deadline: Date?, date: Date) {
        let total = Double(max(1, totalSeconds))
        let remaining = deadline.map { $0.timeIntervalSince(date) } ?? Double(remainingSeconds)
        elapsed = min(total, max(0, total - remaining))
    }

    var hourDegrees: Double { elapsed / 3600 * 30 }
    var minuteDegrees: Double { elapsed / 60 * 6 }
    var secondDegrees: Double { elapsed * 6 }
}
