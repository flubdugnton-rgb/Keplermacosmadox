import Foundation

struct KepleraeCloudState {
    let schemaVersion: Int
    let updatedAt: Date
    let sourcePlatform: String?
    let deviceID: String?
    let googleProjectNumber: String?
    let favorites: [String]
    let completed: [String]
    let lastOpenedID: String?
    let notes: [StudyNote]
    let noteTags: [NoteTag]
    let questionSubjects: [QuestionSubject]
    let questionRecords: [QuestionRecord]
    let pomodoroSettings: PomodoroSettings
    let pomodoroHistory: [FocusRecord]
    let theme: AppTheme
    let glassIntensity: Int

    var hasUserData: Bool {
        !favorites.isEmpty || !completed.isEmpty || !notes.isEmpty || !noteTags.isEmpty ||
        !questionSubjects.isEmpty || !questionRecords.isEmpty || !pomodoroHistory.isEmpty
    }
}

extension KepleraeCloudState: Codable {
    private enum CodingKeys: String, CodingKey {
        case schemaVersion, updatedAt, sourcePlatform, deviceID, googleProjectNumber
        case favorites, completed, lastOpenedID, notes, noteTags
        case questionSubjects, questionRecords, pomodoroSettings, pomodoroHistory
        case theme, glassIntensity
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        schemaVersion = try container.decodeIfPresent(Int.self, forKey: .schemaVersion) ?? 1

        if let date = try? container.decode(Date.self, forKey: .updatedAt) {
            updatedAt = date
        } else if let numeric = try? container.decode(Double.self, forKey: .updatedAt) {
            // Android 1.1.1 gravava epoch em milissegundos. Mantemos migração automática.
            let seconds = numeric > 10_000_000_000 ? numeric / 1000.0 : numeric
            updatedAt = Date(timeIntervalSince1970: seconds)
        } else if let raw = try? container.decode(String.self, forKey: .updatedAt),
                  let parsed = ISO8601DateFormatter().date(from: raw) {
            updatedAt = parsed
        } else {
            updatedAt = .distantPast
        }

        sourcePlatform = try container.decodeIfPresent(String.self, forKey: .sourcePlatform)
        deviceID = try container.decodeIfPresent(String.self, forKey: .deviceID)
        googleProjectNumber = try container.decodeIfPresent(String.self, forKey: .googleProjectNumber)
        favorites = try container.decodeIfPresent([String].self, forKey: .favorites) ?? []
        completed = try container.decodeIfPresent([String].self, forKey: .completed) ?? []
        lastOpenedID = try container.decodeIfPresent(String.self, forKey: .lastOpenedID)
        notes = try container.decodeIfPresent([StudyNote].self, forKey: .notes) ?? []
        noteTags = try container.decodeIfPresent([NoteTag].self, forKey: .noteTags) ?? []
        questionSubjects = try container.decodeIfPresent([QuestionSubject].self, forKey: .questionSubjects) ?? []
        questionRecords = try container.decodeIfPresent([QuestionRecord].self, forKey: .questionRecords) ?? []
        pomodoroSettings = try container.decodeIfPresent(PomodoroSettings.self, forKey: .pomodoroSettings) ?? PomodoroSettings()
        pomodoroHistory = try container.decodeIfPresent([FocusRecord].self, forKey: .pomodoroHistory) ?? []

        if let rawTheme = try container.decodeIfPresent(String.self, forKey: .theme) {
            theme = AppTheme(rawValue: rawTheme.lowercased()) ?? .system
        } else {
            theme = .system
        }
        glassIntensity = min(100, max(0, try container.decodeIfPresent(Int.self, forKey: .glassIntensity) ?? 85))
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(schemaVersion, forKey: .schemaVersion)
        try container.encode(updatedAt, forKey: .updatedAt)
        try container.encodeIfPresent(sourcePlatform, forKey: .sourcePlatform)
        try container.encodeIfPresent(deviceID, forKey: .deviceID)
        try container.encodeIfPresent(googleProjectNumber, forKey: .googleProjectNumber)
        try container.encode(favorites, forKey: .favorites)
        try container.encode(completed, forKey: .completed)
        try container.encodeIfPresent(lastOpenedID, forKey: .lastOpenedID)
        try container.encode(notes, forKey: .notes)
        try container.encode(noteTags, forKey: .noteTags)
        try container.encode(questionSubjects, forKey: .questionSubjects)
        try container.encode(questionRecords, forKey: .questionRecords)
        try container.encode(pomodoroSettings, forKey: .pomodoroSettings)
        try container.encode(pomodoroHistory, forKey: .pomodoroHistory)
        try container.encode(theme.rawValue, forKey: .theme)
        try container.encode(glassIntensity, forKey: .glassIntensity)
    }
}

enum CloudSyncStatus: Equatable {
    case idle
    case syncing
    case synced(Date)
    case failed(String)

    var title: String {
        switch self {
        case .idle: return "Aguardando"
        case .syncing: return "Sincronizando…"
        case .synced: return "Sincronizado"
        case .failed: return "Falha na sincronização"
        }
    }
}

