import Foundation

extension Notification.Name {
    static let kepleraeDataDidChange = Notification.Name("keplerae.data.didChange")
}
