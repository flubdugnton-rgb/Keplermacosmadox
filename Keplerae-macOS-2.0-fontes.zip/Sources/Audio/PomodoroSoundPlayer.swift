import AVFoundation
import Combine
import Foundation

@MainActor
protocol PomodoroAudioPlaying: AnyObject {
    func startTicking(volume: Double)
    func stopTicking()
    func playAlarm(volume: Double)
    func stopAll()
}

/// Dois arquivos fornecidos pelo usuário: tique-taque em loop e alarme único.
@MainActor
final class PomodoroSoundPlayer: ObservableObject, PomodoroAudioPlaying {
    @Published private(set) var lastError: String?
    private var ticking: AVAudioPlayer?
    private var alarm: AVAudioPlayer?

    func startTicking(volume: Double) {
        if ticking == nil { ticking = prepare("pomodoro_clock", loops: -1) }
        ticking?.volume = Float(min(max(volume, 0), 1))
        if ticking?.isPlaying == false { ticking?.play() }
    }
    func stopTicking() { ticking?.stop(); ticking = nil }
    func playAlarm(volume: Double) {
        alarm?.stop()
        alarm = prepare("pomodoro_alarm", loops: 0)
        alarm?.volume = Float(min(max(volume, 0), 1))
        alarm?.play()
    }
    func stopAll() { stopTicking(); alarm?.stop(); alarm = nil }

    private func prepare(_ resource: String, loops: Int) -> AVAudioPlayer? {
        let url = Bundle.main.url(forResource: resource, withExtension: "wav")
            ?? Bundle.main.url(forResource: resource, withExtension: "wav", subdirectory: "Sounds")
            ?? Bundle.main.url(forResource: resource, withExtension: "wav", subdirectory: "Resources/Sounds")
        guard let url else {
            lastError = "Não foi possível encontrar o som do Pomodoro."
            return nil
        }
        do {
            let player = try AVAudioPlayer(contentsOf: url)
            player.numberOfLoops = loops
            player.prepareToPlay()
            lastError = nil
            return player
        } catch { lastError = error.localizedDescription; return nil }
    }
}
