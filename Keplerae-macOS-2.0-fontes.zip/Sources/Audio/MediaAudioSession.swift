/// macOS routes AVPlayer and AVAudioPlayer through the user's selected output
/// device automatically and allows ambient audio to mix with other apps.
/// Keep the common playback entry point without configuring an iOS audio session.
enum MediaAudioSession {
    static func activatePlayback() {
        // The desktop system owns routing and audio activation.
    }
}
