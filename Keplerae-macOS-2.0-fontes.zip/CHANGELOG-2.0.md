# Kepleræ macOS 2.0

Primeira versão nativa macOS, derivada da base iOS 2.0.

- Navegação lateral, janelas redimensionáveis e atalhos de teclado.
- Google Sign-In com janela AppKit, client ID macOS e integração com Chaves.
- PDFs com PDFKit e tela cheia nativa, AVPlayer e APNGs transparentes.
- Catálogo, dados locais e contrato de sincronização 2.0 preservados.
- Build universal Apple Silicon/Intel, ZIP/DMG, assinatura Developer ID opcional e notarização opcional.
- Testes de compatibilidade do schema e validação dos recursos.
