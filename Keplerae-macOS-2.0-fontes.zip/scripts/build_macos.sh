#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."

python3 scripts/validate_macos.py
command -v xcodegen >/dev/null || { echo "Instale XcodeGen: brew install xcodegen"; exit 1; }
xcodegen generate
rm -rf build/CoreTests.xcresult
xcodebuild -project Keplerae.xcodeproj -scheme Keplerae \
  -configuration Debug -destination 'platform=macOS' \
  -derivedDataPath build -resultBundlePath build/CoreTests.xcresult \
  CODE_SIGNING_ALLOWED=NO test
xcodebuild -project Keplerae.xcodeproj -scheme Keplerae \
  -configuration Release -destination 'generic/platform=macOS' \
  -derivedDataPath build ARCHS='arm64 x86_64' ONLY_ACTIVE_ARCH=NO \
  CODE_SIGNING_ALLOWED=NO build

mkdir -p dist
rm -rf dist/Keplerae.app
ditto build/Build/Products/Release/Keplerae.app dist/Keplerae.app
lipo dist/Keplerae.app/Contents/MacOS/Keplerae -verify_arch arm64 x86_64

if [[ -n "${MACOS_SIGN_IDENTITY:-}" ]]; then
  # Sign nested binary bundles before the containing app.
  while IFS= read -r -d '' framework; do
    codesign --force --options runtime --timestamp --sign "$MACOS_SIGN_IDENTITY" "$framework"
  done < <(find dist/Keplerae.app/Contents -depth -type d -name '*.framework' -print0)
  codesign --force --options runtime --timestamp --sign "$MACOS_SIGN_IDENTITY" dist/Keplerae.app
  echo "Assinatura Developer ID aplicada."
else
  codesign --force --deep --sign - dist/Keplerae.app
  echo "Build de teste com assinatura ad hoc; credenciais guardadas no Chaves local do Mac."
fi
codesign --verify --deep --strict --verbose=2 dist/Keplerae.app

ditto -c -k --sequesterRsrc --keepParent dist/Keplerae.app dist/Keplerae-macOS-2.0.2.zip
if [[ -n "${APPLE_ID:-}" && -n "${APPLE_APP_SPECIFIC_PASSWORD:-}" && -n "${APPLE_TEAM_ID:-}" && -n "${MACOS_SIGN_IDENTITY:-}" ]]; then
  xcrun notarytool submit dist/Keplerae-macOS-2.0.2.zip \
    --apple-id "$APPLE_ID" --password "$APPLE_APP_SPECIFIC_PASSWORD" \
    --team-id "$APPLE_TEAM_ID" --wait
  xcrun stapler staple dist/Keplerae.app
  rm dist/Keplerae-macOS-2.0.2.zip
  ditto -c -k --sequesterRsrc --keepParent dist/Keplerae.app dist/Keplerae-macOS-2.0.2.zip
fi

rm -rf build/dmg
mkdir -p build/dmg
ditto dist/Keplerae.app build/dmg/Keplerae.app
ln -s /Applications build/dmg/Applications
hdiutil create -volname 'Kepleræ 2.0.2' -srcfolder build/dmg -ov \
  -format UDZO dist/Keplerae-macOS-2.0.2.dmg
shasum -a 256 dist/Keplerae-macOS-2.0.2.zip dist/Keplerae-macOS-2.0.2.dmg > dist/SHA256SUMS.txt
echo 'Aplicativo universal Apple Silicon/Intel e instalador gerados em dist/.'
