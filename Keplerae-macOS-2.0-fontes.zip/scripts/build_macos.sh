#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."

python3 scripts/validate_macos.py
command -v xcodegen >/dev/null || { echo "Instale XcodeGen: brew install xcodegen"; exit 1; }
xcodegen generate
rm -rf build/CoreTests.xcresult
xcodebuild -project Keplerae.xcodeproj -scheme Keplerae \
  -configuration Debug -destination 'platform=macOS' \
  -derivedDataPath build -resultBundlePath build/CoreTests.xcresult \
  CODE_SIGNING_ALLOWED=NO test
xcodebuild -project Keplerae.xcodeproj -scheme Keplerae \
  -configuration Release -destination 'generic/platform=macOS' \
  -derivedDataPath build ARCHS='arm64 x86_64' ONLY_ACTIVE_ARCH=NO \
  CODE_SIGNING_ALLOWED=NO build

mkdir -p dist
rm -rf dist/Keplerae.app
ditto build/Build/Products/Release/Keplerae.app dist/Keplerae.app
lipo -verify_arch arm64 x86_64 dist/Keplerae.app/Contents/MacOS/Keplerae

if [[ -n "${MACOS_SIGN_IDENTITY:-}" ]]; then
  : "${APPLE_TEAM_ID:?Defina APPLE_TEAM_ID para assinar o aplicativo.}"
  : "${MACOS_PROVISION_PROFILE:?Defina MACOS_PROVISION_PROFILE com o perfil Developer ID que autoriza acesso ao Chaves.}"
  test -f "$MACOS_PROVISION_PROFILE"
  cp "$MACOS_PROVISION_PROFILE" dist/Keplerae.app/Contents/embedded.provisionprofile
  security cms -D -i "$MACOS_PROVISION_PROFILE" > build/ProvisioningProfile.plist
  python3 - <<'PY'
import datetime, fnmatch, os, plistlib
bundle = 'com.aistudio.keplerae.stdy.macos'
team = os.environ['APPLE_TEAM_ID']
with open('build/ProvisioningProfile.plist', 'rb') as file:
    profile = plistlib.load(file)
assert team in profile['TeamIdentifier'], 'O perfil pertence a outra equipe Apple.'
assert profile['ExpirationDate'] > datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None), 'O perfil está expirado.'
prefix = profile['ApplicationIdentifierPrefix'][0]
application_id = f'{prefix}.{bundle}'
allowed = profile['Entitlements']
assert fnmatch.fnmatchcase(application_id, allowed['com.apple.application-identifier']), 'O perfil não autoriza o bundle ID do Kepleræ macOS.'
assert any(fnmatch.fnmatchcase(application_id, group) for group in allowed.get('keychain-access-groups', [])), 'O perfil não autoriza o grupo de acesso ao Chaves.'
entitlements = {
    'keychain-access-groups': [application_id],
    'com.apple.application-identifier': application_id,
    'com.apple.developer.team-identifier': team,
}
with open('build/Signing.entitlements', 'wb') as file:
    plistlib.dump(entitlements, file)
PY
  # Sign nested binary bundles before the containing app.
  while IFS= read -r -d '' framework; do
    codesign --force --options runtime --timestamp --sign "$MACOS_SIGN_IDENTITY" "$framework"
  done < <(find dist/Keplerae.app/Contents -depth -type d -name '*.framework' -print0)
  codesign --force --options runtime --timestamp --sign "$MACOS_SIGN_IDENTITY" \
    --entitlements build/Signing.entitlements dist/Keplerae.app
  echo "Assinatura Apple aplicada; verificar o login com o cliente OAuth macOS."
else
  codesign --force --deep --sign - dist/Keplerae.app
  echo "Build de teste com assinatura ad hoc. O login Google requer assinatura Apple."
fi
codesign --verify --deep --strict --verbose=2 dist/Keplerae.app

ditto -c -k --sequesterRsrc --keepParent dist/Keplerae.app dist/Keplerae-macOS-2.0.zip
if [[ -n "${APPLE_ID:-}" && -n "${APPLE_APP_SPECIFIC_PASSWORD:-}" && -n "${APPLE_TEAM_ID:-}" && -n "${MACOS_SIGN_IDENTITY:-}" ]]; then
  xcrun notarytool submit dist/Keplerae-macOS-2.0.zip \
    --apple-id "$APPLE_ID" --password "$APPLE_APP_SPECIFIC_PASSWORD" \
    --team-id "$APPLE_TEAM_ID" --wait
  xcrun stapler staple dist/Keplerae.app
  rm dist/Keplerae-macOS-2.0.zip
  ditto -c -k --sequesterRsrc --keepParent dist/Keplerae.app dist/Keplerae-macOS-2.0.zip
fi

rm -rf build/dmg
mkdir -p build/dmg
ditto dist/Keplerae.app build/dmg/Keplerae.app
ln -s /Applications build/dmg/Applications
hdiutil create -volname 'Kepleræ 2.0' -srcfolder build/dmg -ov \
  -format UDZO dist/Keplerae-macOS-2.0.dmg
shasum -a 256 dist/Keplerae-macOS-2.0.zip dist/Keplerae-macOS-2.0.dmg > dist/SHA256SUMS.txt
echo 'Aplicativo universal Apple Silicon/Intel e instalador gerados em dist/.'
