#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."

python3 scripts/validate_macos.py
command -v xcodegen >/dev/null || { echo "Instale XcodeGen: brew install xcodegen"; exit 1; }
xcodegen generate
rm -rf build/CoreTests.xcresult
xcodebuild -project Keplerae.xcodeproj -scheme Keplerae \
  -configuration Debug -destination 'platform=macOS' \
  -derivedDataPath build -resultBundlePath build/CoreTests.xcresult \
  CODE_SIGNING_ALLOWED=NO test
xcodebuild -project Keplerae.xcodeproj -scheme Keplerae \
  -configuration Release -destination 'generic/platform=macOS' \
  -derivedDataPath build ARCHS='arm64 x86_64' ONLY_ACTIVE_ARCH=NO \
  CODE_SIGNING_ALLOWED=NO build

mkdir -p dist
rm -rf dist/Keplerae.app
ditto build/Build/Products/Release/Keplerae.app dist/Keplerae.app
lipo dist/Keplerae.app/Contents/MacOS/Keplerae -verify_arch arm64 x86_64

if [[ -n "${MACOS_SIGN_IDENTITY:-}" ]]; then
  # Sign nested binary bundles before the containing app.
  while IFS= read -r -d '' framework; do
    codesign --force --options runtime --timestamp --sign "$MACOS_SIGN_IDENTITY" "$framework"
  done < <(find dist/Keplerae.app/Contents -depth -type d -name '*.framework' -print0)
  codesign --force --options runtime --timestamp --sign "$MACOS_SIGN_IDENTITY" dist/Keplerae.app
  echo "Assinatura Developer ID aplicada."
else
  codesign --force --deep --sign - dist/Keplerae.app
  echo "Build de teste com assinatura ad hoc; credenciais guardadas no Chaves local do Mac."
fi
codesign --verify --deep --strict --verbose=2 dist/Keplerae.app

app_version=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' dist/Keplerae.app/Contents/Info.plist)
archive_path="dist/Keplerae-macOS-${app_version}.zip"
installer_path="dist/Keplerae-macOS-${app_version}.dmg"
ditto -c -k --sequesterRsrc --keepParent dist/Keplerae.app "$archive_path"
if [[ -n "${APPLE_ID:-}" && -n "${APPLE_APP_SPECIFIC_PASSWORD:-}" && -n "${APPLE_TEAM_ID:-}" && -n "${MACOS_SIGN_IDENTITY:-}" ]]; then
  xcrun notarytool submit "$archive_path" \
    --apple-id "$APPLE_ID" --password "$APPLE_APP_SPECIFIC_PASSWORD" \
    --team-id "$APPLE_TEAM_ID" --wait
  xcrun stapler staple dist/Keplerae.app
  rm "$archive_path"
  ditto -c -k --sequesterRsrc --keepParent dist/Keplerae.app "$archive_path"
fi

rm -rf build/dmg
mkdir -p build/dmg
ditto dist/Keplerae.app build/dmg/Keplerae.app
ln -s /Applications build/dmg/Applications
hdiutil create -volname "Kepleræ ${app_version}" -srcfolder build/dmg -ov \
  -format UDZO "$installer_path"
shasum -a 256 "$archive_path" "$installer_path" > dist/SHA256SUMS.txt
echo 'Aplicativo universal Apple Silicon/Intel e instalador gerados em dist/.'
