#!/usr/bin/env python3
"""Validate bundled content and configuration before compiling the native Mac app."""
import json
import plistlib
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parent.parent
catalog = json.loads((root / "Resources/catalog.json").read_text())
assert len(catalog) == 1035
assert len({row["id"] for row in catalog}) == len(catalog)
assert Counter(row["type"] for row in catalog) == Counter(VIDEO=709, PDF=313, AUDIO=13)
assert Counter(row["subjectId"] for row in catalog) == Counter(
    portugues=356, profisio=311, fisioterapia=170, sus=135, hu_legislacao=33, matematica=17,
    isgh_lei_das_os=13
)
isgh = [row for row in catalog if row["subjectId"] == "isgh_lei_das_os"]
assert Counter(row["type"] for row in isgh) == Counter(VIDEO=6, PDF=7)
assert Counter(tuple(row["folderPath"]) for row in isgh) == Counter({
    ("LEI DA OS",): 5,
    ("LEI DA OS", "Impressos"): 7,
    ("LEI DA OS", "Resolução de Questões"): 1,
})
assert len({row["driveFileId"] for row in isgh}) == 13
assert all(row["linkKind"] == "FILE" and row["driveFileId"] for row in isgh)
public_media = [row for row in catalog if row.get("mediaDelivery") == "PUBLIC_DOWNLOAD"]
assert len(public_media) == 6
assert all(row["subjectId"] == "isgh_lei_das_os" and row["type"] == "VIDEO" for row in public_media)
portuguese = [row for row in catalog if row["subjectId"] == "portugues"]
assert len({row["folderPath"][0] for row in portuguese}) == 11
assert sum(row["linkKind"] == "FOLDER" for row in portuguese) == 342
assert all(row["driveFileId"] for row in portuguese if row["linkKind"] == "FOLDER")

client_id = "240965240632-g58uffmvvthdqa1mk513fd4k8m8jml2v.apps.googleusercontent.com"
plist = plistlib.loads((root / "Resources/Info.plist").read_bytes())
assert plist["GIDClientID"] == client_id
assert plist["CFBundleURLTypes"][0]["CFBundleURLSchemes"] == [
    "com.googleusercontent.apps.240965240632-g58uffmvvthdqa1mk513fd4k8m8jml2v"
]
assert "LSRequiresIPhoneOS" not in plist
assert plist["LSMinimumSystemVersion"] == "$(MACOSX_DEPLOYMENT_TARGET)"
plistlib.loads((root / "Resources/Keplerae.entitlements").read_bytes())

for source in (root / "Sources").rglob("*.swift"):
    text = source.read_text()
    for unsupported in ("import UIKit", "UIViewRepresentable", "AVAudioSession", ".keyboardType(",
                        ".navigationBarTitleDisplayMode(", ".tabViewStyle(.page", "Color(uiColor:"):
        assert unsupported not in text, f"iOS API in {source}: {unsupported}"
    assert "GOCSPX-" not in text, f"OAuth secret in {source}"

icons = root / "Resources/Assets.xcassets/AppIcon.appiconset"
for icon in json.loads((icons / "Contents.json").read_text())["images"]:
    assert icon["idiom"] == "mac"
    assert (icons / icon["filename"]).is_file()

for name in ("pomodoro_rest", "pomodoro_fishing"):
    assert (root / f"Resources/Animations/{name}.png").is_file()
for name in ("pomodoro_clock", "pomodoro_alarm"):
    assert (root / f"Resources/Sounds/{name}.wav").is_file()
assert {p.name for p in (root / "Resources/Sounds").iterdir() if p.suffix == ".wav"} == {"pomodoro_clock.wav", "pomodoro_alarm.wav"}
print("macOS: catálogo de 1.035 recursos, OAuth público, ícones e APIs validados.")
