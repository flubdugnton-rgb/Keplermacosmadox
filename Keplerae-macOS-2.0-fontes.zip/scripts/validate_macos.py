#!/usr/bin/env python3
"""Validate bundled content and configuration before compiling the native Mac app."""
import json
import plistlib
from collections import Counter
from pathlib import Path

root = Path(__file__).resolve().parent.parent
catalog = json.loads((root / "Resources/catalog.json").read_text())
assert len(catalog) == 1022
assert len({row["id"] for row in catalog}) == len(catalog)
assert Counter(row["type"] for row in catalog) == Counter(VIDEO=703, PDF=306, AUDIO=13)
assert Counter(row["subjectId"] for row in catalog) == Counter(
    portugues=356, profisio=311, fisioterapia=170, sus=135, hu_legislacao=33, matematica=17
)
portuguese = [row for row in catalog if row["subjectId"] == "portugues"]
assert len({row["folderPath"][0] for row in portuguese}) == 11
assert sum(row["linkKind"] == "FOLDER" for row in portuguese) == 342
assert all(row["driveFileId"] for row in portuguese if row["linkKind"] == "FOLDER")

client_id = "240965240632-g58uffmvvthdqa1mk513fd4k8m8jml2v.apps.googleusercontent.com"
plist = plistlib.loads((root / "Resources/Info.plist").read_bytes())
assert plist["GIDClientID"] == client_id
assert plist["CFBundleURLTypes"][0]["CFBundleURLSchemes"] == [
    "com.googleusercontent.apps.240965240632-g58uffmvvthdqa1mk513fd4k8m8jml2v"
]
assert "LSRequiresIPhoneOS" not in plist
assert plist["LSMinimumSystemVersion"] == "$(MACOSX_DEPLOYMENT_TARGET)"
plistlib.loads((root / "Resources/Keplerae.entitlements").read_bytes())

for source in (root / "Sources").rglob("*.swift"):
    text = source.read_text()
    for unsupported in ("import UIKit", "UIViewRepresentable", "AVAudioSession", ".keyboardType(",
                        ".navigationBarTitleDisplayMode(", ".tabViewStyle(.page", "Color(uiColor:"):
        assert unsupported not in text, f"iOS API in {source}: {unsupported}"
    assert "GOCSPX-" not in text, f"OAuth secret in {source}"

icons = root / "Resources/Assets.xcassets/AppIcon.appiconset"
for icon in json.loads((icons / "Contents.json").read_text())["images"]:
    assert icon["idiom"] == "mac"
    assert (icons / icon["filename"]).is_file()

for name in ("pomodoro_rest", "pomodoro_fishing"):
    assert (root / f"Resources/Animations/{name}.png").is_file()
for name in ("clock", "wind", "rain", "storm", "fire", "library", "room"):
    assert (root / f"Resources/Sounds/ambient_{name}.m4a").is_file()
print("macOS: catálogo de 1.022 recursos, OAuth público, ícones e APIs validados.")
